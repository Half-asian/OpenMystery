using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using Newtonsoft.Json;

public class GlobalEngineVariables
{
    public static string configs_content_file = "contents.json";

    [JsonProperty("configs_folder")]
    public static string configs_folder;
    [JsonProperty("assets_folder")]
    public static string assets_folder;
    [JsonProperty("apk_folder")]
    public static string apk_folder;
    [JsonProperty("player_folder")]
    public static string player_folder;
    [JsonProperty("tlsq_name")]
    public static string tlsq_name;
    [JsonProperty("launch_mode")]
    public static string launch_mode;
    [JsonProperty("goal_chains")]

    public static Dictionary<string, string> goal_chains;

    public static void CreateFromJSON(string file)
    {
        StreamReader reader = new StreamReader(file);
        string content = reader.ReadToEnd();
        reader.Close();
        
        JsonConvert.DeserializeObject<GlobalEngineVariables>(content);
    }

    public static bool checkIntegrity()
    {
        if (assets_folder == null || configs_folder == null || apk_folder == null || player_folder == null)
            return false;
        if (!Directory.Exists(assets_folder) || !Directory.Exists(configs_folder) || !Directory.Exists(apk_folder) || !Directory.Exists(player_folder))
            return false;
        return true;
    }
    
    public static string getTLSQName()
    {
        if (tlsq_name == null)
            return "";
        return tlsq_name;
    }
}
