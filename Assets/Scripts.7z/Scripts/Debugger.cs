using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Debugger : MonoBehaviour
{
    public Canvas canvas;

    public Text goalchain_text;
    public Text goal_text;
    public Text scenario_text;
    public Text scene_text;
    public Text objectives_text;

    void Update()
    {
        if (Input.GetKeyDown("f3"))
        {
            canvas.enabled = !canvas.enabled; 
        }

        //try
        //{

            if (GameStart.game_state != null)
            {
                if (GameStart.game_state.goal_chain != null)
                {
                    if (GameStart.game_state.goal_chain.goal_chain != null)
                        goalchain_text.text = "Goalchain: " + GameStart.game_state.goal_chain.goal_chain.id;
                    else
                        goalchain_text.text = "Goalchain: None";
                    if (GameStart.ui_manager.next_area_button.activeSelf == true)
                        goal_text.text = "Upcoming Goal: ";
                    else
                        goal_text.text = "Goal: ";
                    Goal g = GameStart.game_state.goal_chain.getCurrentGoal();
                    if (g != null)
                    {
                        goal_text.text += g.goal.goal_id;
                        objectives_text.text = "Active Objectives: \n";

                        List<Objective> objectives = GameStart.game_state.goal_chain.getObjectives();
                        foreach (Objective objective in objectives)
                        {
                            objectives_text.text += "     ID: " + objective.objective.objective_id + "\n          message: " + objective.objective.message + "\n          keys: ";
                            if (objective.objective.keys != null)
                            {
                                foreach (string key in objective.objective.keys)
                                {
                                    objectives_text.text += key + ", ";
                                }
                                objectives_text.text += "\n";
                            }
                        }
                    }
                    else
                    {
                        goal_text.text += "None";
                        objectives_text.text = "Active Objectives: None";
                    }
                    

                }

                if (GameStart.game_state.scenario_holder != null)
                {
                    if (GameStart.game_state.scenario_holder.current_scenario != null)
                        scenario_text.text = "Scenario: " + GameStart.game_state.scenario_holder.current_scenario.scenarioId;
                    if (GameStart.game_state.scenario_holder.scene != null)
                        scene_text.text = "Scene: " + GameStart.game_state.scenario_holder.scene.layoutId;
                }
            }
       // }
        //catch (System.Exception e)
        //{
       //     Debug.LogError("Debugger error " + e.ToString());
        //}
    }
}
