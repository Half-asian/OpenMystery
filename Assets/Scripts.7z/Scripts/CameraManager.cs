using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraManager : MonoBehaviour
{
    public enum CameraState
    {
        StateFree,
        StateAnimation,
        StateLerp,
        StatePanCamOnTrack,
    }
    
    public static GameObject main_camera;
    public static GameObject main_camera_holder;
    public static GameObject main_camera_jt_cam_bind;
    static GameObject main_camera_jt_anim_bind;
    public static SimpleCameraController simple_camera_controller;
    public static CameraState camera_state;

    public static void initialise()
    {
        main_camera_holder = GameObject.Find("Camera Holder");
        main_camera_jt_cam_bind = main_camera_holder.transform.Find("Armature").Find("jt_all_bind").Find("jt_cam_bind").gameObject;
        main_camera_jt_anim_bind = main_camera_jt_cam_bind.transform.Find("jt_anim_bind").gameObject;
        main_camera = main_camera_jt_anim_bind.transform.Find("Main Camera").gameObject;
        simple_camera_controller = main_camera.GetComponent<SimpleCameraController>();
        camera_state = CameraState.StateFree;
        main_camera.transform.localPosition = Vector3.zero;
        main_camera.transform.localEulerAngles = Vector3.zero;
    }

    public static void resetCamera()
    {
        main_camera_holder.transform.localScale = new Vector3(-1, 1, 1);
        main_camera_jt_anim_bind.transform.localPosition = Vector3.zero;
        main_camera_jt_anim_bind.transform.localEulerAngles = Vector3.zero;
        main_camera_jt_cam_bind.transform.localPosition = Vector3.zero;
        main_camera_jt_cam_bind.transform.localEulerAngles = Vector3.zero;
        main_camera.transform.localEulerAngles = new Vector3(0, 180, 0);
        main_camera.transform.position = Vector3.zero;//new Vector3(0, 0.05f, 0); //idk?
    }

    public static void freeCamera()
    {
        camera_state = CameraState.StateFree;
        //simple_camera_controller.enabled = true;
    }

    public static void playCameraAnimation(string animation, bool disable_jt_cam_bind)
    {
        simple_camera_controller.enabled = false;

        camera_state = CameraState.StateAnimation;
        Dictionary<string, AnimationManager.BoneMod> bone_mods = new Dictionary<string, AnimationManager.BoneMod>();

        if (disable_jt_cam_bind)
        {
            bone_mods["jt_cam_bind"] = new AnimationManager.BoneMod(false);
        }

        AnimationClip anim_clip = AnimationManager.loadAnimationClip(animation, "c3b", null, bone_mods, true);


        if (main_camera_holder.GetComponent<Animation>() == null)
        {
            main_camera_holder.AddComponent<Animation>();
        }
        main_camera_holder.GetComponent<Animation>().AddClip(anim_clip, "default");
        main_camera_holder.GetComponent<Animation>().Play("default");
        main_camera_holder.GetComponent<Animation>().wrapMode = WrapMode.Once;

        GameObject.Find("GameManager").GetComponent<EventManager>().startWaitCameraAnimation(Time.realtimeSinceStartup, anim_clip.length, animation);
    }

    static public void panCamOnTrack(string animation)
    {
        if (animation == null)
        {
            return;
        }

        simple_camera_controller.enabled = false;

        camera_state = CameraState.StatePanCamOnTrack;

        
        AnimationClip anim_clip_pancam = AnimationManager.loadAnimationClip(animation, "c3b", null, null, true);

        if (main_camera_holder.GetComponent<Animation>() == null)
        {
            main_camera_holder.AddComponent<Animation>();
        }
        main_camera_holder.GetComponent<Animation>().AddClip(anim_clip_pancam, "default");
        main_camera_holder.GetComponent<Animation>().Play("default");
        main_camera_holder.GetComponent<Animation>().wrapMode = WrapMode.Once;

        GameObject.Find("GameManager").GetComponent<EventManager>().startWaitCameraAnimation(Time.realtimeSinceStartup, anim_clip_pancam.length, animation);

    }

    static public ConfigScene._Scene.Camera focusCam(ref string[] action_params) { //action param 1 is probably lerp transition time
        if (camera_state == CameraState.StateLerp)
        {
            main_camera.transform.localPosition = Vector3.zero;
            main_camera.transform.localEulerAngles = new Vector3(0, 180, 0);
        }     
        
        if (camera_state == CameraState.StatePanCamOnTrack)
        {
            main_camera_holder.GetComponent<Animation>().Stop();
        }

        camera_state = CameraState.StateFree;

        ConfigScene._Scene.Camera last_camera = null;
        
        simple_camera_controller.enabled = false;
        if (action_params.Length > 1)
        {
            if (action_params.Length > 2)
                throw new System.Exception("Camera what the fuck? why do you have more than 2 params?");

            if (action_params[1] == "0")
            {
                simple_camera_controller.enabled = false;
                if (GameStart.game_state.scenario_holder.scene.camera_dict.ContainsKey(action_params[0])){
                    ConfigScene._Scene.Camera camera = GameStart.game_state.scenario_holder.scene.camera_dict[action_params[0]];
                    last_camera = camera;

                    resetCamera();
                    if (camera.fullRoomCam_position != null)
                    {
                        main_camera_jt_cam_bind.transform.localPosition = new Vector3(camera.fullRoomCam_position[0] * 0.01f, camera.fullRoomCam_position[1] * 0.01f, camera.fullRoomCam_position[2] * 0.01f);
                    }
                    if (camera.fullRoomCam_rotation != null)
                    {

                        main_camera_jt_cam_bind.transform.rotation = Quaternion.identity;
                        main_camera_jt_cam_bind.transform.Rotate(new Vector3(0, 0, camera.fullRoomCam_rotation[2]));
                        main_camera_jt_cam_bind.transform.Rotate(new Vector3(0, camera.fullRoomCam_rotation[1], 0));
                        main_camera_jt_cam_bind.transform.Rotate(new Vector3(camera.fullRoomCam_rotation[0], 0, 0));

                        //main_camera_jt_cam_bind.transform.localRotation = Quaternion.Euler(new Vector3(camera.fullRoomCam_rotation[0] * 1, camera.fullRoomCam_rotation[1], camera.fullRoomCam_rotation[2]));
                    }

                    if (camera.animation != null)
                    {
                        //playCameraAnimation(camera.animation, false);

                        simple_camera_controller.enabled = false;

                        //camera_state = CameraState.StateAnimation;

                        AnimationClip anim_clip = AnimationManager.loadAnimationClip(camera.animation, "c3b", null, null, true);

                        anim_clip.SampleAnimation(main_camera_holder, 0.0f);

                    }

                    if (camera.position != null)
                    {
                        if (camera.position.Length != 0)
                        main_camera_jt_cam_bind.transform.localPosition = new Vector3(camera.position[0] * 0.01f, camera.position[1] * 0.01f, camera.position[2] * 0.01f);
                    }
                    if (camera.rotation != null)
                    {
                        if (camera.rotation.Length != 0)
                        {
                            main_camera_jt_cam_bind.transform.rotation = Quaternion.identity;
                            main_camera_jt_cam_bind.transform.Rotate(new Vector3(0, 0, camera.rotation[2]));
                            main_camera_jt_cam_bind.transform.Rotate(new Vector3(0, camera.rotation[1], 0));
                            main_camera_jt_cam_bind.transform.Rotate(new Vector3(camera.rotation[0], 0, 0));
                        }

                        //main_camera_jt_cam_bind.transform.localEulerAngles = new Vector3(camera.rotation[0], camera.rotation[1], camera.rotation[2]);
                    }

                    //Game defined Field of View is often pretty bad. Usually looks better if its constant.
                    if (camera.verticalAOV != 0.0f) 
                    {
                        main_camera.GetComponent<Camera>().fieldOfView = camera.verticalAOV * 1.35f;
                    }
                }
                else
                {
                    Debug.LogError("Could not find camera " + action_params[0] + " in scene");
                }
                simple_camera_controller.enabled = true;
            }
            else
            {
                foreach (ConfigScene._Scene.Camera camera in GameStart.game_state.scenario_holder.scene.cameras)
                {
                    if (camera.name == action_params[0])
                    {
                        camera_state = CameraState.StateLerp;

                        simple_camera_controller.enabled = false;

                        Quaternion rotation = Quaternion.identity;
                        rotation *= Quaternion.Euler(new Vector3(0, 0, camera.rotation[2]));
                        rotation *= Quaternion.Euler(new Vector3(0, camera.rotation[1], 0));
                        rotation *= Quaternion.Euler(new Vector3(camera.rotation[0], 0, 0));


                        //float x_difference = Mathf.DeltaAngle(main_camera_jt_cam_bind.transform.localEulerAngles.x, camera.rotation[0]);
                        //float y_difference = Mathf.DeltaAngle(main_camera_jt_cam_bind.transform.localEulerAngles.y, camera.rotation[1]);//-camera.rotation[1] + 180.0f);
                        //float z_difference = Mathf.DeltaAngle(main_camera_jt_cam_bind.transform.localEulerAngles.z, camera.rotation[2]);

                        //Vector3 rotation_difference = new Vector3(x_difference, y_difference, z_difference);

                        GameObject.Find("GameManager").GetComponent<EventManager>().startLerpCamera(main_camera_jt_cam_bind.transform.localPosition, main_camera_jt_cam_bind.transform.localRotation, new Vector3(camera.position[0] * 0.01f, camera.position[1] * 0.01f, camera.position[2] * 0.01f), rotation, Time.realtimeSinceStartup, float.Parse(action_params[1]));
                    }
                }
            }
        }
        return last_camera;
    }
}
