﻿using System.Collections.Generic;
using System.IO;
using UnityEngine;
using System.Collections;
using System.Threading.Tasks;


public class GameStart : MonoBehaviour
{
    public InteractionProject project_callback;

    static IMenuBackground menu_background;


    public static GameState game_state;

    public static InteractionManager interaction_manager;
    public static EventManager event_manager;
    public static DialogueManager dialogue_manager;
    public static DungeonMaster dungeon_master;
    public static Quidditch quidditch_manager;
    public static EncounterManager encounter_manager;

    public static UiManager ui_manager;


    public static List<Objective> objective_cleanup = new List<Objective>();
    void Update()
    {
        foreach(Objective objective in objective_cleanup)
        {
            objective.cleanup();
        }
        objective_cleanup.Clear();

    }

    public void removePatchesFromCharacter(string character_name)
    {
        if (game_state.characters.ContainsKey(character_name))
        {
            foreach (GameObject patch in game_state.characters[character_name].patches) {
                Destroy(patch);
            }
            game_state.characters[character_name].patches.Clear();
        }
    }


    public void removePatchFromCharacter(string character_name, GameObject patch)
    {
        
        if (patch == null) {
            return;
        }
        if (game_state.characters.ContainsKey(character_name)){

            if (game_state.characters[character_name].patches.Contains(patch))
            {
                game_state.characters[character_name].patches.Remove(patch);
                Debug.Log("Destroyed " + patch.name);
                Destroy(patch);

            }
            else
            {
                Debug.LogWarning("Could not find patch " + patch.name);
            }
        }
    }

    public GameObject addPatchToCharacter(string character_name, string patch_name, Dictionary<string, Transform> parent_bones)
    {
        Debug.Log("add patch " + patch_name + " to " + character_name );
        if (patch_name == "o_Male_ForestFormal_FULL3_skin")
        {
            patch_name = "o_Male_ForestFormal_FULL_skin"; //WHY THE FUCK IS THIS NAMED WRONG
        }
        if (patch_name == "o_Male_ForestFormal_FULL1_skin")
        {
            patch_name = "o_Male_ForestFormal_FULL_skin"; //WHY THE FUCK IS THIS NAMED WRONG
        }

        GameObject p = null;
        
        if (parent_bones == null)
        {
            Debug.LogError("FUCK");
        }

        ModelManager.loadModel(ref p, patch_name, "c3b", parent_bones);
        if (p != null)
        {
            p.AddComponent<Animation>();
            p.transform.parent = game_state.characters[character_name].gameObject.gameObject.transform;
            p.transform.localPosition = Vector3.zero;
            p.transform.localRotation = Quaternion.Euler(Vector3.zero);
            game_state.characters[character_name].patches.Add(p);
        }
        else
        {
            Debug.LogWarning("Failed to load patch " + patch_name);
        }
        return p;
    }


    public void cleanUp()
    {
        foreach (Prop p in game_state.spawned_props.Values)
        {
            Destroy(p.game_object);
        }
        game_state.spawned_props.Clear();



        GetComponent<EventManager>().scenarioTransition();

        GetComponent<DialogueManager>().dialogue_status = DialogueManager.DialogueStatus.Finished;
        GetComponent<DialogueManager>().ui_dialogue.SetActive(false);

        menu_background.spawnMenuBackground();

        game_state.destroy();
        game_state = null;
    }

    public void startMatch(string match_name)
    {
        StartCoroutine(quidditch_manager.startMatchCoroutine(match_name));
    }

    public static void activateScenario(string scenario_name)
    {
        menu_background.destroy();

        ui_manager.showPopup(null); //hide popup

        if (CameraManager.main_camera_holder.GetComponent<Animator>() != null) {
            Destroy(CameraManager.main_camera_holder.GetComponent<Animator>());
        }
        if (game_state == null)
        {
            game_state = new GameState();
        }
        game_state.scenario_holder = new GameState.ScenarioHolder(scenario_name);

        //DialogueManager.local_avatar_clothing_type = null;
        //DialogueManager.local_avatar_secondary_lothing_option = null;

        event_manager.scenarioTransition();


        List<string> props_to_remove = new List<string>();


        foreach (string p in game_state.spawned_props.Keys) //Delete only props spawned by event manager
        {

            if (game_state.spawned_props[p].spawned_by == Prop.spawner.Event)
            {
                props_to_remove.Add(p);
                Destroy(game_state.spawned_props[p].game_object);
            }
        }
        foreach (string p in props_to_remove)
        {
            game_state.spawned_props.Remove(p);
        }

        foreach (CharacterManager c in game_state.characters.Values)
        {
            c.destroyPatches();
        }


        foreach (GameObject c in game_state.characters_gameobjects)
        {
            Destroy(c.gameObject);
        }
        game_state.characters_gameobjects.Clear();
        game_state.characters.Clear();


        foreach (Prop p in game_state.spawned_props.Values)
        {
            Destroy(p.game_object);
        }
        game_state.spawned_props.Clear();


        game_state.refreshBgSound();
        game_state.refreshMusic();

        game_state.characters.Clear();

        game_state.spawnScenarioActors();

        Debug.Log("Finished loading scene. Starting events");


        if (game_state.scenario_holder.scenario.enterEvents != null)
        {
            foreach (string event_string in game_state.scenario_holder.scenario.enterEvents)
            {
                event_manager.event_stack.Add(event_string);
            }
        }

        if (game_state.scenario_holder.scenario.scenarioId == "NUX_TrainScene")
        {
            Debug.Log("choo choo");
            string[] a = new string[] { "cam_shotA", "0" };
            CameraManager.focusCam(ref a);
        }

        if (game_state.scenario_holder.scenario.firstAction != null)
        {
            interaction_manager.activateInteraction(game_state.scenario_holder.scenario.firstAction);
        }

        if (game_state.goal_chain.getCurrentObjective().objectiveHubNpcs != null) //Works if there is only 1 objective hub npc spawned
        {
            foreach (string objective_hub_npc_string in game_state.goal_chain.getCurrentObjective().objectiveHubNpcs)
            {
                ConfigHubNPC._HubNPC objective_hub_npc = Configs.config_hub_npc.HubNPC[objective_hub_npc_string];
                if (objective_hub_npc.autoStartDialogue == true)
                {
                    dialogue_manager.activateNewDialogue(objective_hub_npc.primaryDialogue);
                }
                else
                {
                    Vector3 location = Vector3.zero;
                    foreach (ConfigScene._Scene.WayPoint hotspot in game_state.scenario_holder.scene.waypoints)
                    {
                        if (hotspot.name == objective_hub_npc.hubWaypoint)
                        {
                            location = new Vector3(hotspot.position[0] * -0.01f, hotspot.position[1] * 0.01f + 1.1f, hotspot.position[2] * 0.01f);
                        }
                    }

                    interaction_manager.activateHubNPCInteraction(ref objective_hub_npc.primaryDialogue, ref location);
                    /*Configs.ConfigInteraction.Interaction new_interaction = new Configs.ConfigInteraction.Interaction();
                    GameObject hud_important = Instantiate(Resources.Load<GameObject>("hud_important"), Vector3.zero, Quaternion.identity);
                    InteractionManager im = hud_important.AddComponent<InteractionManager>();
                    im.interaction = new_interaction;
                    new_interaction.type = "GoalDialog";
                    new_interaction.dialogId = objective_hub_npc.primaryDialogue;
                    hud_important.transform.rotation = Quaternion.Euler(new Vector3(90, 0, 0));*/

                }
            }
        }
    }


    public void dialogueChoice1Callback()
    {
        Debug.Log("dialogueChoice1Callback");
        dialogue_manager.ui_dialogue_choice_1.SetActive(false);
        dialogue_manager.ui_dialogue_choice_2.SetActive(false);
        dialogue_manager.ui_dialogue_choice_3.SetActive(false);
        dialogue_manager.next_dialogue = dialogue_manager.dialogue_choice_1_next_dialogue;
        if (!File.ReadAllText("save\\choices_made.txt").Contains("madeChoice(\"" + dialogue_manager.choices[0] + "\")"))
        {
            StreamWriter writer = new StreamWriter("save\\choices_made.txt", true);
            writer.WriteLine("madeChoice(\"" + dialogue_manager.choices[0] + "\")");
            writer.Close();
        }
        dialogue_manager.waiting_for_dialogue = true;
        dialogue_manager.activateDialogue(dialogue_manager.next_dialogue);
    }
    public void dialogueChoice2Callback()
    {
        Debug.Log("dialogueChoice2Callback");
        dialogue_manager.ui_dialogue_choice_1.SetActive(false);
        dialogue_manager.ui_dialogue_choice_2.SetActive(false);
        dialogue_manager.ui_dialogue_choice_3.SetActive(false);
        dialogue_manager.next_dialogue = dialogue_manager.dialogue_choice_2_next_dialogue;
        if (!File.ReadAllText("save\\choices_made.txt").Contains("madeChoice(\"" + dialogue_manager.choices[1] + "\")"))
        {
            StreamWriter writer = new StreamWriter("save\\choices_made.txt", true);
            writer.WriteLine("madeChoice(\"" + dialogue_manager.choices[1] + "\")");
            writer.Close();
        }
        dialogue_manager.waiting_for_dialogue = true;
        dialogue_manager.activateDialogue(dialogue_manager.next_dialogue);
    }
    public void dialogueChoice3Callback()
    {
        Debug.Log("dialogueChoice3Callback");
        dialogue_manager.ui_dialogue_choice_1.SetActive(false);
        dialogue_manager.ui_dialogue_choice_2.SetActive(false);
        dialogue_manager.ui_dialogue_choice_3.SetActive(false); 
        dialogue_manager.next_dialogue = dialogue_manager.dialogue_choice_3_next_dialogue;
        if (!File.ReadAllText("save\\choices_made.txt").Contains("madeChoice(\"" + dialogue_manager.choices[2] + "\")"))
        {
            StreamWriter writer = new StreamWriter("save\\choices_made.txt", true);
            writer.WriteLine("madeChoice(\"" + dialogue_manager.choices[2] + "\")");
            writer.Close();
        }
        dialogue_manager.waiting_for_dialogue = true;
        dialogue_manager.activateDialogue(dialogue_manager.next_dialogue);
    }

    public static void activateProject(string project_name, InteractionProject _project_callback)
    {
        game_state.current_project = Configs.config_project.Project[project_name];

        activateScenario(game_state.current_project.scenarioId);

    }

    public static void finishProject()
    {
        if (game_state.current_project != null)
        {
            if (game_state.current_project.outroScenarioId != null)
                activateScenario(game_state.current_project.outroScenarioId);
        }
        game_state.current_project = null;
    }



    public async Task StartLoading()
    {
        Log.write("Start Loading");


        //anything thats a getcomponent, makes use of coroutines or needs references to game objects

        dialogue_manager = GetComponent<DialogueManager>();
        event_manager = GetComponent<EventManager>();
        dungeon_master = new DungeonMaster();
        interaction_manager = GetComponent<InteractionManager>();
        quidditch_manager = new Quidditch();
        encounter_manager = GetComponent<EncounterManager>();
        ui_manager = GameObject.Find("UI Handler").GetComponent<UiManager>();
        PlayerManager.initialise();
        game_state = new GameState();
        dialogue_manager = GetComponent<DialogueManager>();
        ActorSpawn.initialise();


        DialogueManager.local_avatar_clothing_type = null;
        DialogueManager.local_avatar_secondary_lothing_option = null;

        System.IO.FileStream oFileStream = null;

        if (!Directory.Exists(Application.dataPath + "/../" + "screenshots"))
        {
            Directory.CreateDirectory(Application.dataPath + "/../" + "screenshots");
        }

        if (!File.Exists("save\\choices_made.txt"))
        {
            oFileStream = new System.IO.FileStream("save\\choices_made.txt", System.IO.FileMode.Create);
            oFileStream.Close();
        }

        if (!File.Exists("save\\interactions_complete.txt"))
        {
            oFileStream = new System.IO.FileStream("save\\interactions_complete.txt", System.IO.FileMode.Create);
            oFileStream.Close();
        }

        if (!File.Exists("save\\goals_complete.txt"))
        {
            oFileStream = new System.IO.FileStream("save\\goals_complete.txt", System.IO.FileMode.Create);
            oFileStream.Close();
        }

        if (!File.Exists("save\\goalchains_complete.txt"))
        {
            oFileStream = new System.IO.FileStream("save\\goalchains_complete.txt", System.IO.FileMode.Create);
            oFileStream.Close();
        }

        GetComponent<Player>().setLocalData("character.txt");

        QualitySettings.vSyncCount = 0;
        Application.targetFrameRate = 144;

        Log.write("Pre Config load");
        ui_manager.setup();

        await Configs.loadConfigsAsync();
        Log.write("LOADED ASYNC");
        CameraManager.initialise();
        GameStart.dialogue_manager.playAudioFile(Configs.playlist_dict["BGM"].files[0], "bgaudio");

        if (GlobalEngineVariables.launch_mode == "character")
        {
            UnityEngine.SceneManagement.SceneManager.LoadScene("CharacterCreator");
        }
        else
        {
            ui_manager.setMenu();
            menu_background = GetComponent<IMenuBackground>();
            menu_background.spawnMenuBackground();
        }
    }


    public static void logWrite(string message)
    {
        //StreamWriter writer = new StreamWriter("log.txt", true);
        //Debug.Log(message);
        //writer.WriteLine(message);
        //writer.Close();
    }

    MainMenu main_menu;

    public async void Start()
    {
        main_menu = GameObject.Find("MainMenuCanvas").GetComponent<MainMenu>();
        //Are we in model view or game mode?
        Log.initLog();
        if (!File.Exists("..\\engine_variables.json"))
            throw new System.Exception("Missing Global Variables. Please finish the setup in the launcher.");
        GlobalEngineVariables.CreateFromJSON("..\\engine_variables.json");
        if (!GlobalEngineVariables.checkIntegrity())
            throw new System.Exception("Global Variables Invalid.");

        main_menu.state = MainMenu.State.stateLoadingScreenLoading;
        await StartLoading();
        main_menu.loading_spinner.enabled = false;
        ui_manager.please_wait_text.enabled = false;
        ui_manager.press_space_text.enabled = true;
        main_menu.state = MainMenu.State.stateLoadingScreenAwait;

        /*if (GlobalEngineVariables.game_mode == "quidditch")
        {
            if (GlobalEngineVariables.goal_chain != null)
            {
                main_menu.main_menu_buttons.SetActive(false);
                main_menu.quidditch_menu_buttons.SetActive(false);
                main_menu.starting_goal_chain = GlobalEngineVariables.goal_chain;
                main_menu.starting_goal = GlobalEngineVariables.goal;
            }




        }*/

    }
}