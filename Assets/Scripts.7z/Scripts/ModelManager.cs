﻿
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEngine;
using UnityEngine.UI;
using Newtonsoft.Json;
using System.Threading.Tasks;
using UnityEngine.Networking;
public class ModelManager : MonoBehaviour
{

    static string[] known_shaders_array = { "ubershader", "ocean_vfx", "skinshader", "neweyeshader", "hairshader", "houserobeshader", "houseclothshader", "clothshader", "SimpleColor", "simpleColor", "glow_vfx", "skyceilingshader_vfx", "fire02_vfx", "panningfalloff", "eyeballshader", "SimpleTexture", "lightrays_vfx", "shadowplane_vfx", "vertecolor_vfx", "avatarfaceshader", "avatarskinshader", "avatarhairshader", "warpfloor_vfx", "ghost_vfx", "ghostfade_vfx", "outfitshader", "watershader", "panningb_vfx", "eyeballshader", "quidditchshader", "AnimateUV", "eyeshader", "dustmotes_vfx", "houseubershader", "FalloffAnimated", "patronusoutfit_vfx", "crowd_vfx", "transition_vfx", "panningbfresnel_vfx"};

	static List<string> known_shaders = new List<string>(known_shaders_array);

	static string[] real_shaders = { "ubershader", "ubershader_transparent", "ocean_vfx", "skinshader", "neweyeshader", "hairshader", "houserobeshader", "houseclothshader", "clothshader", "SimpleColor", "glow_vfx", "skyceilingshader_vfx", "fire02_vfx", "eyeshader", "lightrays_vfx", "SimpleTexture", "panningfalloff", "shadowplane_vfx", "vertecolor_vfx", "avatarfaceshader", "avatarskinshader", "avatarhairshader", "warpfloor_vfx", "ghost_vfx", "ghostfade_vfx", "outfitshader", "watershader", "panningb_vfx", "eyeballshader", "quidditchshader", "AnimateUV", "dustmotes_vfx", "FalloffAnimated", "patronusoutfit_vfx", "crowd_vfx", "transition_vfx", "panningbfresnel_vfx"};

	static string[] transparent_shaders_array = { "ocean_vfx", "glow_vfx", "lightrays_vfx", "shadowplane_vfx", "vertecolor_vfx", "panningb_vfx", "panningfalloff", "fire02_vfx", "ubershader_transparent", "AnimateUV", "dustmotes_vfx", "FalloffAnimated", "SimpleColor", "panningbfresnel_vfx"};
	static List<string> transparent_shaders = new List<string>(transparent_shaders_array);

	static Material transparent_material;
	static Material opaque_material;
	static Dictionary<string, Shader> shader_dict;// = new Dictionary<string, Shader>();

	static string patch_text;

	public static Vector3 ExtractTranslationFromMatrix(ref Matrix4x4 matrix)
	{
		Vector3 translate;
		translate.x = matrix.m03;
		translate.y = matrix.m13;
		translate.z = matrix.m23;
		return translate;
	}
	public static Quaternion ExtractRotationFromMatrix(ref Matrix4x4 matrix)
	{
		Vector3 forward;
		forward.x = matrix.m02;
		forward.y = matrix.m12;
		forward.z = matrix.m22;

		Vector3 upwards;
		upwards.x = matrix.m01;
		upwards.y = matrix.m11;
		upwards.z = matrix.m21;

		return Quaternion.LookRotation(forward, upwards);
	}
	public static Vector3 ExtractScaleFromMatrix(ref Matrix4x4 matrix)
	{
		Vector3 scale;
		scale.x = new Vector4(matrix.m00, matrix.m10, matrix.m20, matrix.m30).magnitude;
		scale.y = new Vector4(matrix.m01, matrix.m11, matrix.m21, matrix.m31).magnitude;
		scale.z = new Vector4(matrix.m02, matrix.m12, matrix.m22, matrix.m32).magnitude;
		return scale;
	}

	[System.Serializable]
	public class c3t
	{
		public string version;
		public string id;

		[System.Serializable]
		public class Mesh
		{
			[System.Serializable]
			public class Attribute
			{
				public int size;
				public string type;
				public string attribute;
			}
			public Attribute[] attributes;
			public float[] vertices;
			public List<Vector3> VERTEX_ATTRIB_POSITION;
			public List<Vector3> VERTEX_ATTRIB_NORMAL;
			public List<Vector3> VERTEX_ATTRIB_SOFT_NORMAL;
			public List<Vector2> VERTEX_ATTRIB_TEX_COORD;
			public List<Vector2> VERTEX_ATTRIB_TEX_COORD1;
			public List<Vector2> VERTEX_ATTRIB_TEX_COORD2;
			public List<Vector2> VERTEX_ATTRIB_TEX_COORD3;
			public List<Vector4> VERTEX_ATTRIB_BLEND_WEIGHT;
			public List<Vector4> VERTEX_ATTRIB_BLEND_INDEX;
			public List<Color> VERTEX_ATTRIB_COLOR;

			[System.Serializable]
			public class Part
			{
				public string id;
				public string type;
				public int[] indices;
				public float[] aabb;
			}
			public Part[] parts;
		}
		public Mesh[] meshes;
		[System.Serializable]
		public class Material
		{
			public string id;
			public float[] ambient;
			public float[] diffuse;
			public float[] emissive;
			public float opacity;
		}
		public Material[] materials;

		[System.Serializable]
		public class Node
		{
			public string id;
			public bool skeleton;
			public float[] transform;
			[System.Serializable]
			public class Part
			{
				public string meshpartid;
				public string materialid;
				[System.Serializable]
				public class Bone
				{
					public string node;
					public float[] transform;
				}
				public Bone[] bones;
			}
			public Part[] parts;
			[SerializeReference]
			public Node[] children;
		}
		public Node[] nodes;
		[System.Serializable]
		public class Animation
		{
			public string id;
			public float length;
			[System.Serializable]
			public class Bone
			{
				public string boneId;
				[System.Serializable]
				public class Keyframe
				{
					public float keytime;
					public float[] rotation;
					public float[] scale;
					public float[] translation;
				}
				public Keyframe[] keyframes;
			}
			public Bone[] bones;
			public Dictionary<string, Bone> bone_dict;
		}
		public Animation[] animations;

		public static c3t CreateFromJSON(string file)
		{
			StreamReader reader = new StreamReader(file);
			string content = reader.ReadToEnd();
			reader.Close();
			return JsonConvert.DeserializeObject<c3t>(content);
		}
	}

	public static int c3bGetMeshAttribute(ref byte[] file, ref c3t.Mesh.Attribute new_attribute, ref int pointer)
	{
		new_attribute.size = System.BitConverter.ToInt32(file, pointer);
		pointer += 4;
		int num_type_letters = System.BitConverter.ToInt32(file, pointer);
		pointer += 4;
		new_attribute.type = Encoding.UTF8.GetString(file, pointer, num_type_letters);
		pointer += num_type_letters;
		int num_attribute_letters = System.BitConverter.ToInt32(file, pointer);
		pointer += 4;
		new_attribute.attribute = Encoding.UTF8.GetString(file, pointer, num_attribute_letters);
		pointer += num_attribute_letters;
		return pointer;
	}

	public static int c3bGetMeshVertices(ref byte[] file, ref c3t.Mesh new_mesh, ref int pointer)
	{
		int num_vertices = System.BitConverter.ToInt32(file, pointer);
		pointer += 4;
		new_mesh.vertices = new float[num_vertices];
		for (int vertex = 0; vertex < num_vertices; vertex++)
		{
			new_mesh.vertices[vertex] = System.BitConverter.ToSingle(file, pointer + vertex * 4);
		}
		pointer += num_vertices * 4;
		return pointer;
	}
	public static int c3bGetMeshPart(ref byte[] file, ref c3t.Mesh.Part new_part, ref int pointer)
	{
		int num_name_letters = System.BitConverter.ToInt32(file, pointer);
		pointer += 4;
		new_part.id = Encoding.UTF8.GetString(file, pointer, num_name_letters);
		pointer += num_name_letters;
		new_part.type = "TRIANGLES";
		int num_part_indices = System.BitConverter.ToInt32(file, pointer);
		pointer += 4;
		new_part.indices = new int[num_part_indices];
		for (int part_index = 0; part_index < num_part_indices; part_index++)
		{
			new_part.indices[part_index] = System.BitConverter.ToInt16(file, pointer + part_index * 2);
		}
		pointer += num_part_indices * 2;
		new_part.aabb = new float[6];
		for (int i = 0; i < 6; i++)
		{
			new_part.aabb[i] = System.BitConverter.ToSingle(file, pointer + i * 4);
		}
		return pointer + 24;
	}

	public static int c3bGetMaterial(ref byte[] file, ref c3t.Material new_material, ref int pointer)
	{
		int num_name_letters = System.BitConverter.ToInt32(file, pointer);
		pointer += 4;
		new_material.id = Encoding.UTF8.GetString(file, pointer, num_name_letters);
		pointer += num_name_letters;
		new_material.ambient = new float[3];
		for (int a = 0; a < 3; a++)
        {
			new_material.ambient[a] = System.BitConverter.ToSingle(file, pointer + a * 4);
		}
		pointer += 12;
		new_material.diffuse = new float[3];
		for (int d = 0; d < 3; d++)
		{
			new_material.diffuse[d] = System.BitConverter.ToSingle(file, pointer + d * 4);
		}
		pointer += 12;
		new_material.emissive = new float[3];
		for (int e = 0; e < 3; e++)
		{
			new_material.emissive[e] = System.BitConverter.ToSingle(file, pointer + e * 4);
		}
		pointer += 12;
		new_material.opacity = System.BitConverter.ToSingle(file, pointer);
		pointer += 4;
		pointer += 16;

		int num_textures = System.BitConverter.ToInt32(file, pointer);
		pointer += 4;
		for (int i = 0; i< num_textures; i++)
        {
			int id_letters = System.BitConverter.ToInt32(file, pointer);
			pointer += 4;
			pointer += id_letters;
			int filename_letters = System.BitConverter.ToInt32(file, pointer);
			pointer += 4;
			pointer += filename_letters;
			pointer += 16;
			int type_letters = System.BitConverter.ToInt32(file, pointer);
			pointer += 4;
			pointer += type_letters;
			int wrapModeU = System.BitConverter.ToInt32(file, pointer);
			pointer += 4;
			pointer += wrapModeU;
			int wrapModeV = System.BitConverter.ToInt32(file, pointer);
			pointer += 4;
			pointer += wrapModeV;
		}



		return pointer;
	}

	public static int c3bGetNodePartBone(ref byte[] file, ref c3t.Node.Part.Bone new_bone, ref int pointer)
    {
		int num_node_letters = System.BitConverter.ToInt32(file, pointer);
		pointer += 4;
		new_bone.node = Encoding.UTF8.GetString(file, pointer, num_node_letters);
		pointer += num_node_letters;

		new_bone.transform = new float[16];
		for (int i = 0; i < 16; i++)
        {
			new_bone.transform[i] = System.BitConverter.ToSingle(file, pointer + i * 4);
		}
		pointer += 64;
		return pointer;
    }
	public static int c3bGetNodeUvMapping(ref byte[] file, ref int pointer)
    {
		int num_uv = System.BitConverter.ToInt32(file, pointer);
		pointer += 4;
		pointer += 4 * num_uv;
		return pointer;
	}

	public static int c3bGetNodePart(ref byte[] file, ref c3t.Node.Part new_part, ref int pointer)
    {
		int num_meshpartid_letters = System.BitConverter.ToInt32(file, pointer);
		pointer += 4;
		new_part.meshpartid = Encoding.UTF8.GetString(file, pointer, num_meshpartid_letters);
		pointer += num_meshpartid_letters;

		int num_materialid_letters = System.BitConverter.ToInt32(file, pointer);
		pointer += 4;
		new_part.materialid = Encoding.UTF8.GetString(file, pointer, num_materialid_letters);
		pointer += num_materialid_letters;


		int num_bones = System.BitConverter.ToInt32(file, pointer);
		pointer += 4;

		if (num_bones != 0)
        {
			new_part.bones = new c3t.Node.Part.Bone[num_bones];
			for (int bone = 0; bone < num_bones; bone++)
            {
				c3t.Node.Part.Bone new_bone = new c3t.Node.Part.Bone();
				c3bGetNodePartBone(ref file, ref new_bone, ref pointer);
				new_part.bones[bone] = new_bone;
			}
        }

		int num_uvmapping = System.BitConverter.ToInt32(file, pointer);
		pointer += 4;
		for (int i = 0; i < num_uvmapping; i++)
        {
			pointer = c3bGetNodeUvMapping(ref file, ref pointer);
        }

		return pointer;
    }

	public static int c3bGetNode(ref byte[] file, ref c3t.Node new_node, ref int pointer)
    {
		int num_name_letters = System.BitConverter.ToInt32(file, pointer);
		pointer += 4;
		new_node.id = Encoding.UTF8.GetString(file, pointer, num_name_letters);
		pointer += num_name_letters;
		new_node.skeleton = System.BitConverter.ToBoolean(file, pointer);
		pointer += 1;

		new_node.transform = new float[16];
		for (int i = 0; i < 16; i++)
        {
			new_node.transform[i] = System.BitConverter.ToSingle(file, pointer + i * 4);
		}
		pointer += 64;

		int num_parts = System.BitConverter.ToInt32(file, pointer);
		pointer += 4;
		if (num_parts != 0)
        {
			new_node.parts = new c3t.Node.Part[num_parts];
			for (int part = 0; part < num_parts; part++)
            {
				c3t.Node.Part new_part = new c3t.Node.Part();
				pointer = c3bGetNodePart(ref file, ref new_part, ref pointer);
				new_node.parts[part] = new_part;
			}
        }

		int num_children = System.BitConverter.ToInt32(file, pointer);
		pointer += 4;
		if (num_children != 0)
		{
			new_node.children = new c3t.Node[num_children];
			for (int part = 0; part < num_children; part++)
			{
				c3t.Node new_child = new c3t.Node();
				pointer = c3bGetNode(ref file, ref new_child, ref pointer);
				new_node.children[part] = new_child;
			}
		}

		return pointer;
    }

	public static int c3bGetAnimationBoneKeyframe(ref byte[] file, ref c3t.Animation.Bone.Keyframe new_keyframe, ref int pointer)
    {
		new_keyframe.keytime = System.BitConverter.ToSingle(file, pointer);
		pointer += 4;

		int mystery_byte = file[pointer];
		
		bool rotate = false;
		bool translate = false;
		bool scale = false;



        switch (mystery_byte)
        {
			case 1:
				rotate = true;
				break;
			case 2:
				scale = true;
				break;
			case 3:
				rotate = true;
				scale = true;
				break;
			case 4:
				translate = true;
				break;
			case 5:
				rotate = true;
				translate = true;
				break;
			case 6:
				scale = true;
				translate = true;
				break;
			case 7:
				rotate = true;
				scale = true;
				translate = true;
				break;
		}
		pointer += 1;

		if (rotate == true)
        {
			new_keyframe.rotation = new float[4];
			for (int r = 0; r < 4; r++)
            {
				new_keyframe.rotation[r] = System.BitConverter.ToSingle(file, pointer + r * 4);
			}
			pointer += 16;
        }
		if (scale == true)
		{
			new_keyframe.scale = new float[3];
			for (int s = 0; s < 3; s++)
			{
				new_keyframe.scale[s] = System.BitConverter.ToSingle(file, pointer + s * 4);
			}
			pointer += 12;
		}
		if (translate == true)
		{
			new_keyframe.translation = new float[3];
			for (int t = 0; t < 3; t++)
			{
				new_keyframe.translation[t] = System.BitConverter.ToSingle(file, pointer + t * 4);
			}
			pointer += 12;
		}
		return pointer;
	}


	public static int c3bGetAnimationBone(ref byte[] file, ref c3t.Animation.Bone new_bone, ref int pointer)
    {
		int num_name_letters = System.BitConverter.ToInt32(file, pointer);
		pointer += 4;
		new_bone.boneId = Encoding.UTF8.GetString(file, pointer, num_name_letters);
		pointer += num_name_letters;
		int num_keyframes = System.BitConverter.ToInt32(file, pointer);
		pointer += 4;
		new_bone.keyframes = new c3t.Animation.Bone.Keyframe[num_keyframes];
		for (int keyframe = 0; keyframe < num_keyframes; keyframe++)
        {
			c3t.Animation.Bone.Keyframe new_keyframe = new c3t.Animation.Bone.Keyframe();
			pointer = c3bGetAnimationBoneKeyframe(ref file, ref new_keyframe, ref pointer);
			new_bone.keyframes[keyframe] = new_keyframe;
		}
		return pointer;
	}


	public static int c3bGetAnimation(ref byte[] file, ref c3t.Animation new_animation, ref int pointer)
    {
		int num_name_letters = System.BitConverter.ToInt32(file, pointer);
		pointer += 4;
		new_animation.id = Encoding.UTF8.GetString(file, pointer, num_name_letters);
		pointer += num_name_letters;
		new_animation.length = System.BitConverter.ToSingle(file, pointer);
		pointer += 4;
		int num_bones = System.BitConverter.ToInt32(file, pointer);
		pointer += 4;
		new_animation.bones = new c3t.Animation.Bone[num_bones];
		for (int bone = 0; bone < num_bones; bone++)
        {
			c3t.Animation.Bone new_bone = new c3t.Animation.Bone();
			pointer = c3bGetAnimationBone(ref file, ref new_bone, ref pointer);
			new_animation.bones[bone] = new_bone;
        }
		return pointer;
    }


	public static c3t loadc3b(string file_name)
    {
		byte[] file = File.ReadAllBytes(file_name);
		c3t model_c3t = new c3t();
		int pointer = 6;
		int num_unknown = System.BitConverter.ToInt32(file, pointer);
		pointer += 4;
		for (int offset = 0; offset < num_unknown; offset++)
        {

			pointer += System.BitConverter.ToInt32(file, pointer);
			pointer += 12;
		}
		int num_meshes = System.BitConverter.ToInt32(file, pointer);
		pointer += 4;
		model_c3t.meshes = new c3t.Mesh[num_meshes];
		for (int mesh = 0; mesh < num_meshes; mesh++)
        {
			c3t.Mesh new_mesh = new c3t.Mesh();
			int num_mesh_attributes = System.BitConverter.ToInt32(file, pointer);
			pointer += 4;
			new_mesh.attributes = new c3t.Mesh.Attribute[num_mesh_attributes];
			for (int mesh_attribute = 0; mesh_attribute < num_mesh_attributes; mesh_attribute++)
            {
				c3t.Mesh.Attribute new_attribute = new c3t.Mesh.Attribute();
				pointer = c3bGetMeshAttribute(ref file, ref new_attribute, ref pointer);
				new_mesh.attributes[mesh_attribute] = new_attribute;
            }

			pointer = c3bGetMeshVertices(ref file, ref new_mesh, ref pointer);

			int num_mesh_parts = System.BitConverter.ToInt32(file, pointer);
			pointer += 4;
			new_mesh.parts = new c3t.Mesh.Part[num_mesh_parts];
			for (int part = 0; part < num_mesh_parts; part++)
            {
				c3t.Mesh.Part new_part = new c3t.Mesh.Part();
				pointer = c3bGetMeshPart(ref file, ref new_part, ref pointer);
				new_mesh.parts[part] = new_part;
            }
			model_c3t.meshes[mesh] = new_mesh;
		}

		int num_materials = System.BitConverter.ToInt32(file, pointer);
		pointer += 4;
		model_c3t.materials = new c3t.Material[num_materials];
		for (int material = 0; material < num_materials; material++)
        {
			c3t.Material new_material = new c3t.Material();
			pointer = c3bGetMaterial(ref file, ref new_material, ref pointer);
			model_c3t.materials[material] = new_material;
        }

		int num_nodes = System.BitConverter.ToInt32(file, pointer);
		pointer += 4;
		model_c3t.nodes = new c3t.Node[num_nodes];
		for (int node = 0; node < num_nodes; node++)
		{
			c3t.Node new_node = new c3t.Node();
			pointer = c3bGetNode(ref file, ref new_node, ref pointer);
			model_c3t.nodes[node] = new_node;
		}

		List<c3t.Animation> animations = new List<c3t.Animation>();

		while (pointer < file.Length)
        {
			c3t.Animation new_animation = new c3t.Animation();
			animations.Add(new_animation);
			pointer = c3bGetAnimation(ref file, ref new_animation, ref pointer);
        }

		if (animations.Count > 0)
        {
			model_c3t.animations = animations.ToArray();
		}

		return model_c3t;
	}

	

	public static c3t loadc3t(string name, string file_type)
	{
		Config3DModel c3m = null;
		if (name[0] == 'c')
		{
			c3m = Configs.config_character_model;
		}
		else if (name[0] == 'p')
		{
			c3m = Configs.config_prop_model;
		}
		else if (name[0] == 'b')
		{
			c3m = Configs.config_environment_model;
		}
		else if (name[0] == 'o')
		{
			c3m = Configs.config_outfit_model;
		}
		else if (name[0] == 'f')
		{
			c3m = Configs.config_fx;
		}
		else
		{
			Log.write("invalid load c3t " + name);
			return null;
		}


		if (name == "")
		{
			Log.write("c3t no name");
			return null;
		}
		if (name == "o_Female_ForestFormal_FULL1_skin")
		{
			name = "o_Female_ForestFormal_FULL_skin";
		}
		if (!c3m.ModelConfig.ContainsKey(name))
		{
			Log.write("Not c3t config entry for " + name);
			return null;
		}

		string file_name = c3m.ModelConfig[name].jsonData[0].mesh;
		file_name = file_name.Substring(0, file_name.Length - 4) + "." + file_type;

		if (System.IO.Directory.Exists("patches\\models"))
		{
			if (System.IO.File.Exists("patches\\models\\" + file_name.Substring(0, file_name.Length - 4) + ".c3b"))
			{
				Debug.Log("FOUnd PATCH for model " + file_name);
				return loadc3b("patches\\models\\" + file_name.Substring(0, file_name.Length - 4) + ".c3b");
			}
		}

		if (System.IO.File.Exists(GlobalEngineVariables.assets_folder + "\\models\\" + file_name))
		{   //Try to find specific file version
			if (file_type == "c3b")
			{
				return loadc3b(GlobalEngineVariables.assets_folder + "\\models\\" + file_name);
			}
			else if (file_type == "c3t")
			{
				return c3t.CreateFromJSON(GlobalEngineVariables.assets_folder + "\\models\\" + file_name);
			}
		}
		Debug.LogError("Couldn't find " + GlobalEngineVariables.assets_folder + "\\models\\" + file_name);
		Log.write("Couldn't find " + GlobalEngineVariables.assets_folder + "\\models\\" + file_name, "error");
		return null;
	}


	public static void processPoseSkeletonChild(c3t.Node node, Transform parent, ref List<Transform> bones, ref List<Matrix4x4> bindPoses)
    {

		bones.Add(new GameObject(node.id).transform);
		int bone_index = bones.Count - 1;

		Matrix4x4 child_transform_matrix = new Matrix4x4(new Vector4(node.transform[0], node.transform[1], node.transform[2], node.transform[3]), new Vector4(node.transform[4], node.transform[5], node.transform[6], node.transform[7]), new Vector4(node.transform[8], node.transform[9], node.transform[10], node.transform[11]), new Vector4(node.transform[12], node.transform[13], node.transform[14], node.transform[15]));

		bones[bone_index].parent = parent;
		bones[bone_index].localRotation = ExtractRotationFromMatrix(ref child_transform_matrix);
		bones[bone_index].localPosition = ExtractTranslationFromMatrix(ref child_transform_matrix);
		//bones[bone_index].localScale = ExtractScaleFromMatrix(ref child_transform_matrix); //Breaks shit


		bones[bone_index].localPosition = new Vector3(bones[bone_index].localPosition.x * -1, bones[bone_index].localPosition.y, bones[bone_index].localPosition.z);
		bones[bone_index].localRotation = Quaternion.Euler(new Vector3(bones[bone_index].localRotation.eulerAngles.x, bones[bone_index].localRotation.eulerAngles.y * -1, bones[bone_index].localRotation.eulerAngles.z * -1));

		bindPoses.Add(bones[bones.Count - 1].worldToLocalMatrix);


		if (node.children != null)
		{
			foreach (c3t.Node child in node.children)
			{
				processPoseSkeletonChild(child, bones[bone_index], ref bones, ref bindPoses);
			}
		}
		return;
    }


	public static string getPatchedName(string name){

		if (name == "o_Female_ForestFormal_FULL1")
		{
			name = "o_Female_ForestFormal_FULL";

		}
		Debug.Log(name);
		if (patch_text.Contains("patch:" + name))
		{

			int patch_index = patch_text.IndexOf("patch:" + name) + ("patch:" + name).Length + 1;
			Debug.Log("patch_index " + patch_index);

			Debug.Log("semicolon_index " + patch_text.IndexOf(';', patch_index));
			name = patch_text.Substring(patch_index, patch_text.IndexOf(';', patch_index) - patch_index);
			Debug.LogWarning("patched " + name);
		}
		return name;
	}

	public static Dictionary<string, Transform> loadModel(ref GameObject go, string name, string type, Dictionary<string, Transform> parent_bones = null) {

		name = getPatchedName(name);


		c3t model = loadc3t(name, "c3b");

		if (model == null)
		{
			Debug.LogError("Model loaded null " + name);
			Log.write("Model loaded null " + name, "error");
			return null;
		}

		#region mesh data

		go = new GameObject();
		go.name = name;

		foreach (c3t.Mesh c3t_mesh in model.meshes)
		{

			int stride = 0;
			foreach (c3t.Mesh.Attribute attrib in c3t_mesh.attributes)
			{
				switch (attrib.attribute)
				{
					case "VERTEX_ATTRIB_POSITION":
						c3t_mesh.VERTEX_ATTRIB_POSITION = new List<Vector3>();
						break;
					case "VERTEX_ATTRIB_NORMAL":
						c3t_mesh.VERTEX_ATTRIB_NORMAL = new List<Vector3>();
						break;
					case "VERTEX_ATTRIB_SOFT_NORMAL":
						c3t_mesh.VERTEX_ATTRIB_SOFT_NORMAL = new List<Vector3>();
						break;
					case "VERTEX_ATTRIB_TEX_COORD":
						c3t_mesh.VERTEX_ATTRIB_TEX_COORD = new List<Vector2>();
						break;
					case "VERTEX_ATTRIB_TEX_COORD1":
						c3t_mesh.VERTEX_ATTRIB_TEX_COORD1 = new List<Vector2>();
						break;
					case "VERTEX_ATTRIB_TEX_COORD2":
						c3t_mesh.VERTEX_ATTRIB_TEX_COORD2 = new List<Vector2>();
						break;
					case "VERTEX_ATTRIB_TEX_COORD3":
						c3t_mesh.VERTEX_ATTRIB_TEX_COORD3 = new List<Vector2>();
						break;
					case "VERTEX_ATTRIB_BLEND_WEIGHT":
						c3t_mesh.VERTEX_ATTRIB_BLEND_WEIGHT = new List<Vector4>();
						break;
					case "VERTEX_ATTRIB_BLEND_INDEX":
						c3t_mesh.VERTEX_ATTRIB_BLEND_INDEX = new List<Vector4>();
						break;
					case "VERTEX_ATTRIB_COLOR":
						c3t_mesh.VERTEX_ATTRIB_COLOR = new List<Color>();
						break;
					default:
						//Debug.Log("ERROR, UNKNOWN VERTEX ATTRIB " + attrib.attribute);
						break;
				}
				stride += attrib.size;
			}

			for (int v = 0; v < c3t_mesh.vertices.Length; v += stride)
			{
				int offset = 0;
				foreach (c3t.Mesh.Attribute attrib in c3t_mesh.attributes)
				{
					switch (attrib.attribute)
					{
						case "VERTEX_ATTRIB_POSITION":
							c3t_mesh.VERTEX_ATTRIB_POSITION.Add(new Vector3(c3t_mesh.vertices[v + offset] * -1, c3t_mesh.vertices[v + offset + 1], c3t_mesh.vertices[v + offset + 2]));
							break;
						case "VERTEX_ATTRIB_NORMAL":
							c3t_mesh.VERTEX_ATTRIB_NORMAL.Add(new Vector3(-c3t_mesh.vertices[v + offset], c3t_mesh.vertices[v + offset + 1], c3t_mesh.vertices[v + offset + 2]));
							break;
						case "VERTEX_ATTRIB_SOFT_NORMAL":
							c3t_mesh.VERTEX_ATTRIB_SOFT_NORMAL.Add(new Vector3(c3t_mesh.vertices[v + offset], c3t_mesh.vertices[v + offset + 1], c3t_mesh.vertices[v + offset + 2]));
							break;
						case "VERTEX_ATTRIB_TEX_COORD":
							c3t_mesh.VERTEX_ATTRIB_TEX_COORD.Add(new Vector2(c3t_mesh.vertices[v + offset], c3t_mesh.vertices[v + offset + 1]));
							break;
						case "VERTEX_ATTRIB_TEX_COORD1":
							c3t_mesh.VERTEX_ATTRIB_TEX_COORD1.Add(new Vector2(c3t_mesh.vertices[v + offset], c3t_mesh.vertices[v + offset + 1]));
							break;
						case "VERTEX_ATTRIB_TEX_COORD2":
							c3t_mesh.VERTEX_ATTRIB_TEX_COORD2.Add(new Vector2(c3t_mesh.vertices[v + offset], c3t_mesh.vertices[v + offset + 1]));
							break;
						case "VERTEX_ATTRIB_TEX_COORD3":
							c3t_mesh.VERTEX_ATTRIB_TEX_COORD3.Add(new Vector2(c3t_mesh.vertices[v + offset], c3t_mesh.vertices[v + offset + 1]));
							break;
						case "VERTEX_ATTRIB_BLEND_WEIGHT":
							c3t_mesh.VERTEX_ATTRIB_BLEND_WEIGHT.Add(new Vector4(c3t_mesh.vertices[v + offset], c3t_mesh.vertices[v + offset + 1], c3t_mesh.vertices[v + offset + 2], c3t_mesh.vertices[v + offset + 3]));
							break;
						case "VERTEX_ATTRIB_BLEND_INDEX":
							c3t_mesh.VERTEX_ATTRIB_BLEND_INDEX.Add(new Vector4(c3t_mesh.vertices[v + offset], c3t_mesh.vertices[v + offset + 1], c3t_mesh.vertices[v + offset + 2], c3t_mesh.vertices[v + offset + 3]));
							break;
						case "VERTEX_ATTRIB_COLOR":
							c3t_mesh.VERTEX_ATTRIB_COLOR.Add(new Color(c3t_mesh.vertices[v + offset], c3t_mesh.vertices[v + offset + 1], c3t_mesh.vertices[v + offset + 2], c3t_mesh.vertices[v + offset + 3]));
							break;
						default:
							//Debug.Log("ERROR, UNKNOWN VERTEX ATTRIB " + attrib.attribute);
							break;
					}
					offset += attrib.size;
				}
			}
		}
        #endregion
        #region skeleton nodes

		List<GameObject> child_go = new List<GameObject>();
		List<Transform> pose_bones = new List<Transform>();
		Dictionary<string, Transform> pose_bone_dict = new Dictionary<string, Transform>();
		List<Matrix4x4> bindPoses = new List<Matrix4x4>();
		Dictionary<string, Matrix4x4> bindposes_dict = new Dictionary<string, Matrix4x4>();


		foreach (c3t.Node node in model.nodes)
        {
			if (node.skeleton == true)
			{
				GameObject amt = new GameObject("Armature");
				amt.transform.parent = go.transform;

				Matrix4x4 jt_all_bind_matrix = new Matrix4x4(new Vector4(node.transform[0], node.transform[1], node.transform[2], node.transform[3]), new Vector4(node.transform[4], node.transform[5], node.transform[6], node.transform[7]), new Vector4(node.transform[8], node.transform[9], node.transform[10], node.transform[11]), new Vector4(node.transform[12], node.transform[13], node.transform[14], node.transform[15]));


				Matrix4x4 transform_matrix = Matrix4x4.identity;

				transform_matrix[0] = jt_all_bind_matrix[0]; //only use jt_all_bind scale
				transform_matrix[5] = jt_all_bind_matrix[5];
				transform_matrix[10] = jt_all_bind_matrix[10];


				pose_bones.Add(new GameObject(node.id).transform);
				pose_bones[0].parent = amt.transform;
				pose_bones[0].localRotation = ExtractRotationFromMatrix(ref transform_matrix);//Quaternion.identity;
				pose_bones[0].localPosition = ExtractTranslationFromMatrix(ref transform_matrix); //Vector3.zero;
				pose_bones[0].localScale = ExtractScaleFromMatrix(ref transform_matrix);



				bindPoses.Add(pose_bones[0].worldToLocalMatrix);
				foreach (c3t.Node child in node.children)
				{
					processPoseSkeletonChild(child, pose_bones[0].transform, ref pose_bones, ref bindPoses);
				}
			}
		}

		for(int t = 0; t < pose_bones.Count; t++)
        {
			pose_bone_dict[pose_bones[t].gameObject.name] = pose_bones[t];
			bindposes_dict[pose_bones[t].gameObject.name] = bindPoses[t];
        }

		#endregion

		Config3DModel c3m = null;
		if (name[0] == 'c')
		{
			c3m = Configs.config_character_model;
		}
		else if (name[0] == 'p')
		{
			c3m = Configs.config_prop_model;
		}
		else if (name[0] == 'b')
		{
			c3m = Configs.config_environment_model;
		}
		else if (name[0] == 'o')
		{
			c3m = Configs.config_outfit_model;
		}
		else if (name[0] == 'f')
        {
			c3m = Configs.config_fx;
        }

		Dictionary<string, Texture2D> all_textures = new Dictionary<string, Texture2D>();
		if (!c3m.ModelConfig.ContainsKey(name))
        {
			name = "o_Female_ForestFormal_FULL_skin";
			Debug.Log(name);
        }

		foreach (string tex in c3m.ModelConfig[name].jsonData[0].neededTextureKeys)
		{
			if (GameStart.game_state.loaded_textures.ContainsKey(tex))
			{
				all_textures[tex] = GameStart.game_state.loaded_textures[tex];
			}
			else
			{

				//all_textures[tex] = TextureManager.loadTexturePng(tex, "models\\" + name);
				all_textures[tex] = TextureManager.loadTextureDDS(tex);
				GameStart.game_state.loaded_textures[tex] = all_textures[tex];
			}
		}

		//all_textures = TextureManager.test1(c3m, c3m.ModelConfig[name].jsonData[0].neededTextureKeys, "models\\" + name).GetAwaiter().GetResult();

		//TextureManager.DownloadMultipleFilesAsync(all_textures, c3m.ModelConfig[name].jsonData[0].neededTextureKeys, "models\\" + name).Wait();

		#region mesh nodes

		foreach (c3t.Node node in model.nodes)
		{
			if (node.skeleton == false)
			{
				Matrix4x4 node_transform_matrix = new Matrix4x4(new Vector4(node.transform[0], node.transform[1], node.transform[2], node.transform[3]), new Vector4(node.transform[4], node.transform[5], node.transform[6], node.transform[7]), new Vector4(node.transform[8], node.transform[9], node.transform[10], node.transform[11]), new Vector4(node.transform[12], node.transform[13], node.transform[14], node.transform[15]));
				
				if (node.parts != null)
                {
					foreach (c3t.Node.Part node_part in node.parts)
					{
						GameObject node_go = new GameObject();
						node_go.transform.parent = go.transform;
						Vector3 extracted_translation = ExtractTranslationFromMatrix(ref node_transform_matrix);
						node_go.transform.position = new Vector3(-extracted_translation.x, extracted_translation.y, extracted_translation.z);
						Quaternion extracted_rotation = ExtractRotationFromMatrix(ref node_transform_matrix);
						node_go.transform.rotation = Quaternion.Euler(new Vector3(extracted_rotation.eulerAngles.x, -extracted_rotation.eulerAngles.y, -extracted_rotation.eulerAngles.z));
						node_go.transform.localScale = ExtractScaleFromMatrix(ref node_transform_matrix);
						node_go.name = node.id;


						c3t.Mesh c3t_mesh = null;
						c3t.Mesh.Part c3t_part = null;


						foreach (c3t.Mesh _mesh in model.meshes)
						{
							foreach (c3t.Mesh.Part c3t_mesh_part in _mesh.parts)
							{
								if (node_part.meshpartid == c3t_mesh_part.id)
								{
									c3t_mesh = _mesh;
									c3t_part = c3t_mesh_part;
								}
							}
						}

						if (c3t_part == null || c3t_mesh == null)
						{
							Debug.Log("Failed to find mesh part: " + node_part.meshpartid);
						}
						else
						{
							Mesh mesh = new Mesh();

							if (c3t_mesh.VERTEX_ATTRIB_POSITION != null)
								mesh.vertices = c3t_mesh.VERTEX_ATTRIB_POSITION.ToArray();
							if (c3t_mesh.VERTEX_ATTRIB_TEX_COORD != null)
								mesh.uv = c3t_mesh.VERTEX_ATTRIB_TEX_COORD.ToArray();
							if (c3t_mesh.VERTEX_ATTRIB_TEX_COORD1 != null)
								mesh.uv2 = c3t_mesh.VERTEX_ATTRIB_TEX_COORD1.ToArray();
							if (c3t_mesh.VERTEX_ATTRIB_TEX_COORD2 != null)
								mesh.uv3 = c3t_mesh.VERTEX_ATTRIB_TEX_COORD2.ToArray();
							if (c3t_mesh.VERTEX_ATTRIB_TEX_COORD3 != null)
								mesh.uv4 = c3t_mesh.VERTEX_ATTRIB_TEX_COORD3.ToArray();
							if (c3t_mesh.VERTEX_ATTRIB_COLOR != null)
								mesh.colors = c3t_mesh.VERTEX_ATTRIB_COLOR.ToArray();
							if (c3t_mesh.VERTEX_ATTRIB_NORMAL != null)
								mesh.normals = c3t_mesh.VERTEX_ATTRIB_NORMAL.ToArray();

							if (c3t_part.indices != null)
							{
								mesh.triangles = c3t_part.indices;
							}

							BoneWeight[] weights = new BoneWeight[mesh.vertexCount];

							if (c3t_mesh.VERTEX_ATTRIB_BLEND_INDEX != null)
							{
								for (int i = 0; i < mesh.vertexCount; i++)
								{
									weights[i].boneIndex0 = (int)c3t_mesh.VERTEX_ATTRIB_BLEND_INDEX[i][0];
									weights[i].boneIndex1 = (int)c3t_mesh.VERTEX_ATTRIB_BLEND_INDEX[i][1];
									weights[i].boneIndex2 = (int)c3t_mesh.VERTEX_ATTRIB_BLEND_INDEX[i][2];
									weights[i].boneIndex3 = (int)c3t_mesh.VERTEX_ATTRIB_BLEND_INDEX[i][3];
									weights[i].weight0 = c3t_mesh.VERTEX_ATTRIB_BLEND_WEIGHT[i][0];
									weights[i].weight1 = c3t_mesh.VERTEX_ATTRIB_BLEND_WEIGHT[i][1];
									weights[i].weight2 = c3t_mesh.VERTEX_ATTRIB_BLEND_WEIGHT[i][2];
									weights[i].weight3 = c3t_mesh.VERTEX_ATTRIB_BLEND_WEIGHT[i][3];
								}
								mesh.boneWeights = weights;
							}

							Material mat = new Material(shader_dict["ubershader"]);

							if (node_go.GetComponent<SkinnedMeshRenderer>() == null)
							{
								node_go.AddComponent<SkinnedMeshRenderer>();
							}
							node_go.GetComponent<SkinnedMeshRenderer>().sharedMesh = mesh;
							node_go.GetComponent<SkinnedMeshRenderer>().material = mat;
							node_go.GetComponent<SkinnedMeshRenderer>().updateWhenOffscreen = true;

							List<Transform> bones = new List<Transform>();// = new Transform[]
							List<Matrix4x4> localBindPoses = new List<Matrix4x4>();

							if (node_part.bones != null)
							{

								foreach (c3t.Node.Part.Bone b in node_part.bones)
								{
									if (parent_bones != null)
									{
										if (parent_bones.ContainsKey(b.node))
											bones.Add(parent_bones[b.node]);
									}
									else
										bones.Add(pose_bone_dict[b.node]);

									Matrix4x4 new_bindpose = new Matrix4x4(new Vector4(bindposes_dict[b.node].m00, bindposes_dict[b.node].m10, bindposes_dict[b.node].m20, bindposes_dict[b.node].m30), new Vector4(bindposes_dict[b.node].m01, bindposes_dict[b.node].m11, bindposes_dict[b.node].m21, bindposes_dict[b.node].m31), new Vector4(bindposes_dict[b.node].m02, bindposes_dict[b.node].m12, bindposes_dict[b.node].m22, bindposes_dict[b.node].m32), new Vector4(bindposes_dict[b.node].m03, bindposes_dict[b.node].m13, bindposes_dict[b.node].m23, bindposes_dict[b.node].m33));
									new_bindpose *= node_transform_matrix;
									localBindPoses.Add(new_bindpose);
								}

								node_go.GetComponent<SkinnedMeshRenderer>().bones = bones.ToArray();
								//node_go.GetComponent<SkinnedMeshRenderer>().rootBone = pose_bones[0];
								node_go.GetComponent<SkinnedMeshRenderer>().sharedMesh.bindposes = localBindPoses.ToArray();
							}

							mesh.triangles = mesh.triangles.Reverse().ToArray();
							mesh.Optimize();
							//mesh.RecalculateNormals();
							mesh.RecalculateBounds();
							#endregion
							#region set materials



							if (c3m.ModelConfig[name].jsonData[0].materials.Length == 0)
							{
								Debug.Log("No material defined for " + node_go.name);
							}

							if (!c3m.ModelConfig[name].jsonData[0].material_dict.ContainsKey(node.id))
							{
								Debug.Log("No material defined for node id " + node.id);
								//node_go.gameObject.SetActive(false);
								break;
							}


							Config3DModel._Config3DModel.JsonData.Material material = c3m.ModelConfig[name].jsonData[0].material_dict[node.id];
							mat.name = material.nodeName;

							/*if (material.shaderName == "glow_vfx") //Ugly ass shader
                            {
								node_go.gameObject.SetActive(false);
							}*/


							if (!known_shaders.Contains(material.shaderName))
							{
								Debug.LogWarning("No shader " + material.shaderName + " for model " + name);
							}
							else
							{
								if (transparent_shaders.Contains(material.shaderName)){
									mat.CopyPropertiesFromMaterial(transparent_material);
								}

								if (material.shaderName == "ubershader")
								{

									bool cutout = false;
									if (material.intSettingIds != null)
									{
										for (int i = 0; i < material.intSettingIds.Length; i++)
										{
											if (material.intSettingIds[i] == "UseAsCutout_SWITCH" && material.intSettingValues[i] == 1)
											{
												cutout = true;
											}
										}
									}

									if (material.transparent == 1 && cutout == false)
									{
										mat.CopyPropertiesFromMaterial(transparent_material);
										mat.shader = shader_dict["ubershader_transparent"];
									}
									else
									{
										mat.CopyPropertiesFromMaterial(opaque_material);

										mat.shader = shader_dict["ubershader"];

									}

									mat.SetFloat("u_opacityAmount", 1.0f);
									mat.SetTexture("u_diffuseMap", (Texture)Resources.Load("Shaders/black"));
									mat.SetTexture("u_specularMap", (Texture)Resources.Load("Shaders/default_dirtmap"));
									mat.SetTexture("u_lightmapMap", (Texture)Resources.Load("default_lightmap"));
									mat.SetTexture("u_dirtMap", (Texture)Resources.Load("Shaders/default_dirtmap"));

									mat.SetFloat("_Surface", 1.0f);
								}

								else if (material.shaderName == "houseubershader")
								{
									mat.shader = shader_dict["quidditchshader"];

								}
								else if (material.shaderName == "simpleColor")
								{
									mat.shader = shader_dict["SimpleColor"];
								}
								else if (material.shaderName == "SimpleTexture")
                                {
									mat.CopyPropertiesFromMaterial(opaque_material);
									mat.shader = shader_dict["SimpleTexture"];
								}
								else if (material.shaderName == "crowd_vfx")
                                {
									mat.CopyPropertiesFromMaterial(opaque_material);
									mat.shader = shader_dict[material.shaderName];
								}
								else
								{
									if (shader_dict.ContainsKey(material.shaderName))
									{
										mat.shader = shader_dict[material.shaderName];
									}
                                    else
                                    {
										mat.shader = shader_dict["ubershader"];
									}
								}

								if (material.stringValueKeys != null)
								{
									for (int i = 0; i < material.stringValueKeys.Length; i++)
									{
										if (all_textures.ContainsKey(material.stringValueKeys[i]))
										{
											mat.SetTexture(material.stringIds[i], all_textures[material.stringValueKeys[i]]);
										}
									}
								}
								if (material.floatIds != null)
								{
									for (int i = 0; i < material.floatIds.Length; i++)
									{
										mat.SetFloat(material.floatIds[i], material.floatValues[i]);
									}	
								}
								if (material.vec3Ids != null)
								{
									for (int i = 0; i < material.vec3Ids.Length; i++)
									{
										mat.SetVector(material.vec3Ids[i], new Vector3(material.vec3Values[i][0], material.vec3Values[i][1], material.vec3Values[i][2]));
									}
								}
								if (material.vec4Ids != null)
								{

									for (int i = 0; i < material.vec4Ids.Length; i++)
									{
										mat.SetVector(material.vec4Ids[i], new Vector4(material.vec4Values[i][0], material.vec4Values[i][1], material.vec4Values[i][2], material.vec4Values[i][3]));
									}
								}
								if (material.intSettingIds != null)
                                {
									for (int i = 0; i < material.intSettingIds.Length; i++)
									{
										mat.SetFloat(material.intSettingIds[i], material.intSettingValues[i]);

									}
								}
								if (material.shaderName == "houserobeshader" || material.shaderName == "houseclothshader" || material.shaderName == "quidditchshader" || material.shaderName == "houseubershader")
								{
									switch (DialogueManager.local_avatar_house)
                                    {
										case "ravenclaw":
											mat.SetInt("is_ravenclaw", 1);
											break;
										case "gryffindor":
											mat.SetInt("is_gryffindor", 1);
											break;
										case "slytherin":
											mat.SetInt("is_slytherin", 1);
											break;
										case "hufflepuff":
											mat.SetInt("is_hufflepuff", 1);
											break;
									}
                                }

								if (material.CastShadow == 0)
                                {
									node_go.GetComponent<SkinnedMeshRenderer>().shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
								}
								if (material.shaderName == "glow_vfx")
                                {
									node_go.GetComponent<SkinnedMeshRenderer>().receiveShadows = false;
								}

							#endregion
							}
						}
					}
				}
			}
		}
		go.transform.localScale = new Vector3(0.01f, 0.01f, 0.01f);

		if (parent_bones != null)
			Destroy(go.transform.Find("Armature").gameObject);

		return pose_bone_dict;
	}

    public void Awake()
    {
		patch_text = File.ReadAllText("patches\\patch.txt");
		transparent_material = (Material)Resources.Load("transparent_base", typeof(Material));
		opaque_material = (Material)Resources.Load("opaque_base", typeof(Material));

		shader_dict = new Dictionary<string, Shader>();

		foreach(string shader in real_shaders)
        {
			shader_dict[shader] = Shader.Find("Shader Graphs/" +  shader);
			if (shader_dict[shader] == null)
            {
				GameObject crash = GameObject.Find("Canvas").transform.Find("Crash").gameObject;
				crash.SetActive(true);
				crash.transform.Find("Error").gameObject.GetComponent<Text>().text = "couldn't find " + shader;
            }
        }

	}

	public static void loadModelsTextures(string model_name)
	{
		if (model_name[0] == 'c')
		{
			foreach (string texture in Configs.config_character_model.ModelConfig[model_name].jsonData[0].neededTextureKeys)
			{
				if (!GameStart.game_state.loaded_textures.ContainsKey(texture))
				{
					//GameStart.game_state.loaded_textures[texture] = TextureManager.loadTexturePng(texture, "models//" + model_name);
					GameStart.game_state.loaded_textures[texture] = TextureManager.loadTextureDDS(texture);
				}
			}
		}
		else if (model_name[0] == 'p')
		{
			foreach (string texture in Configs.config_prop_model.ModelConfig[model_name].jsonData[0].neededTextureKeys)
			{
				if (!GameStart.game_state.loaded_textures.ContainsKey(texture))
				{
					//GameStart.game_state.loaded_textures[texture] = TextureManager.loadTexturePng(texture, "models//" + model_name);
					GameStart.game_state.loaded_textures[texture] = TextureManager.loadTextureDDS(texture);
				}
			}
		}
		else if (model_name[0] == 'f')
		{
			foreach (string texture in Configs.config_fx.ModelConfig[model_name].jsonData[0].neededTextureKeys)
			{
				if (!GameStart.game_state.loaded_textures.ContainsKey(texture))
				{
					//GameStart.game_state.loaded_textures[texture] = TextureManager.loadTexturePng(texture, "models//" + model_name);
					GameStart.game_state.loaded_textures[texture] = TextureManager.loadTextureDDS(texture);
				}
			}
		}
		else if (model_name[0] == 'o')
		{
			foreach (string texture in Configs.config_outfit_model.ModelConfig[model_name].jsonData[0].neededTextureKeys)
			{
				if (!GameStart.game_state.loaded_textures.ContainsKey(texture))
				{
					//GameStart.game_state.loaded_textures[texture] = TextureManager.loadTexturePng(texture, "models//" + model_name);
					GameStart.game_state.loaded_textures[texture] = TextureManager.loadTextureDDS(texture);
				}
			}
		}
	}


	/*IEnumerator LoadTexture()
	{
		string filePath = "";//.....
		UnityWebRequest uwr = UnityWebRequestTexture.GetTexture(filePath);
		yield return uwr.SendWebRequest();

		if (uwr.result == UnityWebRequest.Result.ConnectionError || uwr.result == UnityWebRequest.Result.DataProcessingError || uwr.result == UnityWebRequest.Result.ProtocolError)
		{
			Debug.Log(uwr.error);
		}
		else
		{
			Texture texture = ((DownloadHandlerTexture)uwr.downloadHandler).texture;
			image.texture = texture;
		}
	}*/

}