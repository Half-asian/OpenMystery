﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Newtonsoft.Json;
using System.IO;

public class EventManager : MonoBehaviour
{

    public List<string> event_stack = new List<string>();
    public float block_duration = 0.0f;


    public GameObject screen_fade;

    public GameObject main_camera;

    public string blocking_message;
    public string blocking_key;
    public string last_finished_animation = "";
    public bool total_block = false;

    public List<string[]> anim_sequences_to_add = new List<string[]>();

    public ConfigScene._Scene.Camera last_camera;

    public class WayPoint
    {
        public Vector3 position;
        public Quaternion rotation;
    }

    public class Looking
    {
        public GameObject character;
        public float progress;
        public float destination_progress;
        public Vector3 looking_position;
    }

    public void stopLookAts(GameObject character)
    {
        foreach (CharacterManager c in GameStart.game_state.characters.Values)
        {
            if (c.looking != null)
            {
                if (c.looking.character == character)
                {
                    c.clearLookat();
                    c.clearTurnHeadAt();
                    Debug.Log(c.name + " stop looking at " + c.looking.character.gameObject.name);
                }
            }
        }
    }

    public void lookAt(string[] action_params)
    {
        if (action_params.Length < 2)
        {
            if (GameStart.game_state.characters.ContainsKey(action_params[0]))
            {
                GameStart.game_state.characters[action_params[0]].clearLookat();
            }
            return;
        }

        if (GameStart.game_state.characters.ContainsKey(action_params[0]))
        {
            if (GameStart.game_state.characters.ContainsKey(action_params[1]))
            {

                Looking new_looking = new Looking();
                new_looking.character = GameStart.game_state.characters[action_params[1]].gameObject;

                new_looking.progress = 0.0f;
                if (GameStart.game_state.characters[action_params[0]].looking != null)
                {
                    if (!(GameStart.game_state.characters[action_params[0]].looking.character == new_looking.character)) //This line is risky
                    {
                        GameStart.game_state.characters[action_params[0]].setLookat(new_looking);
                    }
                }
                else
                {
                    GameStart.game_state.characters[action_params[0]].setLookat(new_looking);
                }
            }
            else
            {
                GameStart.game_state.characters[action_params[0]].clearLookat();
            }
        }
    }

    public void turnHeadAt(string[] action_params)
    {
        if (action_params.Length < 2)
        {
            if (GameStart.game_state.characters.ContainsKey(action_params[0]))
            {
                GameStart.game_state.characters[action_params[0]].clearTurnHeadAt();
            }
            return;
        }

        if (GameStart.game_state.characters.ContainsKey(action_params[0]))
        {
            if (GameStart.game_state.characters.ContainsKey(action_params[1]))
            {

                Looking new_looking = new Looking();
                new_looking.character = GameStart.game_state.characters[action_params[1]].gameObject;

                new_looking.progress = 0.0f;
                if (GameStart.game_state.characters[action_params[0]].looking != null)
                {
                    if (!(GameStart.game_state.characters[action_params[0]].looking.character == new_looking.character)) //This line is risky
                    {
                        GameStart.game_state.characters[action_params[0]].setTurnHeadAt(new_looking);
                    }
                }
                else
                {
                    GameStart.game_state.characters[action_params[0]].setTurnHeadAt(new_looking);
                }
            }
            else
            {
                GameStart.game_state.characters[action_params[0]].clearTurnHeadAt();
            }
        }
    }

    private IEnumerator LerpCamera(Vector3 start_position, Quaternion start_rotation, Vector3 end_position, Quaternion end_rotation, float start_time, float length)
    {
        while (Time.realtimeSinceStartup < length + start_time && CameraManager.camera_state == CameraManager.CameraState.StateLerp) {
            float elapsed_time = Time.realtimeSinceStartup - start_time;
            float progress = elapsed_time / length;

            CameraManager.main_camera_jt_cam_bind.transform.localPosition = Vector3.Lerp(start_position, end_position, progress);
            CameraManager.main_camera_jt_cam_bind.transform.localRotation= Quaternion.Lerp(start_rotation, end_rotation, progress);
            yield return null;

        }
        CameraManager.main_camera_jt_cam_bind.transform.localPosition = end_position;
        CameraManager.main_camera_jt_cam_bind.transform.localRotation = end_rotation;
        main_camera.GetComponent<SimpleCameraController>().enabled = true;
    }

    public void startLerpCamera(Vector3 start_position, Quaternion start_rotation, Vector3 end_position, Quaternion end_rotation, float start_time, float length){
        StartCoroutine(LerpCamera(start_position, start_rotation, end_position, end_rotation, start_time, length));
    }

    IEnumerator waitCameraAnimation(float start_time, float length, string animation)
    {
        last_finished_animation = "";
        while (Time.realtimeSinceStartup < length + start_time)
        {
            yield return null;
        }
        CameraManager.freeCamera();
        notifyCamAnimFinished(animation);
        CameraManager.simple_camera_controller.enabled = true;
        last_finished_animation = animation;
    }

    IEnumerator waitPropAnimation(float start_time, float length, string prop, string animation)
    {
        while (Time.realtimeSinceStartup < length + start_time)
        {
            yield return null;
        }
        notifyPropAnimationComplete(prop, animation);
    }

    IEnumerator waitCharacterAnimation(float start_time, float length, string character, string animation)
    {
        while (Time.realtimeSinceStartup < length + start_time)
        {
            yield return null;
        }
        notifyCharacterAnimationComplete(character, animation);
    }

    public void startWaitCameraAnimation(float start_time, float length, string animation)
    {
        StartCoroutine(waitCameraAnimation(start_time, length, animation));
    }

    public List<string> carvePath(List<string> visited, string destination)
    {
        List<string> final_result = new List<string>();

        if (GameStart.game_state.scenario_holder.scene.waypointconnections == null)
        {
            return final_result;
        }

        foreach(ConfigScene._Scene.WayPointConnection connection in GameStart.game_state.scenario_holder.scene.waypointconnections)
        {
            if (connection.connection[0] == visited[visited.Count - 1]){
                if (connection.connection[1] == destination)
                {
                    visited.Add( destination);
                    return visited;
                }
                else if (!visited.Contains(connection.connection[1]))
                {
                    List<string> temp = new List<string>(visited);
                    temp.Add(connection.connection[1]);
                    List<string> result = carvePath(temp, destination);

                    if (result[result.Count - 1] == destination) //we found a path
                    {
                        string s_path = "";
                        foreach (string s in result)
                        {
                            s_path += s + " ";
                        }

                        if (final_result.Count != 0) //we already found a path
                        {
                            if (result.Count < final_result.Count)
                            {
                                final_result = result; //The new path is shorter
                            }
                        }
                        else
                        {
                            
                            final_result = result; //we hadn't found a path, now we have
                        }
                    }
                }
            }
            else if (connection.connection[1] == visited[visited.Count - 1])
            {
                if (connection.connection[0] == destination)
                {
                    visited.Add(destination);
                    return visited;
                }
                else if (!visited.Contains(connection.connection[0]))
                {
                    List<string> temp = new List<string>(visited);
                    temp.Add(connection.connection[0]);
                    List<string> result = carvePath(temp, destination);

                    if (result[result.Count - 1] == destination) //we found a path
                    {
                        string s_path = "";
                        foreach (string s in result)
                        {
                            s_path += s + " ";
                        }
                        if (final_result.Count != 0) //we already found a path
                        {
                            if (result.Count < final_result.Count)
                            {
                                final_result = result; //The new path is shorter
                            }
                        }
                        else
                        {
                            final_result = result; //we hadn't found a path, now we have
                        }
                    }
                }
            }
        }
        if (final_result.Count == 0)
        {
            return visited;
        }
        return final_result;
    }

    public void moveCharacter(string[] action_params, bool walking = true, bool set_animation = true)
    {
        if (!GameStart.game_state.scenario_holder.scene.waypoint_dict.ContainsKey(action_params[1]))
        {
            Debug.LogWarning("COULDN'T FIND WAYPOINT " + action_params[1] + " IN CURRENT SCENE! for character move");
            return;
        }

        if (GameStart.game_state.characters.ContainsKey(action_params[0]))
        {
            if (GameStart.game_state.characters[action_params[0]].getCurrentWaypoint() == null)
            {
                return;
            }
        }
        else
        {
            return;
        }

        ConfigScene._Scene.WayPoint waypoint = GameStart.game_state.scenario_holder.scene.waypoint_dict[action_params[1]];

        List<string> visited = new List<string>();
        visited.Add(GameStart.game_state.characters[action_params[0]].getCurrentWaypoint());


        List<string> path = carvePath(visited, action_params[1]);

        string s_path = "";
        foreach (string s in path)
        {
            s_path += s + " ";
        }
        if (path.Count != 0)
        {
            if (path[path.Count - 1] != action_params[1])
            {//Did not find a path
                path.Clear();
                path.Add(action_params[1]); //Change to a direct route
            }
        }
        else
        {
            path.Clear();
            path.Add(action_params[1]); //Change to a direct route
        }

        if (GameStart.game_state.characters.ContainsKey(action_params[0]))
        {
            if (GameStart.game_state.characters[action_params[0]].gameObject != null)
            {
                WayPoint new_waypoint = new WayPoint();
                new_waypoint.position = new Vector3(waypoint.position[0] * -0.01f, waypoint.position[1] * 0.01f, waypoint.position[2] * 0.01f);
                if (waypoint.rotation != null)
                {
                    new_waypoint.rotation = Quaternion.identity;
                    new_waypoint.rotation *= Quaternion.Euler(new Vector3(0, 0, -waypoint.rotation[2]));
                    new_waypoint.rotation *= Quaternion.Euler(new Vector3(0, -waypoint.rotation[1], 0));
                    new_waypoint.rotation *= Quaternion.Euler(new Vector3(waypoint.rotation[0], 0, 0));

                }

                if (set_animation)
                {

                    if (action_params.Length > 2)
                    {
                        //Unknown what fourth action_param does. It is usually set to 1
                        GameStart.game_state.characters[action_params[0]].moveCharacter(path, action_params[2]);
                    }
                    else
                    {
                        if (walking)
                            GameStart.game_state.characters[action_params[0]].moveCharacter(path);
                        else
                            GameStart.game_state.characters[action_params[0]].moveCharacterNoAnimation(path, 0.0f);
                    }
                }
                else
                {
                    if (action_params[2] == "walk_wheelchairStudent" || action_params[2] == "c_Stu_Jog01" || action_params[2].Contains("flyingOnBroom"))
                        GameStart.game_state.characters[action_params[0]].moveCharacterNoAnimation(path, 1.3f);
                    else
                        GameStart.game_state.characters[action_params[0]].moveCharacterNoAnimation(path, 0.0f);
                }
            }
        }
        else
        {
            Debug.Log("Couldn't find character " + action_params[0] + " in characters.");
        }

    }

    public float activateEvent(string event_name)
    {

        if (Configs.config_script_events.ScriptEvents[event_name].shouldRun != null)
        {
            if (Configs.config_script_events.ScriptEvents[event_name].shouldRun != "")
            {
                if (Predicate.parsePredicate(Configs.config_script_events.ScriptEvents[event_name].shouldRun) == false)
                {
                    //Debug.Log("predicate fail " + event_config.ScriptEvents[event_name].shouldRun);
                    return 0.0f;
                }
                else
                {
                    //Debug.Log("predicate pass " + event_config.ScriptEvents[event_name].shouldRun);

                }
            }
        }

        Debug.Log("Event " + event_name);
        Log.write("Event " + event_name);

        float event_time = 0.0f;
        if (!Configs.config_script_events.ScriptEvents.ContainsKey(event_name))
        {
            Debug.Log("Couldn't find event " + event_name);
            return 0.0f;
        }

        if (Configs.config_script_events.ScriptEvents[event_name].type == "Blocking" && Configs.config_script_events.ScriptEvents[event_name].duration == 0.0f && Configs.config_script_events.ScriptEvents[event_name].messageAndKeys != null) //There are some blocking events with no way to exit and no time. Just leftover junk maybe?
        {
            total_block = true;
        }


       if (Configs.config_script_events.ScriptEvents[event_name].action == null)
        {
            if (Configs.config_script_events.ScriptEvents[event_name].type == "Blocking")
            {
                //Debug.Log("blocking event " + event_name);
                GetComponent<DialogueManager>().ui_dialogue.SetActive(false);
                event_time = Configs.config_script_events.ScriptEvents[event_name].duration;
                if (Configs.config_script_events.ScriptEvents[event_name].messageAndKeys != null)
                {
                    blocking_message = Configs.config_script_events.ScriptEvents[event_name].messageAndKeys[0][0];
                    if (Configs.config_script_events.ScriptEvents[event_name].messageAndKeys[0].Length >= 2)
                    {
                        blocking_key = Configs.config_script_events.ScriptEvents[event_name].messageAndKeys[0][1];
                    }
                    else
                    {
                        blocking_key = blocking_message;
                    }
                }
            }
            if (Configs.config_script_events.ScriptEvents[event_name].type == "Sequential")
            {
                StartCoroutine(waitSequentialEvents(Configs.config_script_events.ScriptEvents[event_name].sequenceIds, Configs.config_script_events.ScriptEvents[event_name].messageAndKeys)); //We need to complete message and keys before activating sequences
            }
            return event_time;


        }

        if (Configs.config_script_events.ScriptEvents[event_name].type == "Blocking")
        {
            event_time = Configs.config_script_events.ScriptEvents[event_name].duration;

            if (Configs.config_script_events.ScriptEvents[event_name].messageAndKeys != null)
            {
                blocking_message = Configs.config_script_events.ScriptEvents[event_name].messageAndKeys[0][0];
                if (Configs.config_script_events.ScriptEvents[event_name].messageAndKeys[0].Length >= 2)
                {
                    blocking_key = Configs.config_script_events.ScriptEvents[event_name].messageAndKeys[0][1];
                }
                else
                {
                    blocking_key = blocking_message;
                }
            }

        }
        else
        {
            if (Configs.config_script_events.ScriptEvents[event_name].duration != 0.0f)
            {
                //Debug.Log("Non-blocking event with non 0 duration " + event_name);
            }
        }

        for (int event_index = 0; event_index < Configs.config_script_events.ScriptEvents[event_name].action.Length; event_index++)
        {

            string[] action_params;
            if (Configs.config_script_events.ScriptEvents[event_name].param != null)
                if (event_index < Configs.config_script_events.ScriptEvents[event_name].param.Length)
                    action_params = Configs.config_script_events.ScriptEvents[event_name].param[event_index].Split(':');
                else
                    return event_time;
            else
                action_params = new string[0];

            switch (Configs.config_script_events.ScriptEvents[event_name].action[event_index])
            {
                case "animateCharacter":
                    if (GameStart.game_state.characters.ContainsKey(action_params[0]))
                    {
                        GameStart.game_state.characters[action_params[0]].replaceCharacterIdle(action_params[1]);

                        float length = AnimationManager.loadAnimationClip(Configs.config_animation.Animation3D[action_params[0]].name, "c3b", null).length;

                        waitCharacterAnimation(Time.realtimeSinceStartup, length, action_params[0], action_params[1]);
                    }

                    break;

                case "replaceCharacterIdleStaggered":
                case "replaceCharacterIdle":
                    if (GameStart.game_state.characters.ContainsKey(action_params[0]))
                    {
                        GameStart.game_state.characters[action_params[0]].replaceCharacterIdle(action_params[1]);
                    }

                    break;

                case "setCharacterIdle":
                    if (GameStart.game_state.characters.ContainsKey(action_params[0]))
                    {
                        if (GameStart.game_state.characters.ContainsKey(action_params[0]))
                        {
                            GameStart.game_state.characters[action_params[0]].setCharacterIdle();
                        }
                    }
                    break;



                case "moveCharacter":
                    moveCharacter(action_params);

                    break;
                case "turnHeadAt": //Don't move shoulders
                    turnHeadAt(action_params);
                    break;
                case "lookAt":
                    lookAt(action_params);
                    break;
                case "teleportCharacter":
                    if (!GameStart.game_state.scenario_holder.scene.waypoint_dict.ContainsKey(action_params[1])) {
                        Debug.LogWarning("COULDN'T FIND WAYPOINT " + action_params[1] + " IN CURRENT SCENE!");
                        break;
                    }

                    GameStart.logWrite("Teleporting character " + action_params[0] + " to " + action_params[1]);

                    ConfigScene._Scene.WayPoint waypoint_b = GameStart.game_state.scenario_holder.scene.waypoint_dict[action_params[1]];
                    if (GameStart.game_state.characters.ContainsKey(action_params[0]))
                    {
                        if (GameStart.game_state.characters[action_params[0]].gameObject != null)
                        {
                            if (waypoint_b.rotation != null)
                            {
                                Vector3 rotation = new Vector3(waypoint_b.rotation[0], waypoint_b.rotation[1], waypoint_b.rotation[2]);



                                GameStart.game_state.characters[action_params[0]].teleportCharacter(new Vector3(waypoint_b.position[0] * -0.01f, waypoint_b.position[1] * 0.01f, waypoint_b.position[2] * 0.01f), rotation);
                                GameStart.logWrite("Teleported character to position " + waypoint_b.position[0] * -0.01f + ", " + waypoint_b.position[1] * 0.01f + ", " + waypoint_b.position[2] * 0.01f + " rotation " + rotation[0] + ", " + rotation[1] + ", " + rotation[2]);

                            }
                            else if (waypoint_b.position != null)
                            {
                                GameStart.game_state.characters[action_params[0]].teleportCharacter(new Vector3(waypoint_b.position[0] * -0.01f, waypoint_b.position[1] * 0.01f, waypoint_b.position[2] * 0.01f), Vector3.zero);
                                GameStart.logWrite("Teleported character to position " + waypoint_b.position[0] * -0.01f + ", " + waypoint_b.position[1] * 0.01f + ", " + waypoint_b.position[2] * 0.01f + " rotation zero vector");
                            }
                            else
                            {
                                GameStart.game_state.characters[action_params[0]].teleportCharacter(Vector3.zero, Vector3.zero);
                                GameStart.logWrite("Teleported character to position zero vector rotation zero vector");
                            }
                            GameStart.game_state.characters[action_params[0]].clearTurnHeadAt();

                            GameStart.game_state.characters[action_params[0]].clearLookat();


                            GameStart.game_state.characters[action_params[0]].current_waypoint = waypoint_b.name;
                        }
                    }
                    else
                    {
                        Debug.Log("Couldn't find character " + action_params[0] + " in characters.");
                    }

                    break;

                case "teleportProp":
                    if (!GameStart.game_state.scenario_holder.scene.waypoint_dict.ContainsKey(action_params[1]))
                    {
                        Debug.LogWarning("COULDN'T FIND WAYPOINT " + action_params[1] + " IN CURRENT SCENE!");
                        break;
                    }
                    ConfigScene._Scene.WayPoint waypoint_c = GameStart.game_state.scenario_holder.scene.waypoint_dict[action_params[1]];
                    if (GameStart.game_state.spawned_props.ContainsKey(action_params[0]))
                    {
                        Common.setWaypointTransform(ref GameStart.game_state.spawned_props[action_params[0]].game_object, waypoint_c);
                    }
                    else
                    {
                        Debug.LogWarning("COULDN'T FIND Prop " + action_params[0]);
                    }
                    break;

                case "spawnCharacter":
                    ActorSpawn.spawnCharacterInScene(action_params[0], action_params[1], action_params[2]);
                    break;

                case "despawnCharacter":
                    ActorSpawn.despawnCharacterInScene(action_params[0]);
                    break;

                case "spawnProp": //model, waypoint, name
                    if (GameStart.game_state.scenario_holder.scene.waypoint_dict.ContainsKey(action_params[1]))
                    {
                        ModelManager.loadModelsTextures(action_params[0]);

                        if (action_params.Length == 3)
                            Prop.spawnPropFromEvent(action_params[0], GameStart.game_state.scenario_holder.scene.waypoint_dict[action_params[1]], action_params[2]);
                        else
                            Prop.spawnPropFromEvent(action_params[0], GameStart.game_state.scenario_holder.scene.waypoint_dict[action_params[1]], action_params[0]);
                    }
                    break;

                case "hideEntity":
                    if (GameStart.game_state.spawned_props.ContainsKey(action_params[0]))
                    {
                        GameStart.game_state.spawned_props[action_params[0]].game_object.SetActive(false);
                    }
                    else
                    {
                        Debug.Log("remove/despawn prop didn't find prop " + action_params[0]);
                    }
                    break;
                case "showEntity":
                    if (GameStart.game_state.spawned_props.ContainsKey(action_params[0]))
                    {
                        GameStart.game_state.spawned_props[action_params[0]].game_object.SetActive(true);
                    }
                    else
                    {
                        Debug.Log("remove/despawn prop didn't find prop " + action_params[0]);
                    }
                    break;

                case "removeProp":
                case "despawnProp":
                    if (GameStart.game_state.spawned_props.ContainsKey(action_params[0]))
                    {
                        Destroy(GameStart.game_state.spawned_props[action_params[0]].game_object);
                        GameStart.game_state.spawned_props.Remove(action_params[0]);
                    }
                    else
                    {
                        Debug.Log("remove/despawn prop didn't find prop " + action_params[0]);
                    }
                    break;

                case "playCameraAnimation":

                    Debug.Log("Playing camera anim " + action_params[0]);
                    CameraManager.playCameraAnimation(action_params[0], true);
                    break;

                case "playCinematicCameraAnimation":
                    if (action_params.Length > 1)
                    {
                        string[] focus_cam_action_params = new string[] { action_params[1], "0" };
                        CameraManager.focusCam(ref focus_cam_action_params);
                    }

                    Debug.Log("Playing cinematic camera anim " + action_params[0]);
                    CameraManager.playCameraAnimation(action_params[0], true);
                    break;

                case "focusCamera": //action param 1 is probably time to transition camera (lerp)
                    last_camera = CameraManager.focusCam(ref action_params);
                    break;

                case "panCamOnTrack":
                    if (action_params[0] != "0:0") //no clue what this means but it seems faulty
                        CameraManager.panCamOnTrack(last_camera.animation);
                    break;

                case "hideCharacter":
                    if (GameStart.game_state.characters.ContainsKey(action_params[0]))
                    {
                        foreach(SkinnedMeshRenderer smr in GameStart.game_state.characters[action_params[0]].gameObject.transform.GetComponentsInChildren<SkinnedMeshRenderer>())
                        {
                            smr.enabled = false;
                        }
                    }
                    break;
                case "showCharacter":
                    if (GameStart.game_state.characters.ContainsKey(action_params[0]))
                    {
                        foreach (SkinnedMeshRenderer smr in GameStart.game_state.characters[action_params[0]].gameObject.transform.GetComponentsInChildren<SkinnedMeshRenderer>())
                        {
                            smr.enabled = true;
                        }
                    }
                    break;
                case "fadeToBlack":
                    screen_fade.SetActive(true);
                    screen_fade.GetComponent<Animator>().SetTrigger("fade_to_black");
                    break;

                case "fadeFromBlack":
                    screen_fade.GetComponent<Animator>().SetTrigger("fade_from_black");
                    break;

                case "safeAdvanceAnimSequenceTo": //This shit is used ONCE in the entire game
                    if (GameStart.game_state.characters.ContainsKey(action_params[0]))
                    {
                        GameStart.game_state.characters[action_params[0]].gameObject.GetComponent<CharAnimSequenceHandler>().safeAdvanceAnimSequenceTo(action_params[2]); //action_param 1 might be starting node (immediate set node).
                    }
                    else
                    {
                        if (GameStart.game_state.spawned_props.ContainsKey(action_params[0]))
                        {
                            GameStart.game_state.spawned_props[action_params[0]].game_object.GetComponent<CharAnimSequenceHandler>().safeAdvanceAnimSequenceTo(action_params[2]);
                        }
                        else
                        {
                            Debug.LogWarning("Couldn't find prop " + action_params[0] + " in spawned props");
                        }
                    }

                    notifySequenceNodeExited(action_params[2]);

                    break;

                case "advanceAnimSequence":
                    if (GameStart.game_state.characters.ContainsKey(action_params[0])){
                        if (GameStart.game_state.characters[action_params[0]].gameObject != null)
                        {
                            if (GameStart.game_state.characters[action_params[0]].gameObject.GetComponent<CharAnimSequenceHandler>() != null)
                                GameStart.game_state.characters[action_params[0]].gameObject.GetComponent<CharAnimSequenceHandler>().advanceAnimSequence();
                        }
                    }
                    else {
                        if (GameStart.game_state.spawned_props.ContainsKey(action_params[0])) {
                            GameStart.game_state.spawned_props[action_params[0]].game_object.GetComponent<CharAnimSequenceHandler>().advanceAnimSequence();
                        }
                        else
                        {
                            Debug.LogWarning("Couldn't find prop " + action_params[0] + " in spawned props");
                        }
                    }
                    break;
                case "replaceCharacterIdleSequence":
                    if (GameStart.game_state.characters.ContainsKey(action_params[0]))
                    {
                        if (GameStart.game_state.characters[action_params[0]].character_state == CharacterManager.CharacterState.Idle)
                        {
                            GameStart.game_state.characters[action_params[0]].anim_state = "sequence";

                            GameStart.logWrite("CharacterIdleSequence " + action_params[0] + " " + action_params[1]);

                            if (GameStart.game_state.characters[action_params[0]].gameObject.GetComponent<CharAnimSequenceHandler>() != null)
                            {
                                GameStart.game_state.characters[action_params[0]].gameObject.GetComponent<CharAnimSequenceHandler>().destroyProps();
                                GameStart.game_state.characters[action_params[0]].gameObject.GetComponent<CharAnimSequenceHandler>().enabled = true;
                                GameStart.game_state.characters[action_params[0]].gameObject.GetComponent<CharAnimSequenceHandler>().initAnimSequence(action_params[1], false);
                            }
                            else
                            {
                                GameStart.game_state.characters[action_params[0]].gameObject.AddComponent<CharAnimSequenceHandler>();
                                GameStart.game_state.characters[action_params[0]].gameObject.GetComponent<CharAnimSequenceHandler>().initAnimSequence(action_params[1], false);
                            }
                        }
                        else
                        {
                            anim_sequences_to_add.Add(action_params);
                        }
                    }
                    break;
                case "playCharacterAnimSequence":
                    if (GameStart.game_state.characters.ContainsKey(action_params[0]))
                    {
                        if (GameStart.game_state.characters[action_params[0]].character_state == CharacterManager.CharacterState.Idle)
                        {
                            GameStart.game_state.characters[action_params[0]].anim_state = "sequence";

                            GameStart.logWrite("CharacterIdleSequence " + action_params[0] + " " + action_params[1]);

                            if (GameStart.game_state.characters[action_params[0]].gameObject.GetComponent<CharAnimSequenceHandler>() != null)
                            {
                                GameStart.game_state.characters[action_params[0]].gameObject.GetComponent<CharAnimSequenceHandler>().enabled = true;
                                GameStart.game_state.characters[action_params[0]].gameObject.GetComponent<CharAnimSequenceHandler>().initAnimSequence(action_params[1], false);
                            }
                            else
                            {
                                GameStart.game_state.characters[action_params[0]].gameObject.AddComponent<CharAnimSequenceHandler>();
                                GameStart.game_state.characters[action_params[0]].gameObject.GetComponent<CharAnimSequenceHandler>().initAnimSequence(action_params[1], false);
                            }
                        }
                        else
                        {
                            anim_sequences_to_add.Add(action_params);
                        }
                    }
                    break;

                case "moveCharacterWithSequence":
                    moveCharacter(action_params, false, false);

                    if (GameStart.game_state.characters.ContainsKey(action_params[0]))
                    {
                        if (GameStart.game_state.characters[action_params[0]].character_state == CharacterManager.CharacterState.Walk)
                        {
                            int result;
                            if (GameStart.game_state.characters[action_params[0]].gameObject.GetComponent<CharAnimSequenceHandler>() != null)
                            {
                                result = GameStart.game_state.characters[action_params[0]].gameObject.GetComponent<CharAnimSequenceHandler>().initAnimSequence(action_params[2], true); //not always action_params 2
                            }
                            else
                            {
                                GameStart.game_state.characters[action_params[0]].gameObject.AddComponent<CharAnimSequenceHandler>();
                                result = GameStart.game_state.characters[action_params[0]].gameObject.GetComponent<CharAnimSequenceHandler>().initAnimSequence(action_params[2], true);
                            }
                            if (result == 1)
                            {
                                GameStart.game_state.characters[action_params[0]].setCharacterWalk(GameStart.game_state.characters[action_params[0]].actor_info.animId_walk);
                                Debug.LogError(GameStart.game_state.characters[action_params[0]].character_state);
                            }
                        }
                    }
                    break;

                case "animateProp":
                    if (GameStart.game_state.spawned_props.ContainsKey(action_params[0]))
                    {
                        if (GameStart.game_state.spawned_props[action_params[0]].game_object.GetComponent<CharAnimSequenceHandler>() != null)
                        {
                            Destroy(GameStart.game_state.spawned_props[action_params[0]].game_object.GetComponent<CharAnimSequenceHandler>());
                        }
                        if (GameStart.game_state.spawned_props[action_params[0]].game_object.GetComponent<Animation>() == null)
                        {
                            GameStart.game_state.spawned_props[action_params[0]].game_object.AddComponent<Animation>();
                        }
                        AnimationClip prop_anim_clip = AnimationManager.loadAnimationClip(action_params[1], "c3b", null);

                        GameStart.game_state.spawned_props[action_params[0]].game_object.GetComponent<Animation>().AddClip(prop_anim_clip, "default");


                        if (Configs.config_animation.Animation3D[action_params[1]].wrapMode == "clamp"){
                            GameStart.game_state.spawned_props[action_params[0]].game_object.GetComponent<Animation>().wrapMode = WrapMode.Clamp;
                            StartCoroutine(waitPropAnimation(Time.realtimeSinceStartup, prop_anim_clip.length, action_params[0], action_params[1]));
                        }
                        else
                        {
                            GameStart.game_state.spawned_props[action_params[0]].game_object.GetComponent<Animation>().wrapMode = WrapMode.Loop;
                        }
                        GameStart.game_state.spawned_props[action_params[0]].game_object.GetComponent<Animation>().Play("default");

                    }
                    else
                    {
                        Debug.LogWarning("Couldn't find prop " + action_params[0] + " in spawned props");
                    }
                    break;
                case "playPropAnimSequence":
                    Debug.Log("playPromAnimSequence " + action_params[0] + " " + action_params[1]);
                    if (GameStart.game_state.spawned_props.ContainsKey(action_params[0])) 
                    {
                        Debug.Log("found!");
                        if (GameStart.game_state.spawned_props[action_params[0]].game_object.GetComponent<Animation>() == null)
                        {
                            GameStart.game_state.spawned_props[action_params[0]].game_object.AddComponent<Animation>();
                        }
                        GameStart.game_state.spawned_props[action_params[0]].game_object.AddComponent<CharAnimSequenceHandler>();
                        GameStart.game_state.spawned_props[action_params[0]].game_object.GetComponent<CharAnimSequenceHandler>().initAnimSequence(action_params[1], false);
                    }
                    else
                    {
                        Debug.LogWarning("Couldn't find prop " + action_params[0] + " in spawned props");
                    }
                    break;

                case "replaceScenarioBGMusic":
                    if (Configs.playlist_dict.ContainsKey(action_params[0]))
                    {
                        GetComponent<DialogueManager>().playAudioFile(Configs.playlist_dict[action_params[0]].files[0], "bgaudio");
                    }
                    break;


                case "equipAvatarComponent":

                    Debug.Log("equipAvatarComponent");

                    if (action_params[0].Contains("hair"))
                    {
                        GameObject.Find("GameManager").GetComponent<GameStart>().removePatchFromCharacter("Avatar", GameObject.Find("GameManager").GetComponent<Player>()._hair);
                        GameObject.Find("GameManager").GetComponent<Player>()._hair = GameObject.Find("GameManager").GetComponent<GameStart>().addPatchToCharacter("Avatar", action_params[0], GameStart.game_state.characters["Avatar"].parent_bones);
                        GameObject.Find("GameManager").GetComponent<Player>().setHairColor();
                    }

                    else if (action_params[0].Contains("TOP"))
                    {
                        if (!action_params[0].Contains("_skin"))
                        {
                            action_params[0] += "_skin";
                        }
                        GameObject.Find("GameManager").GetComponent<GameStart>().removePatchFromCharacter("Avatar", GameObject.Find("GameManager").GetComponent<Player>()._outfit);
                        GameObject.Find("GameManager").GetComponent<Player>()._outfit = GameObject.Find("GameManager").GetComponent<GameStart>().addPatchToCharacter("Avatar", action_params[0], GameStart.game_state.characters["Avatar"].parent_bones);
                    }
                    else if (action_params[0].Contains("BOTTOM"))
                    {
                        if (!action_params[0].Contains("_skin"))
                        {
                            action_params[0] += "_skin";
                        }
                        GameObject.Find("GameManager").GetComponent<GameStart>().removePatchFromCharacter("Avatar", GameObject.Find("GameManager").GetComponent<Player>()._outfit_bottom);
                        GameObject.Find("GameManager").GetComponent<Player>()._outfit_bottom = GameObject.Find("GameManager").GetComponent<GameStart>().addPatchToCharacter("Avatar", action_params[0], GameStart.game_state.characters["Avatar"].parent_bones);
                    }
                    else if (action_params[0].Contains("FULL"))
                    {
                        if (!action_params[0].Contains("_skin"))
                        {
                            action_params[0] += "_skin";
                        }
                        GameObject.Find("GameManager").GetComponent<GameStart>().removePatchFromCharacter("Avatar", GameObject.Find("GameManager").GetComponent<Player>()._outfit);
                        GameObject.Find("GameManager").GetComponent<GameStart>().removePatchFromCharacter("Avatar", GameObject.Find("GameManager").GetComponent<Player>()._outfit_bottom);
                        GameObject.Find("GameManager").GetComponent<Player>()._outfit_bottom = GameObject.Find("GameManager").GetComponent<GameStart>().addPatchToCharacter("Avatar", action_params[0], GameStart.game_state.characters["Avatar"].parent_bones);
                        GameObject.Find("GameManager").GetComponent<Player>()._outfit = GameObject.Find("GameManager").GetComponent<Player>()._outfit_bottom;

                        if (action_params[0] == "o_Female_ForestFormal_FULL_skin" || action_params[0] == "o_Female_ForestFormal_FULL1_skin")
                        {
                            GameObject.Find("GameManager").GetComponent<Player>()._arms = GameObject.Find("GameManager").GetComponent<GameStart>().addPatchToCharacter("Avatar", "c_AvatarArms_female_skin", GameStart.game_state.characters["Avatar"].parent_bones);

                            if (GameObject.Find("GameManager").GetComponent<Player>()._arms.GetComponentInChildren<SkinnedMeshRenderer>().material.HasProperty("brightness"))
                                GameObject.Find("GameManager").GetComponent<Player>()._arms.GetComponentInChildren<SkinnedMeshRenderer>().material.SetFloat("brightness",  GameObject.Find("GameManager").GetComponent<Player>()._skin_brightness);
                            if (GameObject.Find("GameManager").GetComponent<Player>()._arms.GetComponentInChildren<SkinnedMeshRenderer>().material.HasProperty("contrast"))
                                GameObject.Find("GameManager").GetComponent<Player>()._arms.GetComponentInChildren<SkinnedMeshRenderer>().material.SetFloat("contrast", GameObject.Find("GameManager").GetComponent<Player>()._skin_contrast);

                            GameObject.Find("GameManager").GetComponent<Player>()._legs = GameObject.Find("GameManager").GetComponent<GameStart>().addPatchToCharacter("Avatar", "c_AvatarLegs_ShortPantsFeet_skin", GameStart.game_state.characters["Avatar"].parent_bones);

                            if (GameObject.Find("GameManager").GetComponent<Player>()._legs.GetComponentInChildren<SkinnedMeshRenderer>().material.HasProperty("brightness"))
                                GameObject.Find("GameManager").GetComponent<Player>()._legs.GetComponentInChildren<SkinnedMeshRenderer>().material.SetFloat("brightness", GameObject.Find("GameManager").GetComponent<Player>()._skin_brightness);
                            if (GameObject.Find("GameManager").GetComponent<Player>()._legs.GetComponentInChildren<SkinnedMeshRenderer>().material.HasProperty("contrast"))
                                GameObject.Find("GameManager").GetComponent<Player>()._legs.GetComponentInChildren<SkinnedMeshRenderer>().material.SetFloat("contrast", GameObject.Find("GameManager").GetComponent<Player>()._skin_contrast);
                        }
                        else
                        {
                            GameObject.Find("GameManager").GetComponent<GameStart>().removePatchFromCharacter("Avatar", GameObject.Find("GameManager").GetComponent<Player>()._arms);
                            GameObject.Find("GameManager").GetComponent<GameStart>().removePatchFromCharacter("Avatar", GameObject.Find("GameManager").GetComponent<Player>()._legs);
                        }

                    }
                    else
                    {
                        GameObject.Find("GameManager").GetComponent<GameStart>().addPatchToCharacter("Avatar", action_params[0], GameStart.game_state.characters["Avatar"].parent_bones);
                    }
                    string[] s = { "Avatar"};
                    GameStart.game_state.characters["Avatar"].replaceCharacterIdleNoDelay(GameStart.game_state.characters["Avatar"].animId_idle);

                    break;
                case "wearClothingType":
                    Debug.Log("wearClothingType");
                    DialogueManager.local_avatar_clothing_type = action_params[0];
                    DialogueManager.local_avatar_secondary_lothing_option = action_params[1];
                    GetComponent<Player>().changeClothes(action_params[0], action_params[1], DialogueManager.local_avatar_onscreen_name);
                    break;
                case "setQuidditchHelmetEquipped":
                    if (Predicate.parsePredicate(action_params[0]))
                        GetComponent<Player>().setQuidditchHelmet();
                    break;
                case "setForcedQuidditchPosition":
                    DialogueManager.local_avatar_quidditch_position = action_params[0];
                    break;
                case "setOpponentHouse":
                    DialogueManager.local_avatar_opponent_house = action_params[0];
                    break;
                default:
                    Debug.LogWarning("Unknown event type " + Configs.config_script_events.ScriptEvents[event_name].action[event_index]);
                    break;
            }

        }
        if (Configs.config_script_events.ScriptEvents[event_name].type == "Sequential")
        {
            StartCoroutine(waitSequentialEvents(Configs.config_script_events.ScriptEvents[event_name].sequenceIds, Configs.config_script_events.ScriptEvents[event_name].messageAndKeys)); //We need to complete message and keys before activating sequences
        }
        return event_time;
    }

    IEnumerator waitSequentialEvents(string[] sequences, string[][] message_and_keys)
    {
        Debug.Log("Sequential events");
        if (message_and_keys != null)
        {
            bool message_keys_complete = false;

            while (message_keys_complete == false)
            {
                for (int i = 0; i < message_and_keys.Length; i++)
                {
                    if (message_and_keys[i][0] == "CharMovementEnded")
                    {
                        if (GameStart.game_state.characters.ContainsKey(message_and_keys[i][1]))
                        {
                            if (GameStart.game_state.characters[message_and_keys[i][1]].character_state == CharacterManager.CharacterState.Idle)
                            {
                                message_and_keys[i][0] = "";
                                message_and_keys[i][1] = "";
                            }
                        }
                        else
                        {
                            message_and_keys[i][0] = "";
                            message_and_keys[i][1] = "";
                        }
                    }
                }

                message_keys_complete = true;
                for (int i = 0; i < message_and_keys.Length; i++)
                {
                    if (!(message_and_keys[i][0] == "" && message_and_keys[i][1] == ""))
                    {
                        message_keys_complete = false;
                    }
                }
                yield return null;
            }
        }
        foreach (string sequence in sequences)
        {

            activateEvent(sequence);
        }
    }


    public void Update()
    {
        runImmediateEvents();
    }

    public void runImmediateEvents()
    {
        block_duration -= Time.deltaTime;
        if (block_duration <= 0.0f)
        {
            GetComponent<DialogueManager>().waiting_for_dialogue = true;
            block_duration = 0.0f;
        }

        if (block_duration > 0.0f)
        {
            if (!GetComponent<DialogueManager>().in_bubble)
            {
                GetComponent<DialogueManager>().waiting_for_dialogue = false;
                GetComponent<DialogueManager>().ui_dialogue.SetActive(false);
            }
        }

        if (block_duration > 1000) //Cast a spell
        {
            block_duration = 1f;
        }

        while (event_stack.Count != 0 && block_duration == 0.0f && total_block == false)
        {
            block_duration = activateEvent(event_stack[0]);
            event_stack.RemoveAt(0);
        }

        if (GameStart.game_state != null)
        {
            if (event_stack.Count == 0 && block_duration == 0.0f && total_block == false && GameStart.game_state.state == GameState.State.StateQuidditch && GameStart.quidditch_manager.state == Quidditch.State.state_waiting_enter_events)
            {
                GameStart.quidditch_manager.enterEventsCallback();
            }
            else if (event_stack.Count == 0 && block_duration == 0.0f && total_block == false && GameStart.game_state.state == GameState.State.StateQuidditch && GameStart.quidditch_manager.state == Quidditch.State.state_waiting_exit_events)
            {
                GameStart.quidditch_manager.exitEventsCallback();
            }
        }

        if (blocking_key == "ScreenFadeComplete")
        {
            blocking_message = "";
            blocking_key = "";
            block_duration = 0.85f;
            total_block = false;
        }
        if (blocking_message == "ScreenFadeComplete")
        {
            blocking_message = "";
            blocking_key = "";
            block_duration = 0.85f;
            total_block = false;
        }

        if (blocking_message == "CamAnimFinished") //Sometimes, a blocking key is called after the animation has finished playing. May be related to very precise timing.
        {
            if (blocking_key == last_finished_animation)
            {
                total_block = false;
                blocking_message = "";
                blocking_key = "";
                block_duration = 0.00f;
            }
        }

        for (int i = anim_sequences_to_add.Count - 1; i >= 0; i--)
        {
            if (GameStart.game_state.characters.ContainsKey(anim_sequences_to_add[i][0]))
            {
                if (GameStart.game_state.characters[anim_sequences_to_add[i][0]].character_state == CharacterManager.CharacterState.Idle)
                {
                    Debug.Log("late anim sequence set for " + anim_sequences_to_add[i][0] + " " + anim_sequences_to_add[i][1]);
                    if (GameStart.game_state.characters[anim_sequences_to_add[i][0]].gameObject.GetComponent<CharAnimSequenceHandler>() == null)
                    {
                        GameStart.game_state.characters[anim_sequences_to_add[i][0]].gameObject.AddComponent<CharAnimSequenceHandler>();
                    }
                    GameStart.game_state.characters[anim_sequences_to_add[i][0]].gameObject.GetComponent<CharAnimSequenceHandler>().initAnimSequence(anim_sequences_to_add[i][1], false);
                    anim_sequences_to_add.RemoveAt(i);
                }
            }
            else
            {
                anim_sequences_to_add.RemoveAt(i);
            }

        }
    }

    public void notifyMoveComplete(string character)
    {
        if (blocking_message == "CharMovementEnded" && blocking_key == character)
        {
            Debug.Log("notifymovecomplete " + character);
            total_block = false;
            blocking_message = "";
            blocking_key = "";
            block_duration = 0.00f;
        }
    }

    public void notifyCamAnimFinished(string animation)
    {
        if (blocking_message == "CamAnimFinished" && blocking_key == animation)
        {
            total_block = false;
            blocking_message = "";
            blocking_key = "";
            block_duration = 0.00f;
        }
    }
    public void notifyCharacterAnimationComplete(string character, string animation)
    {
        if (blocking_message == "CharAnimEnded" && blocking_key == character + ":" + animation)
        {
            total_block = false;
            blocking_message = "";
            blocking_key = "";
            block_duration = 0.00f;
        }
    }

    public void notifyPropAnimationComplete(string prop, string animation)
    {
        if (blocking_message == "PropAnimEnded" && blocking_key == prop + ":" + animation)
        {
            total_block = false;
            blocking_message = "";
            blocking_key = "";
            block_duration = 0.00f;
        }
    }

    public void notifySequenceNodeExited(string node_name)
    {
        if (blocking_message == "SequenceNodeExited" && blocking_key == node_name)
        {
            total_block = false;
            blocking_message = "";
            blocking_key = "";
            block_duration = 0.00f;
        }
    }

    public void scenarioTransition()
    {
        if (GameStart.game_state.characters != null)
        {
            foreach (string character in GameStart.game_state.characters.Keys)
            {
                GameStart.game_state.characters[character].clearTurnHeadAt();
                GameStart.game_state.characters[character].clearLookat();
                GameStart.game_state.characters[character].stopCharacterWalk();
            }
        }

        event_stack.Clear();
    }

}