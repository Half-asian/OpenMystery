﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;
namespace UI
{
    class GoalPopup : MonoBehaviour, IGoalPopup
    {
        [SerializeField]
        GameObject _popup;
        [SerializeField]
        Text _title;
        [SerializeField]
        Text _description;
        [SerializeField]
        Vector3 character_spawn_pos;
        GameObject character_gameobject = null;

        public void setPopup(string goal_id)
        {
            if (goal_id != null)
            {
                if (Configs.config_goal.Goals.ContainsKey(goal_id))
                {
                    if (character_gameobject != null)
                        Destroy(character_gameobject);
                    ConfigGoal.Goal goal = Configs.config_goal.Goals[goal_id];
                    _popup.SetActive(true);



                    if (goal.ready_text != null) _description.text = GameStart.dialogue_manager.getLocalDataLine(goal.ready_text); else _description.text = "";
                    if (goal.goal_name != null) _title.text = GameStart.dialogue_manager.getLocalDataLine(goal.goal_name); else _title.text = "";
                    if (goal.characterId != null) ActorSpawn.spawnCharacter(ref character_gameobject, goal.characterId, goal.characterId);
                    if (character_gameobject != null)
                    {
                        character_gameobject.transform.position = character_spawn_pos;
                        //character_gameobject.layer = 6; //3d Menu Layer
                        foreach (SkinnedMeshRenderer smr in character_gameobject.transform.GetComponentsInChildren<SkinnedMeshRenderer>())
                        {
                            smr.renderingLayerMask = 2;
                        }
                    }
                }
                else
                {
                    _popup.SetActive(false);
                    _description.text = "";
                    _title.text = "";
                }
            }
            else
            {
                if (character_gameobject != null) Destroy(character_gameobject);
                _popup.SetActive(false);
                _description.text = "";
                _title.text = "";
            }
        }
    }
}
