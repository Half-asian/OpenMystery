﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;

public class UiManager : MonoBehaviour
{

    private UI.IGoalDropdown _goal_dropdown;
    private UI.IGoalPopup _goal_popup;
    private UiImageLoader _ui_image_loader;

    public GameObject goal_popup_gameobject;
    public GameObject tlsq_menu_gameobject;
    public GameObject goal_dropdown_gameobject;

    public GameObject next_area_button;

    public Text please_wait_text;
    public Text press_space_text;

    public GameObject exit_to_menu_button;
    public GameObject pause_menu;
    public GameObject main_menu;

    UnityEvent<string> _event_goal_dropdown_changed;

    private void Awake()
    {
        _goal_dropdown = GetComponent<UI.IGoalDropdown>();
        _goal_popup = GetComponent<UI.IGoalPopup>();
        _event_goal_dropdown_changed = new UnityEvent<string>();
        _event_goal_dropdown_changed.AddListener(showPopup);
        _ui_image_loader = GetComponent<UiImageLoader>();
    }

    public void setup()
    {
        StartCoroutine(_ui_image_loader.setup());
    }

    public void setMenu()
    {
        _goal_dropdown.setup(_event_goal_dropdown_changed);
        _goal_popup.setPopup(null);
    }

    public void nextAreaButtonClicked()
    {
        GameStart.dungeon_master.nextArea();
    }

    public void exitToMenuButtonClicked()
    {
        GameStart.dungeon_master.exitToMenu();
    }

    public void chapterSelectButtonClicked()
    {
        if (GlobalEngineVariables.launch_mode == "tlsq")
            tlsq_menu_gameobject.SetActive(!tlsq_menu_gameobject.activeSelf);
        goal_popup_gameobject.SetActive(!goal_popup_gameobject.activeSelf);
        goal_dropdown_gameobject.SetActive(!goal_dropdown_gameobject.activeSelf);
    }

    public void startQuestButtonClicked()
    {
        string goal_chain = _goal_dropdown.getCurrentGoalChainId();
        int goal = _goal_dropdown.getCurrentGoalIndex();
        if (goal_chain != null) GameObject.Find("MainMenuCanvas").GetComponent<MainMenu>().startGoal(goal_chain, goal);
    }

    public void showPopup(string goal_id)
    {
        _goal_popup.setPopup(goal_id);
    }


}

namespace UI
{
    interface IGoalDropdown
    {
        void setup(UnityEvent<string> event_goal_dropdown_changed);
        string getCurrentGoalChainId();
        string getCurrentGoalId();
        int getCurrentGoalIndex();
    }

    interface IQuestBox
    {
        void setQuest(string goal_chain_id);
    }

    interface IGoalPopup
    {
        void setPopup(string goal_id);
    }
}

