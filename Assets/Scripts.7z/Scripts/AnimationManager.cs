﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Newtonsoft.Json;
using System.IO;
public class AnimationManager : MonoBehaviour
{
	static ModelManager.c3t loadc3t(string name, string file_type)
	{
		if (name == "" || name == null)
        {
			Debug.LogError("loadc3t name is null or blank");
			return null;
        }

		if (!Configs.config_animation.Animation3D.ContainsKey(name))
		{
			Debug.Log("Not c3t config entry for " + name);
			return null;
		}
		string file_name = Configs.config_animation.Animation3D[name].fileName;
		file_name = file_name.Substring(0, file_name.Length - 4) + "." + file_type;

		if (!System.IO.Directory.Exists(GlobalEngineVariables.assets_folder + "\\animations"))
		{
			return null;
		}

		if (System.IO.Directory.Exists("patches\\animations")){
			if (System.IO.File.Exists("patches\\animations\\" + file_name.Substring(0, file_name.Length - 4) + ".c3t"))
            {
				return ModelManager.c3t.CreateFromJSON("patches\\animations\\" + file_name.Substring(0, file_name.Length - 4) + ".c3t");
			}
        }

		if (System.IO.File.Exists(GlobalEngineVariables.assets_folder + "\\animations\\" + file_name))
		{   //Try to find specific file version

			if (file_type == "c3b")
			{
				return ModelManager.loadc3b(GlobalEngineVariables.assets_folder + "\\animations\\" + file_name);
			}
			else if (file_type == "c3t")
            {
				return ModelManager.c3t.CreateFromJSON(GlobalEngineVariables.assets_folder + "\\animations\\" + file_name);
			}
		}
		Debug.Log("Couldn't find " + GlobalEngineVariables.assets_folder + "\\animations\\" + file_name + ". Looking for another version.");

		DirectoryInfo dir = new DirectoryInfo(GlobalEngineVariables.assets_folder + "\\animations\\");    //If not found, try find any version

		FileInfo[] info = dir.GetFiles(name + "*");
		if (info.Length != 0)
		{
			if (file_type == "c3b" && info[0].ToString().Contains(".c3b"))
			{
				return ModelManager.loadc3b(info[0].ToString());
			}
			else if (file_type == "c3t" && info[0].ToString().Contains(".c3t"))
            {
				return ModelManager.c3t.CreateFromJSON(info[0].ToString());
            }
		}
		Debug.Log("Failed to find model " + name);
		return null;
	}

	public static void processAnimationNode(string name, float animation_length, ModelManager.c3t.Node node, ref Dictionary<string, ModelManager.c3t.Animation.Bone> bone_dict, ref AnimationClip anim_clip, float animationScale, float headAnimationScale, ref List<string> bonemods_activated, Dictionary<string, BoneMod> bone_mods = null, bool is_camera = false, float jt_all_bind_scale_x = 1.0f, float jt_all_bind_scale_y = 1.0f, float jt_all_bind_scale_z = 1.0f)
	{
		name = name + "/" + node.id;

		anim_clip.legacy = true;

		//if (name != "Armature/jt_all_bind")
		if (true)
		{

			bool first = true;
			float prev_w = 0;
			float prev_x = 0;
			float prev_y = 0;
			float prev_z = 0;
			float prev_kt = 0;

			List<Keyframe> key_frames_pos_x = new List<Keyframe>();
			List<Keyframe> key_frames_pos_y = new List<Keyframe>();
			List<Keyframe> key_frames_pos_z = new List<Keyframe>();

			List<Keyframe> key_frames_rot_x = new List<Keyframe>();
			List<Keyframe> key_frames_rot_y = new List<Keyframe>();
			List<Keyframe> key_frames_rot_z = new List<Keyframe>();
			List<Keyframe> key_frames_rot_w = new List<Keyframe>();

			List<Keyframe> key_frames_scale_x = new List<Keyframe>();
			List<Keyframe> key_frames_scale_y = new List<Keyframe>();
			List<Keyframe> key_frames_scale_z = new List<Keyframe>();

			//List<Keyframe> key_frames_aov = new List<Keyframe>();

			string[] split_name = name.Split('/');
			string bone_name = split_name[split_name.Length - 1];
			bool use_bone_mod = false;

			if (bone_mods != null) 
			{
				if (bone_mods.ContainsKey(bone_name))
				{
					use_bone_mod = true;
				}
			}

			if (name == "Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind")
			{
				key_frames_scale_x.Add(new Keyframe(0, headAnimationScale));
				key_frames_scale_y.Add(new Keyframe(0, headAnimationScale));
				key_frames_scale_z.Add(new Keyframe(0, headAnimationScale));
			}

			foreach (ModelManager.c3t.Animation.Bone.Keyframe keyframe in bone_dict[node.id].keyframes)
			{

				if (first == false) //Spazzing fix
                {
					if (keyframe.rotation != null)
					{
						float rotation_difference = Mathf.Abs(prev_x - keyframe.rotation[0]) + Mathf.Abs(prev_y - keyframe.rotation[1]) + Mathf.Abs(prev_z - keyframe.rotation[2]) + Mathf.Abs(prev_w - keyframe.rotation[3]);
						if (rotation_difference > 2.5f)
						{
							keyframe.keytime = prev_kt + 0.00001f;
						}
					}
                }

				if (keyframe.translation != null)
				{
					if (use_bone_mod == true)
					{
						if (bone_mods[bone_name].enabled)
						{

							if (!is_camera)
							{
								key_frames_pos_x.Add(new Keyframe(keyframe.keytime * animation_length, keyframe.translation[0] * -1 + bone_mods[bone_name].translation.x));
								key_frames_pos_y.Add(new Keyframe(keyframe.keytime * animation_length, keyframe.translation[1] + bone_mods[bone_name].translation.y));
								key_frames_pos_z.Add(new Keyframe(keyframe.keytime * animation_length, keyframe.translation[2] + bone_mods[bone_name].translation.z));
							}
							else
							{
								key_frames_pos_x.Add(new Keyframe(keyframe.keytime * animation_length, keyframe.translation[0] * -0.01f + bone_mods[bone_name].translation.x));
								key_frames_pos_y.Add(new Keyframe(keyframe.keytime * animation_length, keyframe.translation[1] * 0.01f + bone_mods[bone_name].translation.y));
								key_frames_pos_z.Add(new Keyframe(keyframe.keytime * animation_length, keyframe.translation[2] * 0.01f + bone_mods[bone_name].translation.z));
							}
						}
                        /*else //jt fucking cam bind
                        {
							Debug.LogError("AAA");
							key_frames_pos_x.Add(new Keyframe(keyframe.keytime * animation_length, CameraManager.main_camera_jt_cam_bind.transform.localPosition.x));
							key_frames_pos_y.Add(new Keyframe(keyframe.keytime * animation_length, CameraManager.main_camera_jt_cam_bind.transform.localPosition.y));
							key_frames_pos_z.Add(new Keyframe(keyframe.keytime * animation_length, CameraManager.main_camera_jt_cam_bind.transform.localPosition.z));
						}*/
					}
					else
					{
						if (!is_camera)
						{
							key_frames_pos_x.Add(new Keyframe(keyframe.keytime * animation_length, keyframe.translation[0] * -1));
							key_frames_pos_y.Add(new Keyframe(keyframe.keytime * animation_length, keyframe.translation[1]));
							key_frames_pos_z.Add(new Keyframe(keyframe.keytime * animation_length, keyframe.translation[2]));
						}
						else //jt_anim bind
						{
							key_frames_pos_x.Add(new Keyframe(keyframe.keytime * animation_length, keyframe.translation[0] * 0.01f));
							key_frames_pos_y.Add(new Keyframe(keyframe.keytime * animation_length, keyframe.translation[1] * 0.01f));
							key_frames_pos_z.Add(new Keyframe(keyframe.keytime * animation_length, keyframe.translation[2] * 0.01f));
						}
					}
				}


				if (keyframe.rotation != null)
				{
					if (use_bone_mod == true)
					{
						if (bone_mods[bone_name].enabled)
						{
							Quaternion bone_quaternion_swizzle = Quaternion.Euler(new Vector3(bone_mods[bone_name].rotation.eulerAngles.y, bone_mods[bone_name].rotation.eulerAngles.x * -1, bone_mods[bone_name].rotation.eulerAngles.z));       //Swizzle X and Y for some reason and -y
							Quaternion resulting_quaternion = new Quaternion(keyframe.rotation[0], keyframe.rotation[1] * -1, keyframe.rotation[2] * -1, keyframe.rotation[3]) * bone_quaternion_swizzle;

							key_frames_rot_x.Add(new Keyframe(keyframe.keytime * animation_length, resulting_quaternion.y));
							key_frames_rot_y.Add(new Keyframe(keyframe.keytime * animation_length, resulting_quaternion.y));
							key_frames_rot_z.Add(new Keyframe(keyframe.keytime * animation_length, resulting_quaternion.z));
							key_frames_rot_w.Add(new Keyframe(keyframe.keytime * animation_length, resulting_quaternion.w));

							prev_x = resulting_quaternion.x;
							prev_y = resulting_quaternion.y;
							prev_z = resulting_quaternion.z;
							prev_w = resulting_quaternion.w;
							first = false;
							prev_kt = keyframe.keytime;
						}

                        else //jt fucking cam bind
                        {
							Vector3 current_rotation = CameraManager.main_camera_jt_cam_bind.transform.localEulerAngles;
							Quaternion cam_bind_anim_quaternion = new Quaternion(keyframe.rotation[0], keyframe.rotation[1], keyframe.rotation[2], keyframe.rotation[3]);
							Vector3 cam_bind_anim_euler = cam_bind_anim_quaternion.eulerAngles;
							Vector3 combined_euler = new Vector3(cam_bind_anim_euler.x, current_rotation.y, cam_bind_anim_euler.z);
							Quaternion final_quaternion = Quaternion.Euler(combined_euler);

							key_frames_rot_x.Add(new Keyframe(keyframe.keytime * animation_length, final_quaternion.x));
							key_frames_rot_y.Add(new Keyframe(keyframe.keytime * animation_length, final_quaternion.y));
							key_frames_rot_z.Add(new Keyframe(keyframe.keytime * animation_length, final_quaternion.z));
							key_frames_rot_w.Add(new Keyframe(keyframe.keytime * animation_length, final_quaternion.w));

							prev_x = keyframe.rotation[0];
							prev_y = keyframe.rotation[1];
							prev_z = keyframe.rotation[2];
							prev_w = keyframe.rotation[3];
							first = false;
							prev_kt = keyframe.keytime;

						}

					}

					else
					{
						if (!is_camera)
						{
							key_frames_rot_x.Add(new Keyframe(keyframe.keytime * animation_length, keyframe.rotation[0]));
							key_frames_rot_y.Add(new Keyframe(keyframe.keytime * animation_length, keyframe.rotation[1] * -1));
							key_frames_rot_z.Add(new Keyframe(keyframe.keytime * animation_length, keyframe.rotation[2] * -1));
							key_frames_rot_w.Add(new Keyframe(keyframe.keytime * animation_length, keyframe.rotation[3]));

							prev_x = keyframe.rotation[0];
							prev_y = keyframe.rotation[1];
							prev_z = keyframe.rotation[2];
							prev_w = keyframe.rotation[3];
							first = false;
							prev_kt = keyframe.keytime;
						}
                        else //jt_anim bind
                        {
							key_frames_rot_x.Add(new Keyframe(keyframe.keytime * animation_length, keyframe.rotation[0]));
							key_frames_rot_y.Add(new Keyframe(keyframe.keytime * animation_length, keyframe.rotation[1]));
							key_frames_rot_z.Add(new Keyframe(keyframe.keytime * animation_length, keyframe.rotation[2]));
							key_frames_rot_w.Add(new Keyframe(keyframe.keytime * animation_length, keyframe.rotation[3]));

							prev_x = keyframe.rotation[0];
							prev_y = keyframe.rotation[1];
							prev_z = keyframe.rotation[2];
							prev_w = keyframe.rotation[3];

							first = false;
							prev_kt = keyframe.keytime;
						}
					}
				}
				if (keyframe.scale != null)
				{

					if (name == "Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind")
					{
						keyframe.scale[0] *= headAnimationScale;
						keyframe.scale[1] *= headAnimationScale;
						keyframe.scale[2] *= headAnimationScale;
					}
					if (use_bone_mod == true)
					{
						if (bone_mods[bone_name].enabled)
						{
							keyframe.scale[0] *= bone_mods[bone_name].scale.x;
							keyframe.scale[2] *= bone_mods[bone_name].scale.y;
							keyframe.scale[1] *= bone_mods[bone_name].scale.z;
						}
					}

					if (name == "Armature/jt_all_bind")
					{
						key_frames_scale_x.Add(new Keyframe(keyframe.keytime * animation_length, keyframe.scale[0] * animationScale)); //why were these switched?
						key_frames_scale_y.Add(new Keyframe(keyframe.keytime * animation_length, keyframe.scale[1] * animationScale));
						key_frames_scale_z.Add(new Keyframe(keyframe.keytime * animation_length, keyframe.scale[2] * animationScale));
						jt_all_bind_scale_x = keyframe.scale[0];
						jt_all_bind_scale_y = keyframe.scale[1];
						jt_all_bind_scale_z = keyframe.scale[2];

					}
					else if (name == "Armature/jt_all_bind/jt_prop_bind")
					{
						key_frames_scale_x.Add(new Keyframe(keyframe.keytime * animation_length, keyframe.scale[0] / jt_all_bind_scale_x)); //why were these switched?
						key_frames_scale_y.Add(new Keyframe(keyframe.keytime * animation_length, keyframe.scale[1] / jt_all_bind_scale_y));
						key_frames_scale_z.Add(new Keyframe(keyframe.keytime * animation_length, keyframe.scale[2] / jt_all_bind_scale_z));
					}
					else
					{
						{
							key_frames_scale_x.Add(new Keyframe(keyframe.keytime * animation_length, keyframe.scale[0])); //why were these switched?
							key_frames_scale_y.Add(new Keyframe(keyframe.keytime * animation_length, keyframe.scale[1]));
							key_frames_scale_z.Add(new Keyframe(keyframe.keytime * animation_length, keyframe.scale[2]));
						}
					}
				}
			}

			string new_name = name;

			foreach (string old in bone_fixes.Keys)
			{
				new_name = new_name.Replace(old, bone_fixes[old]);
			}

			if (bone_mods != null)
			{
				if (standard_bone_to_avatar_bone.ContainsKey(name))
				{
					new_name = standard_bone_to_avatar_bone[name];
				}
			}


			if (new_name != "Armature/jt_all_bind")
			{



				AnimationCurve curve_pos_x = new AnimationCurve(key_frames_pos_x.ToArray());
				anim_clip.SetCurve(new_name, typeof(Transform), "localPosition.x", curve_pos_x);

				AnimationCurve curve_pos_y = new AnimationCurve(key_frames_pos_y.ToArray());
				anim_clip.SetCurve(new_name, typeof(Transform), "localPosition.y", curve_pos_y);

				AnimationCurve curve_pos_z = new AnimationCurve(key_frames_pos_z.ToArray());
				anim_clip.SetCurve(new_name, typeof(Transform), "localPosition.z", curve_pos_z);

				AnimationCurve curve_rot_w = new AnimationCurve(key_frames_rot_w.ToArray());
				anim_clip.SetCurve(new_name, typeof(Transform), "localRotation.w", curve_rot_w);

				AnimationCurve curve_rot_y = new AnimationCurve(key_frames_rot_y.ToArray());
				anim_clip.SetCurve(new_name, typeof(Transform), "localRotation.y", curve_rot_y);

				AnimationCurve curve_rot_z = new AnimationCurve(key_frames_rot_z.ToArray());
				anim_clip.SetCurve(new_name, typeof(Transform), "localRotation.z", curve_rot_z);

				AnimationCurve curve_rot_x = new AnimationCurve(key_frames_rot_x.ToArray());
				anim_clip.SetCurve(new_name, typeof(Transform), "localRotation.x", curve_rot_x);

				AnimationCurve curve_scale_x = new AnimationCurve(key_frames_scale_x.ToArray());
				anim_clip.SetCurve(new_name, typeof(Transform), "localScale.x", curve_scale_x);

				AnimationCurve curve_scale_y = new AnimationCurve(key_frames_scale_y.ToArray());
				anim_clip.SetCurve(new_name, typeof(Transform), "localScale.y", curve_scale_y);

				AnimationCurve curve_scale_z = new AnimationCurve(key_frames_scale_z.ToArray());
				anim_clip.SetCurve(new_name, typeof(Transform), "localScale.z", curve_scale_z);
			}

            else
            {
				/*AnimationCurve curve_pos_x = new AnimationCurve(key_frames_pos_x.ToArray());
				anim_clip.SetCurve(new_name, typeof(Transform), "localPosition.x", curve_pos_x);

				AnimationCurve curve_pos_y = new AnimationCurve(key_frames_pos_y.ToArray());
				anim_clip.SetCurve(new_name, typeof(Transform), "localPosition.y", curve_pos_y);

				AnimationCurve curve_pos_z = new AnimationCurve(key_frames_pos_z.ToArray());
				anim_clip.SetCurve(new_name, typeof(Transform), "localPosition.z", curve_pos_z);

				AnimationCurve curve_rot_w = new AnimationCurve(key_frames_rot_w.ToArray());
				anim_clip.SetCurve(new_name, typeof(Transform), "localRotation.w", curve_rot_w);

				AnimationCurve curve_rot_y = new AnimationCurve(key_frames_rot_y.ToArray());
				anim_clip.SetCurve(new_name, typeof(Transform), "localRotation.y", curve_rot_y);

				AnimationCurve curve_rot_z = new AnimationCurve(key_frames_rot_z.ToArray());
				anim_clip.SetCurve(new_name, typeof(Transform), "localRotation.z", curve_rot_z);

				AnimationCurve curve_rot_x = new AnimationCurve(key_frames_rot_x.ToArray());
				anim_clip.SetCurve(new_name, typeof(Transform), "localRotation.x", curve_rot_x);*/

				AnimationCurve curve_scale_x = new AnimationCurve(key_frames_scale_x.ToArray());
				anim_clip.SetCurve(new_name, typeof(Transform), "localScale.x", curve_scale_x);

				AnimationCurve curve_scale_y = new AnimationCurve(key_frames_scale_y.ToArray());
				anim_clip.SetCurve(new_name, typeof(Transform), "localScale.y", curve_scale_y);

				AnimationCurve curve_scale_z = new AnimationCurve(key_frames_scale_z.ToArray());
				anim_clip.SetCurve(new_name, typeof(Transform), "localScale.z", curve_scale_z);
			}

			/*if (new_name == "Armature/jt_all_bind/jt_cam_bind/jt_anim_bind/jt_aov_bind")
            {
				AnimationCurve fov = new AnimationCurve(key_frames_scale_z.ToArray());

			}*/
		}
        else
        {
			/*List<Keyframe> key_frames_scale_x = new List<Keyframe>();
			List<Keyframe> key_frames_scale_y = new List<Keyframe>();
			List<Keyframe> key_frames_scale_z = new List<Keyframe>();

			key_frames_scale_x.Add(new Keyframe(0, animationScale));
			key_frames_scale_y.Add(new Keyframe(0, animationScale));
			key_frames_scale_z.Add(new Keyframe(0, animationScale));

			AnimationCurve curve_scale_x = new AnimationCurve(key_frames_scale_x.ToArray());
			anim_clip.SetCurve(name, typeof(Transform), "localScale.x", curve_scale_x);

			AnimationCurve curve_scale_y = new AnimationCurve(key_frames_scale_y.ToArray());
			anim_clip.SetCurve(name, typeof(Transform), "localScale.y", curve_scale_y);

			AnimationCurve curve_scale_z = new AnimationCurve(key_frames_scale_z.ToArray());
			anim_clip.SetCurve(name, typeof(Transform), "localScale.z", curve_scale_z);*/
		}

		if (node.children != null)
        {
			foreach (ModelManager.c3t.Node child_node in node.children)
            {
				processAnimationNode(name, animation_length, child_node, ref bone_dict, ref anim_clip, animationScale, headAnimationScale, ref bonemods_activated, bone_mods, is_camera, jt_all_bind_scale_x, jt_all_bind_scale_y, jt_all_bind_scale_z);
            }
        }
	}

	static Dictionary<string, string> standard_bone_to_avatar_bone = new Dictionary<string, string>
	{
		//lowerLip1_Joint_bind
		["Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind/jaw1_Joint_bind/lowerLip1_Joint_bind"] = "Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind/jaw1_Joint_bind/jawCorners_MOD_Joint_bind/jt_lowLipParent_MOD_bind/lowerLip1_Joint_bind",
		//nose1_Joint_bind
		["Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind/nose1_Joint_bind"] = "Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind/jt_nose_MOD_bind/jt_noseParent_MOD_bind/nose1_Joint_bind",
		//nostril1_Joint_bind
		["Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind/nose1_Joint_bind/nostril1_Joint_bind"] = "Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind/jt_nose_MOD_bind/jt_noseParent_MOD_bind/nose1_Joint_bind/nostril1_Joint_bind",
		//leftUpperLid1_Joint_bind
		["Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind/leftUpperLid1_Joint_bind"] = "Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind/jt_L_eye_MOD_bind/jt_L_eyeParent_MOD_bind/leftUpperLid1_Joint_bind",
		//leftLowerLid1_Joint_bind
		["Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind/leftLowerLid1_Joint_bind"] = "Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind/jt_L_eye_MOD_bind/jt_L_eyeParent_MOD_bind/leftLowerLid1_Joint_bind",
		//leftEye1_EyeballJoint_bind
		["Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind/leftEye1_EyeballJoint_bind"] = "Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind/jt_L_eye_MOD_bind/jt_L_eyeParent_MOD_bind/leftEye1_EyeballJoint_bind",
		//rightUpperLid1_Joint_bind
		["Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind/rightUpperLid1_Joint_bind"] = "Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind/jt_R_eye_MOD_bind/jt_R_eyeParent_MOD_bind/rightUpperLid1_Joint_bind",
		//rightLowerLid1_Joint_bind
		["Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind/rightLowerLid1_Joint_bind"] = "Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind/jt_R_eye_MOD_bind/jt_R_eyeParent_MOD_bind/rightLowerLid1_Joint_bind",
		//rightEye1_EyeballJoint_bind
		["Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind/rightEye1_EyeballJoint_bind"] = "Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind/jt_R_eye_MOD_bind/jt_R_eyeParent_MOD_bind/rightEye1_EyeballJoint_bind",
		//leftLip1_Joint_bind
		["Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind/leftLip1_Joint_bind"] = "Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind/jt_mouth_MOD_bind/jt_mouthParent_bind/leftLip1_Joint_bind",
		//upperLip1_Joint_bind
		["Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind/upperLip1_Joint_bind"] = "Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind/jt_mouth_MOD_bind/jt_mouthParent_bind/upperLip1_Joint_bind",
		//rightLip1_Joint_bind
		["Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind/rightLip1_Joint_bind"] = "Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind/jt_mouth_MOD_bind/jt_mouthParent_bind/rightLip1_Joint_bind",
	};

	static Dictionary<string, string> boneMODName_to_skeleton = new Dictionary<string, string>
	{
		["chin_MOD_Joint_bind"] = "Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind/jaw1_Joint_bind/chin_MOD_Joint_bind",
		["jawCorners_MOD_Joint_bind"] = "Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind/jaw1_Joint_bind/jawCorners_MOD_Joint_bind",
		["jt_lowLipParent_MOD_bind"] = "Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind/jaw1_Joint_bind/jawCorners_MOD_Joint_bind/jt_lowLipParent_MOD_bind",
		["jt_nose_MOD_bind"] = "Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind/jt_nose_MOD_bind",
		["jt_noseParent_MOD_bind"] = "Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind/jt_nose_MOD_bind/jt_noseParent_MOD_bind",
		["jt_noseBridge_MOD_bind"] = "Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind/jt_noseBridge_MOD_bind",
		["jt_L_eye_MOD_bind"] = "Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind/jt_L_eye_MOD_bind",
		["jt_L_eyeParent_MOD_bind"] = "Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind/jt_L_eye_MOD_bind/jt_L_eyeParent_MOD_bind",
		["jt_R_eye_MOD_bind"] = "Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind/jt_R_eye_MOD_bind",
		["jt_R_eyeParent_MOD_bind"] = "Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind/jt_R_eye_MOD_bind/jt_R_eyeParent_MOD_bind",
		["jt_mouth_MOD_bind"] = "Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind/jt_mouth_MOD_bind",
	};

	static Dictionary<string, Vector3> boneMODDefault_position = new Dictionary<string, Vector3>
	{
		["chin_MOD_Joint_bind"] = new Vector3(1.400244e-16f, -3.916735f, 2.928557f),
		["jawCorners_MOD_Joint_bind"] = new Vector3(0.00242094f, -1.961419f, -0.2943561f),
		["jt_lowLipParent_MOD_bind"] = new Vector3(-1.387779e-16f, 1.961419f, 0.294366f),
		["jt_nose_MOD_bind"] = new Vector3(-0.4869505f, 3.511287e-14f, 4.476315f),
		["jt_noseParent_MOD_bind"] = new Vector3(-3.489662e-14f, -0.4869505f, -4.476315f),
		["jt_noseBridge_MOD_bind"] = new Vector3(-2.376049f, 3.61496e-14f, 4.345019f),
		["jt_L_eye_MOD_bind"] = new Vector3(-2.574324f, -1.844644f, 3.032392f),
		["jt_L_eyeParent_MOD_bind"] = new Vector3(1.844644f, -2.574573f, -3.023612f),
		["jt_R_eye_MOD_bind"] = new Vector3(-2.574324f, 1.844644f, 3.032392f),
		["jt_R_eyeParent_MOD_bind"] = new Vector3(-1.844644f, 2.574573f, 3.023612f),
		["jt_mouth_MOD_bind"] = new Vector3(0.9160487f, -2.145447e-15f, 4.235064f),
	};

	static Dictionary<string, Quaternion> boneMODDefault_rotation = new Dictionary<string, Quaternion>
	{
		["chin_MOD_Joint_bind"] = Quaternion.Euler(new Vector3(0, 0, 0)),
		["jawCorners_MOD_Joint_bind"] = Quaternion.Euler(new Vector3(0, -0.471f, 0)),
		["jt_lowLipParent_MOD_bind"] = Quaternion.Euler(new Vector3(0, 0.471f, 0)),
		["jt_nose_MOD_bind"] = Quaternion.Euler(new Vector3(0, 0, 90)),
		["jt_noseParent_MOD_bind"] = Quaternion.Euler(new Vector3(0, 0, -90)),
		["jt_noseBridge_MOD_bind"] = Quaternion.Euler(new Vector3(0, 0, 90)),
		["jt_L_eye_MOD_bind"] = Quaternion.Euler(new Vector3(0, 0, 90)),
		["jt_L_eyeParent_MOD_bind"] = Quaternion.Euler(new Vector3(0, 0, -90)), //0, 0, -90
		["jt_R_eye_MOD_bind"] = Quaternion.Euler(new Vector3(0, 180, 90)), //Should be 0, 180, 90
		["jt_R_eyeParent_MOD_bind"] = Quaternion.Euler(new Vector3(0, 180, 90)), //Should be 0, 180, 90
		["jt_mouth_MOD_bind"] = Quaternion.Euler(new Vector3(0, 0, 0)),
	};

	static Dictionary<string, string> bone_fixes = new Dictionary<string, string>
	{
		["jt_all_bind1"] = "jt_all_bind", //Just why
		["jt_all_bind2"] = "jt_all_bind",
		["jt_all_bind3"] = "jt_all_bind",
		["jt_all_bind4"] = "jt_all_bind",
		["jt_all_bind5"] = "jt_all_bind",
	};
	public static void setBoneMODMods(ref AnimationClip anim_clip, ref Dictionary<string, BoneMod> bone_mods)
    {
		foreach (string key in bone_mods.Keys)
		{
			if (key.Contains("MOD"))
			{
				List<Keyframe> key_frames_pos_x = new List<Keyframe>();
				List<Keyframe> key_frames_pos_y = new List<Keyframe>();
				List<Keyframe> key_frames_pos_z = new List<Keyframe>();

				List<Keyframe> key_frames_rot_x = new List<Keyframe>();
				List<Keyframe> key_frames_rot_y = new List<Keyframe>();
				List<Keyframe> key_frames_rot_z = new List<Keyframe>();
				List<Keyframe> key_frames_rot_w = new List<Keyframe>();

				List<Keyframe> key_frames_scale_x = new List<Keyframe>();
				List<Keyframe> key_frames_scale_y = new List<Keyframe>();
				List<Keyframe> key_frames_scale_z = new List<Keyframe>();

				key_frames_pos_x.Add(new Keyframe(0, bone_mods[key].translation[0] + boneMODDefault_position[key].x));
				key_frames_pos_y.Add(new Keyframe(0, bone_mods[key].translation[1] + boneMODDefault_position[key].y));
				key_frames_pos_z.Add(new Keyframe(0, bone_mods[key].translation[2] + boneMODDefault_position[key].z));



				Quaternion resulting_quaternion = bone_mods[key].rotation * boneMODDefault_rotation[key];

				key_frames_rot_x.Add(new Keyframe(0, resulting_quaternion.x));
				key_frames_rot_y.Add(new Keyframe(0, resulting_quaternion.y));
				key_frames_rot_z.Add(new Keyframe(0, resulting_quaternion.z));
				key_frames_rot_w.Add(new Keyframe(0, resulting_quaternion.w));



				key_frames_scale_x.Add(new Keyframe(0, bone_mods[key].scale[0]));
				key_frames_scale_y.Add(new Keyframe(0, bone_mods[key].scale[1]));
				key_frames_scale_z.Add(new Keyframe(0, bone_mods[key].scale[2]));



				string bone_full_name = boneMODName_to_skeleton[key];

				AnimationCurve curve_pos_x = new AnimationCurve(key_frames_pos_x.ToArray());
				anim_clip.SetCurve(bone_full_name, typeof(Transform), "localPosition.x", curve_pos_x);

				AnimationCurve curve_pos_y = new AnimationCurve(key_frames_pos_y.ToArray());
				anim_clip.SetCurve(bone_full_name, typeof(Transform), "localPosition.y", curve_pos_y);

				AnimationCurve curve_pos_z = new AnimationCurve(key_frames_pos_z.ToArray());
				anim_clip.SetCurve(bone_full_name, typeof(Transform), "localPosition.z", curve_pos_z);

				AnimationCurve curve_rot_w = new AnimationCurve(key_frames_rot_w.ToArray());
				anim_clip.SetCurve(bone_full_name, typeof(Transform), "localRotation.w", curve_rot_w);

				AnimationCurve curve_rot_y = new AnimationCurve(key_frames_rot_y.ToArray());
				anim_clip.SetCurve(bone_full_name, typeof(Transform), "localRotation.y", curve_rot_y);

				AnimationCurve curve_rot_z = new AnimationCurve(key_frames_rot_z.ToArray());
				anim_clip.SetCurve(bone_full_name, typeof(Transform), "localRotation.z", curve_rot_z);

				AnimationCurve curve_rot_x = new AnimationCurve(key_frames_rot_x.ToArray());
				anim_clip.SetCurve(bone_full_name, typeof(Transform), "localRotation.x", curve_rot_x);

				AnimationCurve curve_scale_x = new AnimationCurve(key_frames_scale_x.ToArray());
				anim_clip.SetCurve(bone_full_name, typeof(Transform), "localScale.x", curve_scale_x);

				AnimationCurve curve_scale_y = new AnimationCurve(key_frames_scale_y.ToArray());
				anim_clip.SetCurve(bone_full_name, typeof(Transform), "localScale.y", curve_scale_y);

				AnimationCurve curve_scale_z = new AnimationCurve(key_frames_scale_z.ToArray());
				anim_clip.SetCurve(bone_full_name, typeof(Transform), "localScale.z", curve_scale_z);
			}
		}


	}

	public class BoneMod
    {
		public BoneMod(Vector3 _p, Quaternion _r, Vector3 _s)
        {
			translation = _p;
			rotation = _r;
			scale = _s;
			enabled = true;
        }

		public BoneMod(bool _enabled)
        {
			enabled = _enabled;
        }

		public bool enabled;
		public Vector3 translation;
		public Quaternion rotation;
		public Vector3 scale;
	}

	public static AnimationClip loadAnimationClip(string name, string file_type, ConfigHPActorInfo._HPActorInfo character, Dictionary<string, BoneMod> bone_mods = null, bool is_camera = false)
    {
		if (name == null || name == "")
        {
			Debug.LogError("loadAnimatonClip name is null or blank.");
			return null;
        }

		float animationScale = 1.0f;
		float headAnimationScale = 1.0f;
		if (character != null)
        {
			animationScale = character.animationScale;
			headAnimationScale = character.headAnimationScale;
        }

		ModelManager.c3t animation_c3t = loadc3t(name, file_type);
		if (animation_c3t == null)
        {

			if (name != "")
				Debug.Log("Couldn't find " + "animations\\" + name + ". Skipping.");
			if (!File.ReadAllText("missing_assets.txt").Contains("Couldn't find " + "animations\\" + name))
			{
				StreamWriter writer = new StreamWriter("missing_assets.txt", true);
				writer.WriteLine("Couldn't find " + "animations\\" + name);
				writer.Close();
			}
			return null;
        }

		animation_c3t.animations[0].bone_dict = new Dictionary<string, ModelManager.c3t.Animation.Bone>();

		AnimationClip anim_clip = new AnimationClip();


		foreach (ModelManager.c3t.Animation.Bone bone in animation_c3t.animations[0].bones)
        {

			animation_c3t.animations[0].bone_dict[bone.boneId] = bone;

/*			if (bone_fixes.ContainsKey(bone.boneId))
			{
				animation_c3t.animations[0].bone_dict[bone_fixes[bone.boneId]] = bone;
			}
			else
			{
				animation_c3t.animations[0].bone_dict[bone.boneId] = bone;
			}*/
        }

		foreach (ModelManager.c3t.Node node in animation_c3t.nodes)
        {
			List<string> bone_mods_activated = new List<string>();
			processAnimationNode("Armature", animation_c3t.animations[0].length, node, ref animation_c3t.animations[0].bone_dict, ref anim_clip, animationScale, headAnimationScale, ref bone_mods_activated, bone_mods, is_camera);
		}

		//Add all MOD bones

		if (bone_mods != null)
		{
			setBoneMODMods(ref anim_clip, ref bone_mods);
		}


		return anim_clip;
    }

	public class AnimationClipOverrides : List<KeyValuePair<AnimationClip, AnimationClip>>
	{
		public AnimationClipOverrides(int capacity) : base(capacity) { }

		public AnimationClip this[string name]
		{
			get { return this.Find(x => x.Key.name.Equals(name)).Value; }
			set
			{
				int index = this.FindIndex(x => x.Key.name.Equals(name));
				if (index != -1)
					this[index] = new KeyValuePair<AnimationClip, AnimationClip>(this[index].Key, value);
			}
		}
	}
}