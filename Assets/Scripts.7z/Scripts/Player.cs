﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Net.NetworkInformation;
using System.Text.RegularExpressions;
using TMPro;
using UnityEditor;
using UnityEngine;
using System.IO;
using System.Runtime.CompilerServices;
using UnityEngine.XR;
using UnityEngine.UI;

public class Player : MonoBehaviour
{


    public SkinnedMeshRenderer _renderer;
    public List<SkinnedMeshRenderer> _rendererTargets;


    public string[] _list_male_eyes_prefabs;
    public int _male_eyes_index;

    public string[] _list_male_nose_prefabs;
    public int _male_nose_index;

    public string[] _list_male_mouth_prefabs;
    public int _male_mouth_index;

    public string[] _list_male_head_prefabs;
    public int _male_head_index;

    public string[] _list_male_outfit_prefabs;
    public int _male_outfit_index;

    public string[] _list_male_hair_prefabs;
    public int _male_hair_index;


    public string[] _list_female_eyes_prefabs;
    public int _female_eyes_index;

    public string[] _list_female_nose_prefabs;
    public int _female_nose_index;

    public string[] _list_female_mouth_prefabs;
    public int _female_mouth_index;

    public string[] _list_female_head_prefabs;
    public int _female_head_index;

    public string[] _list_female_outfit_prefabs;
    public int _female_outfit_index;

    public string[] _list_female_hair_prefabs;
    public int _female_hair_index;

    public string[] _list_wand_prefabs;
    public int _wand_index;

    public Material[] _list_male_skin_colours;
    public Material[] _list_male_hand_skin_colours;
    public int _male_skin_colour_index;

    public Material[] _list_female_skin_colours;
    public Material[] _list_female_hand_skin_colours;
    public int _female_skin_colour_index;

    //public Material[] _list_eye_colours;
    //public int _eye_colour_index;

    //public GameObject _hands_prefab; //Hands are the same between male and female. We don't need to store in a list.

    public string[] _list_hands_prefabs;
    public int hands_index;


    public GameObject[] _accessories_prefabs;
    public bool[] _accessories_selections;

    Color _mouth_color;

    public GameObject _eyes;
    public GameObject _nose;
    public GameObject _mouth;
    public GameObject _head;
    public GameObject _outfit;
    public GameObject _outfit_bottom;
    public GameObject _hair;
    public GameObject _hands;
    public GameObject _forearms;
    public GameObject _wand;
    public GameObject _arms;
    public GameObject _legs;
    
    public GameObject[] _custom;

    public string _first_name;
    public InputField _first_name_input;
    public string _last_name;
    public InputField _last_name_input;
    public string _gender;
    public string _house;

    public float _hair_add_R;
    public Slider _hair_add_R_slider;
    public float _hair_add_G;
    public Slider _hair_add_G_slider;
    public float _hair_add_B;
    public Slider _hair_add_B_slider;

    public float _eye_add_R;
    public Slider _eye_add_R_slider;
    public float _eye_add_G;
    public Slider _eye_add_G_slider;
    public float _eye_add_B;
    public Slider _eye_add_B_slider;

    public float _skin_brightness;
    public Slider _skin_brightness_slider;
    public float _skin_contrast;
    public Slider _skin_contrast_slider;

    public float _chin_size;
    public Slider _chin_size_slider;
    public float _jaw_size;
    public Slider _jaw_size_slider;

    public float _bridge_height;
    public Slider _bridge_height_slider;
    public float _bridge_length;
    public Slider _bridge_length_slider;
    public float _bridge_width;
    public Slider _bridge_width_slider;
    public float _roundness;
    public Slider _roundness_slider;
    public float _tip_height;
    public Slider _tip_height_slider;
    public float _tip_length;
    public Slider _tip_length_slider;
    public float _twist;
    public Slider _twist_slider;
    public float _tip_width;
    public Slider _tip_width_slider;

    public float _eye_closeness;
    public Slider _eye_closeness_slider;
    public float _eye_size;
    public Slider _eye_size_slider;
    public float _eye_height;
    public Slider _eye_height_slider;
    public float _brow_size;
    public Slider _brow_size_slider;

    public List<string> _custom_character_options;

    public Dictionary<string, AnimationManager.BoneMod> _bonemods = new Dictionary<string, AnimationManager.BoneMod>();
    Quaternion player_rot = Quaternion.Euler(new Vector3(270, 0, -270));

    public enum ClothingType
    {
        Scripted,
        QuidditchRobesWalk,
        QuidditchRobesFly,
        Base, //wearCasual
        ClassRobes,
    };


    public void changeClothes(string clothing_type, string secondary_clothing_option, string avatar_name)
    {
        Debug.Log("CHANGE CLOTHES MUTHAFUCKER");
        switch (clothing_type)
        {
            case "QuidditchRobesWalk":
                Debug.Log("CHANGE CLOTHES MUTHAFUCKER WALK");

                GetComponent<GameStart>().removePatchFromCharacter(DialogueManager.local_avatar_onscreen_name, GameObject.Find("GameManager").GetComponent<Player>()._outfit);
                GetComponent<GameStart>().removePatchFromCharacter(DialogueManager.local_avatar_onscreen_name, GameObject.Find("GameManager").GetComponent<Player>()._outfit_bottom);

                if (secondary_clothing_option == "houseCup")
                {
                    if (DialogueManager.local_avatar_gender == "male")
                        GetComponent<Player>()._outfit = GameObject.Find("GameManager").GetComponent<GameStart>().addPatchToCharacter(DialogueManager.local_avatar_onscreen_name, "o_male_QuidditchHouseOfficialRobes_FULL_skin", GameStart.game_state.characters[DialogueManager.local_avatar_onscreen_name].parent_bones);
                    else
                        GetComponent<Player>()._outfit = GameObject.Find("GameManager").GetComponent<GameStart>().addPatchToCharacter(DialogueManager.local_avatar_onscreen_name, "o_female_QuidditchHouseOfficialRobes_FULL_skin", GameStart.game_state.characters[DialogueManager.local_avatar_onscreen_name].parent_bones);
                }
                else if (secondary_clothing_option == "friendly")
                {
                    if (DialogueManager.local_avatar_gender == "male")
                        GetComponent<Player>()._outfit = GameObject.Find("GameManager").GetComponent<GameStart>().addPatchToCharacter(DialogueManager.local_avatar_onscreen_name, "o_male_QuidditchHousePracticeRobesHome_FULL_skin", GameStart.game_state.characters[DialogueManager.local_avatar_onscreen_name].parent_bones);
                    else
                        GetComponent<Player>()._outfit = GameObject.Find("GameManager").GetComponent<GameStart>().addPatchToCharacter(DialogueManager.local_avatar_onscreen_name, "o_female_QuidditchHousePracticeRobesHome_FULL_skin", GameStart.game_state.characters[DialogueManager.local_avatar_onscreen_name].parent_bones);
                }
                else if (secondary_clothing_option == "preTryout")
                {
                    if (DialogueManager.local_avatar_gender == "male")
                        GetComponent<Player>()._outfit = GameObject.Find("GameManager").GetComponent<GameStart>().addPatchToCharacter(DialogueManager.local_avatar_onscreen_name, "o_male_QuidditchHouseTryoutRobesHome_FULL_skin", GameStart.game_state.characters[DialogueManager.local_avatar_onscreen_name].parent_bones);
                    else
                        GetComponent<Player>()._outfit = GameObject.Find("GameManager").GetComponent<GameStart>().addPatchToCharacter(DialogueManager.local_avatar_onscreen_name, "o_female_QuidditchHouseTryoutRobesHome_FULL_skin", GameStart.game_state.characters[DialogueManager.local_avatar_onscreen_name].parent_bones);
                }
                GetComponent<Player>()._outfit = GameObject.Find("GameManager").GetComponent<Player>()._outfit_bottom;
                break;


            case "QuidditchRobesFly":
                GetComponent<GameStart>().removePatchFromCharacter(DialogueManager.local_avatar_onscreen_name, GameObject.Find("GameManager").GetComponent<Player>()._outfit);
                GetComponent<GameStart>().removePatchFromCharacter(DialogueManager.local_avatar_onscreen_name, GameObject.Find("GameManager").GetComponent<Player>()._outfit_bottom);
                Debug.Log("CHANGE CLOTHES MUTHAFUCKER FLY");
                if (secondary_clothing_option == "houseCup")
                {
                    if (DialogueManager.local_avatar_gender == "male")
                        GetComponent<Player>()._outfit = GameObject.Find("GameManager").GetComponent<GameStart>().addPatchToCharacter(DialogueManager.local_avatar_onscreen_name, "o_male_QuidditchHouseOfficialRobes_flying_FULL_skin", GameStart.game_state.characters[DialogueManager.local_avatar_onscreen_name].parent_bones);
                    else
                        GetComponent<Player>()._outfit = GameObject.Find("GameManager").GetComponent<GameStart>().addPatchToCharacter(DialogueManager.local_avatar_onscreen_name, "o_female_QuidditchHouseOfficialRobes_flying_FULL_skin", GameStart.game_state.characters[DialogueManager.local_avatar_onscreen_name].parent_bones);
                }
                else if (secondary_clothing_option == "friendly")
                {
                    if (DialogueManager.local_avatar_gender == "male")
                        GetComponent<Player>()._outfit = GameObject.Find("GameManager").GetComponent<GameStart>().addPatchToCharacter(DialogueManager.local_avatar_onscreen_name, "o_male_QuidditchHousePracticeRobesHome_flying_FULL_skin", GameStart.game_state.characters[DialogueManager.local_avatar_onscreen_name].parent_bones);
                    else
                        GetComponent<Player>()._outfit = GameObject.Find("GameManager").GetComponent<GameStart>().addPatchToCharacter(DialogueManager.local_avatar_onscreen_name, "o_female_QuidditchHousePracticeRobesHome_flying_FULL_skin", GameStart.game_state.characters[DialogueManager.local_avatar_onscreen_name].parent_bones);
                }
                else if (secondary_clothing_option == "preTryout")
                {
                    if (DialogueManager.local_avatar_gender == "male")
                        GetComponent<Player>()._outfit = GameObject.Find("GameManager").GetComponent<GameStart>().addPatchToCharacter(DialogueManager.local_avatar_onscreen_name, "o_male_QuidditchHouseTryoutRobesHome_flying_FULL_skin", GameStart.game_state.characters[DialogueManager.local_avatar_onscreen_name].parent_bones);
                    else
                        GetComponent<Player>()._outfit = GameObject.Find("GameManager").GetComponent<GameStart>().addPatchToCharacter(DialogueManager.local_avatar_onscreen_name, "o_female_QuidditchHouseTryoutRobesHome_flying_FULL_skin", GameStart.game_state.characters[DialogueManager.local_avatar_onscreen_name].parent_bones);
                }
                GetComponent<Player>()._outfit = GameObject.Find("GameManager").GetComponent<Player>()._outfit_bottom;
                break;
        }
    }

    public void setQuidditchHelmet()
    {
        

        GetComponent<GameStart>().removePatchFromCharacter("Avatar", GameObject.Find("GameManager").GetComponent<Player>()._hair);

        if (DialogueManager.local_avatar_gender == "male")
            GetComponent<Player>()._hair = GameObject.Find("GameManager").GetComponent<GameStart>().addPatchToCharacter(DialogueManager.local_avatar_onscreen_name, "c_male_QuidditchKeeperHelmet_skin", GameStart.game_state.characters["Avatar"].parent_bones);
        else
            GetComponent<Player>()._hair = GameObject.Find("GameManager").GetComponent<GameStart>().addPatchToCharacter(DialogueManager.local_avatar_onscreen_name, "c_female_QuidditchKeeperHelmet_skin", GameStart.game_state.characters["Avatar"].parent_bones);
    }


    void changeSkinColour(Material new_skin, Material new_hand_skin) //Change the players skin colour. Supports base parts only.
    {
        /*if (_head != null)
            _head.GetComponentInChildren<SkinnedMeshRenderer>().material = new_skin;// Material[] { new_skin, _list_eye_colours[_eye_colour_index] };
        if (_eyes != null)
            _eyes.GetComponentInChildren<SkinnedMeshRenderer>().material = new_skin;
        if (_nose != null)
            _nose.GetComponentInChildren<SkinnedMeshRenderer>().material = new_skin;
        if (_mouth != null)
            _mouth.GetComponentInChildren<SkinnedMeshRenderer>().material = new_skin;
        if (_hands != null)
            _hands.GetComponentInChildren<SkinnedMeshRenderer>().material = new_hand_skin;*/
    }


    void removePlayerPiece(GameObject piece)
    {
        if (piece != null)
        {
            _rendererTargets.Remove(piece.GetComponentInChildren<SkinnedMeshRenderer>());
            Destroy(piece);
        }
    }

    void addCustomPiece(GameObject custom_piece) //Imported piece from an asset package
    {
        GameObject piece;
        piece = Instantiate(custom_piece, new Vector3(0, 0, 0), Quaternion.identity);
        piece.transform.parent = this.transform;
        _rendererTargets.Add(piece.GetComponentInChildren<SkinnedMeshRenderer>());
        _custom.Append(piece);
    }

    Dictionary<string, Transform> addPlayerPiece(ref GameObject piece, int piece_index, string[] prefab_list, bool increase_counter) //Base game piece
    {
        if (increase_counter == true)
        {
            piece_index++;
            if (piece_index == prefab_list.Length)
                piece_index = 0;
        }
        return ModelManager.loadModel(ref piece, prefab_list[piece_index], "c3b");
    }

    public void writeCharacterFile(string character_file)
    {
        Debug.Log("Writing character file");
        if (_first_name_input.text != "")
            _first_name = _first_name_input.text;
        if (_last_name_input.text != "")
            _last_name = _last_name_input.text;
        StreamWriter writer = new StreamWriter(character_file, false);
        writer.WriteLine("firstname:" + _first_name);
        writer.WriteLine("lastname:" + _last_name);
        writer.WriteLine("gender:" + _gender);
        writer.WriteLine("house:" + _house);
        if (_head != null)
            writer.WriteLine("eyecolor:" + _eye_add_R + ":" + _eye_add_G + ":" + _eye_add_B);
        if (_hair != null)
            writer.WriteLine("haircolor:" + _hair_add_R + ":" + _hair_add_G + ":" + _hair_add_B);
        if (_head != null)
            writer.WriteLine("head:base:0"); //Only 1 head to choose from for each gender
        if (_hands != null)
            writer.WriteLine("hands:base:0"); //Only 1 base hands to choose from
        if (_gender == "female")
        {
            writer.WriteLine("skin:base:" + _female_skin_colour_index);
            if (_eyes != null)
                writer.WriteLine("eyes:base:" + _female_eyes_index);
            if (_nose != null)
                writer.WriteLine("nose:base:" + _female_nose_index);
            if (_mouth != null)
                writer.WriteLine("mouth:base:" + _female_mouth_index);
            if (_hair != null)
                writer.WriteLine("hair:base:" + _female_hair_index);
            if (_outfit != null)
                writer.WriteLine("outfit:base:" + _female_outfit_index);
        }
        if (_gender == "male")
        {
            writer.WriteLine("skin:base:" + _male_skin_colour_index);
            if (_eyes != null)
                writer.WriteLine("eyes:base:" + _male_eyes_index);
            if (_nose != null)
                writer.WriteLine("nose:base:" + _male_nose_index);
            if (_mouth != null)
                writer.WriteLine("mouth:base:" + _male_mouth_index);
            if (_hair != null)
                writer.WriteLine("hair:base:" + _male_hair_index);
            if (_outfit != null)
                writer.WriteLine("outfit:base:" + _male_outfit_index);
        }

        /*for (int i = 0; i < _bonemods.Length; i++)
        {
            if (_bonemods[i].position.x != 0.0f || _bonemods[i].position.y != 0.0f || _bonemods[i].position.z != 0.0f ||
                _bonemods[i].rotation.x != 0.0f || _bonemods[i].rotation.y != 0.0f || _bonemods[i].rotation.z != 0.0f ||
                _bonemods[i].scale.x != 1.0f || _bonemods[i].scale.y != 1.0f || _bonemods[i].scale.z != 1.0f)
            {
                writer.WriteLine("bonemod:" + _bonemods[i].bone_name + ":" + _bonemods[i].position.x + ":" + _bonemods[i].position.y + ":" + _bonemods[i].position.z + ":"
                + _bonemods[i].rotation.x + ":" + _bonemods[i].rotation.y + ":" + _bonemods[i].rotation.z + ":"
                + _bonemods[i].scale.x + ":" + _bonemods[i].scale.y + ":" + _bonemods[i].scale.z);
            }
        }*/


        if (_custom_character_options != null)
        {
            for (int i = 0; i < _custom_character_options.Count; i++)
                writer.WriteLine(_custom_character_options[i]);
        }
        writer.Close();
    }

    public void setLocalData(string character_file)
    {
        StreamReader reader = new StreamReader(character_file);
        string line = reader.ReadLine();
        while (!string.IsNullOrEmpty(line))
        {
            string[] split_line = line.Split(':');
            switch (split_line[0])
            {
                case "firstname":
                    _first_name = split_line[1];
                    if (_first_name_input != null)
                        _first_name_input.text = _first_name;
                    DialogueManager.local_avatar_first_name = _first_name;
                    DialogueManager.local_avatar_full_name = DialogueManager.local_avatar_first_name + " " + DialogueManager.local_avatar_last_name;

                    break;
                case "lastname":
                    _last_name = split_line[1];
                    if (_last_name_input != null)
                        _last_name_input.text = _last_name;
                    DialogueManager.local_avatar_last_name = _last_name;
                    DialogueManager.local_avatar_full_name = DialogueManager.local_avatar_first_name + " " + DialogueManager.local_avatar_last_name;
                    break;
                case "house":
                    _house = split_line[1];
                    DialogueManager.local_avatar_house = _house;
                    break;
                case "gender":
                    _gender = split_line[1];
                    DialogueManager.local_avatar_gender = _gender;
                    break;
            }
            line = reader.ReadLine();

        }
        reader.Close();
    }

    public Dictionary<string, Transform> readCharacterFile(ref GameObject character_gameobject, string character_file)
    {
        _custom_character_options = new List<string>();
        StreamReader reader = new StreamReader(character_file);
        string line = reader.ReadLine();

        Dictionary<string, Transform> parent_bones = null;

        /*for (int i = 0; i < _renderer.bones.Length; i++)
        {
            _bonemods[i].position.x = 0;
            _bonemods[i].position.y = 0;
            _bonemods[i].position.z = 0;
            _bonemods[i].rotation = Quaternion.Euler(new Vector3(0, 0, 0));
            _bonemods[i].scale.x = 1;
            _bonemods[i].scale.y = 1;
            _bonemods[i].scale.z = 1;
        }*/


        removePlayerPiece(_head);
        removePlayerPiece(_eyes);
        removePlayerPiece(_nose);
        removePlayerPiece(_mouth);
        removePlayerPiece(_outfit);
        removePlayerPiece(_hair);
        removePlayerPiece(_hands);

        while (!string.IsNullOrEmpty(line))
        {
            string[] split_line = line.Split(':');
            switch (split_line[0])
            {
                case "firstname":
                    _first_name = split_line[1];
                    if (_first_name_input != null)
                        _first_name_input.text = _first_name;
                    DialogueManager.local_avatar_first_name = _first_name;
                    DialogueManager.local_avatar_full_name = DialogueManager.local_avatar_first_name + " " + DialogueManager.local_avatar_last_name;

                    break;
                case "lastname":
                    _last_name = split_line[1];
                    if (_last_name_input != null)
                        _last_name_input.text = _last_name;
                    DialogueManager.local_avatar_last_name = _last_name;
                    DialogueManager.local_avatar_full_name = DialogueManager.local_avatar_first_name + " " + DialogueManager.local_avatar_last_name;
                    break;
                case "house":
                    _house = split_line[1];
                    DialogueManager.local_avatar_house = _house;
                    break;
                case "gender":
                    _gender = split_line[1];
                    DialogueManager.local_avatar_gender = _gender;
                    break;
                case "head":
                    if (split_line[1] == "base")
                    {
                        if (_gender == "female")
                            parent_bones = addPlayerPiece(ref _head, _female_head_index, _list_female_head_prefabs, false);
                        else
                            parent_bones = addPlayerPiece(ref _head, _male_head_index, _list_male_head_prefabs, false);
                    }
                    break;
                case "eyes":
                    if (split_line[1] == "base")
                    {
                        if (_gender == "female")
                        {
                            _female_eyes_index = int.Parse(split_line[2]);
                            addPlayerPiece(ref _eyes, _female_eyes_index, _list_female_eyes_prefabs, false);
                        }
                        else
                        {
                            _male_eyes_index = int.Parse(split_line[2]);
                            addPlayerPiece(ref _eyes, _male_eyes_index, _list_male_eyes_prefabs, false);
                        }
                        if (_eyes != null)
                            _eyes.transform.parent = _head.transform;
                    }
                    break;
                case "nose":
                    if (split_line[1] == "base")
                    {
                        if (_gender == "female")
                        {
                            _female_nose_index = int.Parse(split_line[2]);
                            addPlayerPiece(ref _nose, _female_nose_index, _list_female_nose_prefabs, false);
                        }
                        else
                        {
                            _male_eyes_index = int.Parse(split_line[2]);
                            addPlayerPiece(ref _nose, _male_nose_index, _list_male_nose_prefabs, false);
                        }
                        if (_nose != null)
                            _nose.transform.parent = _head.transform;
                    }
                    break;
                case "mouth":
                    if (split_line[1] == "base")
                    {
                        if (_gender == "female")
                        {
                            _female_mouth_index = int.Parse(split_line[2]);
                            addPlayerPiece(ref _mouth, _female_mouth_index, _list_female_mouth_prefabs, false);
                        }
                        else
                        {
                            _male_mouth_index = int.Parse(split_line[2]);
                            addPlayerPiece(ref _mouth, _male_mouth_index, _list_male_mouth_prefabs, false);
                        }
                        if (_mouth != null)
                            _mouth.transform.parent = _head.transform;
                    }
                    break;
                case "outfit":
                    if (split_line[1] == "base")
                    {
                        if (_gender == "female")
                        {
                            _female_outfit_index = int.Parse(split_line[2]);
                            addPlayerPiece(ref _outfit, _female_outfit_index, _list_female_outfit_prefabs, false);
                        }
                        else
                        {
                            _male_outfit_index = int.Parse(split_line[2]);
                            addPlayerPiece(ref _outfit, _male_outfit_index, _list_male_outfit_prefabs, false);
                        }
                        if (_outfit != null)
                            _outfit.transform.parent = _head.transform;
                    }
                    break;
                case "hands":
                    if (split_line[1] == "base")
                    {
                        //_hands = Instantiate(_hands_prefab, new Vector3(0, 0, 0), Quaternion.identity); //Hands can't be swapped in base game
                        //_hands.transform.parent = this.transform;
                        //_rendererTargets.Add(_hands.GetComponentInChildren<SkinnedMeshRenderer>());

                        addPlayerPiece(ref _hands, hands_index, _list_hands_prefabs, false);

                        ModelManager.loadModel(ref _forearms, "c_AvatarForeArms_skin", "c3b");


                        if (_hands != null)
                            _hands.transform.parent = _head.transform;

                        if (_forearms != null)
                            _forearms.transform.parent = _head.transform;
                    }
                    break;
                case "hair":
                    if (split_line[1] == "base")
                    {
                        if (_gender == "female")
                        {
                            _female_hair_index = int.Parse(split_line[2]);
                            addPlayerPiece(ref _hair, _female_hair_index, _list_female_hair_prefabs, false);
                        }
                        else
                        {
                            _male_hair_index = int.Parse(split_line[2]);
                            addPlayerPiece(ref _hair, _male_hair_index, _list_male_hair_prefabs, false);
                        }
                        if (_hair != null)
                            _hair.transform.parent = _head.transform;
                    }
                    break;
                /*case "skin":
                    if (split_line[1] == "base")
                    {
                        if (_gender == "female")
                            _female_skin_colour_index = int.Parse(split_line[2]);
                        else
                            _male_skin_colour_index = int.Parse(split_line[2]);
                    }
                    break;*/
                case "skinbrightness":
                    _skin_brightness = float.Parse(split_line[1]);

                    //_skin_brightness_slider.value = float.Parse(split_line[1]);
                    break;
                case "skincontrast":
                    _skin_contrast = float.Parse(split_line[1]);
                    //_skin_contrast = _skin_contrast_slider.value;

                    //_skin_contrast_slider.value = float.Parse(split_line[1]);
                    break;
                case "custom": //This is an array of options. Put anything custom in here;
                    if (split_line[1] != "base")
                    {
                        var asset_bundle = AssetBundle.LoadFromFile(Path.Combine(Application.streamingAssetsPath, split_line[1]));
                        _custom_character_options.Add(line);
                        if (asset_bundle == null)
                        {
                            Debug.Log("Failed to load AssetBundle!");
                            break;
                        }
                        addCustomPiece(asset_bundle.LoadAsset(split_line[2]) as GameObject);
                    }
                    break;
                case "bonemod":
                    /*for (int i = 0; i < _renderer.bones.Length; i++)
                    {
                        if (_bonemods[i].bone_name == split_line[1])
                        {
                            _bonemods[i].position.x = float.Parse(split_line[2]);
                            _bonemods[i].position.y = float.Parse(split_line[3]);
                            _bonemods[i].position.z = float.Parse(split_line[4]);

                            _bonemods[i].rotation.x = float.Parse(split_line[5]);
                            _bonemods[i].rotation.y = float.Parse(split_line[6]);
                            _bonemods[i].rotation.z = float.Parse(split_line[7]);

                            _bonemods[i].scale.x = float.Parse(split_line[8]);
                            _bonemods[i].scale.y = float.Parse(split_line[9]);
                            _bonemods[i].scale.z = float.Parse(split_line[10]);
                        }
                    }*/
                    if (split_line[1] == "jt_L_eye_MOD_bind")
                    {
                        _bonemods[split_line[1]] = new AnimationManager.BoneMod(
                        new Vector3(float.Parse(split_line[2]) * 100, float.Parse(split_line[3]) * -100, float.Parse(split_line[4]) * -100),
                        Quaternion.Euler(new Vector3(float.Parse(split_line[5]), float.Parse(split_line[6]), float.Parse(split_line[7]))),
                        new Vector3(float.Parse(split_line[8]), float.Parse(split_line[9]), float.Parse(split_line[10])));
                    }
                    else
                    {
                        _bonemods[split_line[1]] = new AnimationManager.BoneMod(
                            new Vector3(float.Parse(split_line[2]) * 100, float.Parse(split_line[3]) * 100, float.Parse(split_line[4]) * 100),
                            Quaternion.Euler(new Vector3(float.Parse(split_line[5]), float.Parse(split_line[6]), float.Parse(split_line[7]))),
                            new Vector3(float.Parse(split_line[8]), float.Parse(split_line[9]), float.Parse(split_line[10])));
                    }
                    break;
                case "haircolor":
                    _hair_add_R = float.Parse(split_line[1]);
                    _hair_add_G = float.Parse(split_line[2]);
                    _hair_add_B = float.Parse(split_line[3]);
                    break;
                case "eyecolor":
                    _eye_add_R = float.Parse(split_line[1]);
                    _eye_add_G = float.Parse(split_line[2]);
                    _eye_add_B = float.Parse(split_line[3]);
                    break;
                case "eyepupilcolor":
                    /*if (_head != null)
                    {
                        if (_head.GetComponentInChildren<SkinnedMeshRenderer>().materials[1].HasProperty("pupil"))
                            _head.GetComponentInChildren<SkinnedMeshRenderer>().materials[1].SetColor("pupil", new Color(float.Parse(split_line[1]), float.Parse(split_line[2]), float.Parse(split_line[3])));
                    }*/
                    break;
                case "eyescleracolor":
                    /*if (_head != null)
                    {
                        if (_head.GetComponentInChildren<SkinnedMeshRenderer>().materials[1].HasProperty("sclera"))
                            _head.GetComponentInChildren<SkinnedMeshRenderer>().materials[1].SetColor("sclera", new Color(float.Parse(split_line[1]), float.Parse(split_line[2]), float.Parse(split_line[3])));
                    }*/
                    break;
                case "browcolor":
                    if (_head != null)
                    {
                        if (_head.GetComponentInChildren<SkinnedMeshRenderer>().material.HasProperty("u_browColor"))
                            _head.GetComponentInChildren<SkinnedMeshRenderer>().material.SetColor("u_browColor", new Color(float.Parse(split_line[1]), float.Parse(split_line[2]), float.Parse(split_line[3])));
                    }
                    break;
                case "mouthcolor":
                    _mouth_color = new Color(float.Parse(split_line[1]), float.Parse(split_line[2]), float.Parse(split_line[3]));
                    break;
                default:
                    Debug.Log("Unknown Line " + split_line[0]);
                    break;
            }
            line = reader.ReadLine();
        }

        addPlayerPiece(ref _wand, _wand_index, _list_wand_prefabs, false);
        if (_wand != null)
            _wand.transform.parent = _head.transform;

        reader.Close();
        _female_skin_colour_index = 0;
        _male_skin_colour_index = 0;
        /*if (_gender == "female")
            changeSkinColour(_list_female_skin_colours[_female_skin_colour_index], _list_female_hand_skin_colours[_female_skin_colour_index]);
        else
            changeSkinColour(_list_male_skin_colours[_male_skin_colour_index], _list_male_hand_skin_colours[_male_skin_colour_index]);*/


        if (_hair != null)
        {
            for (int i = 0; i < _hair.transform.childCount; i++)
            {
                if (_hair.transform.GetChild(i).GetComponent<SkinnedMeshRenderer>() != null)
                {
                    if (_hair.transform.GetChild(i).GetComponent<SkinnedMeshRenderer>().material.HasProperty("u_hairColor"))
                    {
                        _hair.transform.GetChild(i).GetComponent<SkinnedMeshRenderer>().material.SetColor("u_hairColor", new Color(_hair_add_R, _hair_add_G, _hair_add_B));
                    }
                }
            }
        }
        if (_mouth != null && _mouth_color != null)
        {
            if (_mouth.GetComponentInChildren<SkinnedMeshRenderer>().material.HasProperty("u_lipColor"))
            {
                _mouth.GetComponentInChildren<SkinnedMeshRenderer>().material.SetColor("u_lipColor", _mouth_color);
            }
        }
        if (_head != null)
        {
            if (_head.transform.Find("c_eyes_mesh").GetComponentInChildren<SkinnedMeshRenderer>().materials[0].HasProperty("u_diffuseColor"))
                _head.transform.Find("c_eyes_mesh").GetComponentInChildren<SkinnedMeshRenderer>().materials[0].SetColor("u_diffuseColor", new Color(_eye_add_R, _eye_add_G, _eye_add_B));
            //setPlayerEyeColor();
        }


        
        setPlayerSkinBrightness();
        setPlayerSkinContrast();
        /*for (int r = 0; r < _rendererTargets.Count; r++)
        {

            for (int i = 0; i < _rendererTargets[r].bones.Length; i++)
            {
                _rendererTargets[r].bones[i].localScale = _bonemods[i].scale;
            }
        }*/

        character_gameobject = _head;

        return parent_bones;

    }
    
    public void setHairColor()
    {
        if (_hair != null)
        {
            if (_hair.GetComponentInChildren<SkinnedMeshRenderer>().material.HasProperty("HairColor"))
                _hair.GetComponentInChildren<SkinnedMeshRenderer>().material.SetColor("HairColor", new Color(_hair_add_R, _hair_add_G, _hair_add_B));
        }
    }

    public void setHouseOutfitGryffindor()
    {
        _house = "gryffindor";
        _female_outfit_index = 0;
        _male_outfit_index = 0;
        if (_outfit != null)
        {
            removePlayerPiece(_outfit);
            if (_gender == "female")
                addPlayerPiece(ref _outfit, _female_outfit_index, _list_female_outfit_prefabs, false);
            else
                addPlayerPiece(ref _outfit, _male_outfit_index, _list_male_outfit_prefabs, false);
        }
    }

    public void setHouseOutfitHufflepuff()
    {
        _house = "hufflepuff";
        _female_outfit_index = 1;
        _male_outfit_index = 1;
        if (_outfit != null)
        {
            removePlayerPiece(_outfit);
            if (_gender == "female")
                addPlayerPiece(ref _outfit, _female_outfit_index, _list_female_outfit_prefabs, false);
            else
                addPlayerPiece(ref _outfit, _male_outfit_index, _list_male_outfit_prefabs, false);
        }
    }

    public void setHouseOutfitRavenclaw()
    {
        _house = "ravenclaw";
        _female_outfit_index = 2;
        _male_outfit_index = 2;
        if (_outfit != null)
        {
            removePlayerPiece(_outfit);
            if (_gender == "female")
                addPlayerPiece(ref _outfit, _female_outfit_index, _list_female_outfit_prefabs, false);
            else
                addPlayerPiece(ref _outfit, _male_outfit_index, _list_male_outfit_prefabs, false);
        }
    }

    public void setHouseOutfitSlytherin()
    {
        _house = "slytherin";
        _female_outfit_index = 3;
        _male_outfit_index = 3;
        if (_outfit != null)
        {
            removePlayerPiece(_outfit);
            if (_gender == "female")
                addPlayerPiece(ref _outfit, _female_outfit_index, _list_female_outfit_prefabs, false);
            else
                addPlayerPiece(ref _outfit, _male_outfit_index, _list_male_outfit_prefabs, false);
        }
    }

    public void swapGender()
    {
        if (_gender == "female")
            _gender = "male";
        else
            _gender = "female";

        removePlayerPiece(_head);
        removePlayerPiece(_eyes);
        removePlayerPiece(_nose);
        removePlayerPiece(_mouth);
        removePlayerPiece(_outfit);
        removePlayerPiece(_hair);

        if (_gender == "female")
        {
            addPlayerPiece(ref _head, _female_head_index, _list_female_head_prefabs, false);
            addPlayerPiece(ref _eyes, _female_eyes_index, _list_female_eyes_prefabs, false);
            addPlayerPiece(ref _nose, _female_nose_index, _list_female_nose_prefabs, false);
            addPlayerPiece(ref _mouth, _female_mouth_index, _list_female_mouth_prefabs, false);
            addPlayerPiece(ref _outfit, _female_outfit_index, _list_female_outfit_prefabs, false);
            addPlayerPiece(ref _hair, _female_hair_index, _list_female_hair_prefabs, false);
            changeSkinColour(_list_female_skin_colours[_female_skin_colour_index], _list_female_hand_skin_colours[_female_skin_colour_index]);
        }
        else
        {
            addPlayerPiece(ref _head, _male_head_index, _list_male_head_prefabs, false);
            addPlayerPiece(ref _eyes, _male_eyes_index, _list_male_eyes_prefabs, false);
            addPlayerPiece(ref _nose, _male_nose_index, _list_male_nose_prefabs, false);
            addPlayerPiece(ref _mouth, _male_mouth_index, _list_male_mouth_prefabs, false);
            addPlayerPiece(ref _outfit, _male_outfit_index, _list_male_outfit_prefabs, false);
            addPlayerPiece(ref _hair, _male_hair_index, _list_male_hair_prefabs, false);
            changeSkinColour(_list_male_skin_colours[_male_skin_colour_index], _list_male_hand_skin_colours[_male_skin_colour_index]);
        }
        setPlayerHairColor();
        setPlayerEyeColor();
        if (_gender == "female")
        {
            switch (_female_outfit_index)
            {
                case 0:
                    _house = "gryffindor";
                    break;
                case 1:
                    _house = "hufflepuff";
                    break;
                case 2:
                    _house = "ravenclaw";
                    break;
                case 3:
                    _house = "slytherin";
                    break;
            }
        }
        else
        {
            switch (_male_outfit_index)
            {
                case 0:
                    _house = "gryffindor";
                    break;
                case 1:
                    _house = "hufflepuff";
                    break;
                case 2:
                    _house = "ravenclaw";
                    break;
                case 3:
                    _house = "slytherin";
                    break;
            }
        }
    }

    public void swapSkinColour()
    {
        if (_gender == "female")
        {
            _female_skin_colour_index++;
            if (_female_skin_colour_index == _list_female_skin_colours.Length)
                _female_skin_colour_index = 0;
            changeSkinColour(_list_female_skin_colours[_female_skin_colour_index], _list_female_hand_skin_colours[_female_skin_colour_index]);
        }
        else
        {
            _male_skin_colour_index++;
            if (_male_skin_colour_index == _list_male_skin_colours.Length)
                _male_skin_colour_index = 0;
            changeSkinColour(_list_male_skin_colours[_male_skin_colour_index], _list_male_hand_skin_colours[_male_skin_colour_index]);
        }
    }

    public void setPlayerSkinBrightness()
    {
        //_skin_brightness = _skin_brightness_slider.value;
        if (_head != null)
            if (_head.GetComponentInChildren<SkinnedMeshRenderer>().material.HasProperty("brightness"))
                _head.GetComponentInChildren<SkinnedMeshRenderer>().material.SetFloat("brightness", _skin_brightness);
        if (_eyes != null)
            if (_eyes.GetComponentInChildren<SkinnedMeshRenderer>().material.HasProperty("brightness"))
                _eyes.GetComponentInChildren<SkinnedMeshRenderer>().material.SetFloat("brightness", _skin_brightness);
        if (_nose != null)
            if (_nose.GetComponentInChildren<SkinnedMeshRenderer>().material.HasProperty("brightness"))
                _nose.GetComponentInChildren<SkinnedMeshRenderer>().material.SetFloat("brightness", _skin_brightness);
        if (_mouth != null)
            if (_mouth.GetComponentInChildren<SkinnedMeshRenderer>().material.HasProperty("brightness"))
                _mouth.GetComponentInChildren<SkinnedMeshRenderer>().material.SetFloat("brightness", _skin_brightness);
        if (_hands != null)
            if (_hands.GetComponentInChildren<SkinnedMeshRenderer>().material.HasProperty("brightness"))
                _hands.GetComponentInChildren<SkinnedMeshRenderer>().material.SetFloat("brightness", _skin_brightness);
        if (_forearms != null)
            if (_forearms.GetComponentInChildren<SkinnedMeshRenderer>().material.HasProperty("brightness"))
                _forearms.GetComponentInChildren<SkinnedMeshRenderer>().material.SetFloat("brightness", _skin_brightness);
    }
    public void setPlayerSkinContrast()
    {
        if (_head != null)
            if (_head.GetComponentInChildren<SkinnedMeshRenderer>().material.HasProperty("contrast"))
                _head.GetComponentInChildren<SkinnedMeshRenderer>().material.SetFloat("contrast", _skin_contrast);
        if (_eyes != null)
            if (_eyes.GetComponentInChildren<SkinnedMeshRenderer>().material.HasProperty("contrast"))
                _eyes.GetComponentInChildren<SkinnedMeshRenderer>().material.SetFloat("contrast", _skin_contrast);
        if (_nose != null)
            if (_nose.GetComponentInChildren<SkinnedMeshRenderer>().material.HasProperty("contrast"))
                _nose.GetComponentInChildren<SkinnedMeshRenderer>().material.SetFloat("contrast", _skin_contrast);
        if (_mouth != null)
            if (_mouth.GetComponentInChildren<SkinnedMeshRenderer>().material.HasProperty("contrast"))
                _mouth.GetComponentInChildren<SkinnedMeshRenderer>().material.SetFloat("contrast", _skin_contrast);
        if (_hands != null)
            if (_hands.GetComponentInChildren<SkinnedMeshRenderer>().material.HasProperty("contrast"))
                _hands.GetComponentInChildren<SkinnedMeshRenderer>().material.SetFloat("contrast", _skin_contrast);
        if (_forearms != null)
            if (_forearms.GetComponentInChildren<SkinnedMeshRenderer>().material.HasProperty("contrast"))
                _forearms.GetComponentInChildren<SkinnedMeshRenderer>().material.SetFloat("contrast", _skin_contrast);
    }



    public void swapHair()
    {
        removePlayerPiece(_hair);
        if (_gender == "female")
            addPlayerPiece(ref _hair, _female_hair_index, _list_female_hair_prefabs, true);
        else
            addPlayerPiece(ref _hair, _male_hair_index, _list_male_hair_prefabs, true);
        _hair.GetComponentInChildren<SkinnedMeshRenderer>().material.SetFloat("_AddR", _hair_add_R); //Colour the hair
        _hair.GetComponentInChildren<SkinnedMeshRenderer>().material.SetFloat("_AddG", _hair_add_G);
        _hair.GetComponentInChildren<SkinnedMeshRenderer>().material.SetFloat("_AddB", _hair_add_B);
        setPlayerHairColor();
    }

    public void swapEyes()
    {
        removePlayerPiece(_eyes);
        if (_gender == "female")
        {
            addPlayerPiece(ref _eyes, _female_eyes_index, _list_female_eyes_prefabs, true);
            _eyes.GetComponentInChildren<SkinnedMeshRenderer>().sharedMaterial = _list_female_skin_colours[_female_skin_colour_index];
        }
        else
        {
            addPlayerPiece(ref _eyes, _male_eyes_index, _list_male_eyes_prefabs, true);
            _eyes.GetComponentInChildren<SkinnedMeshRenderer>().sharedMaterial = _list_male_skin_colours[_male_skin_colour_index];
        }
    }

    public void swapNose()
    {
        removePlayerPiece(_nose);
        if (_gender == "female")
        {
            addPlayerPiece(ref _nose, _female_nose_index, _list_female_nose_prefabs, true);
            _nose.GetComponentInChildren<SkinnedMeshRenderer>().sharedMaterial = _list_female_skin_colours[_female_skin_colour_index];
        }
        else
        {
            addPlayerPiece(ref _nose, _male_nose_index, _list_male_nose_prefabs, true);
            _nose.GetComponentInChildren<SkinnedMeshRenderer>().sharedMaterial = _list_male_skin_colours[_male_skin_colour_index];
        }
    }

    public void swapMouth()
    {
        removePlayerPiece(_mouth);
        if (_gender == "female")
        {
            addPlayerPiece(ref _mouth, _female_mouth_index, _list_female_mouth_prefabs, true);
            _mouth.GetComponentInChildren<SkinnedMeshRenderer>().sharedMaterial = _list_female_skin_colours[_female_skin_colour_index];
        }
        else
        {
            addPlayerPiece(ref _mouth, _male_mouth_index, _list_male_mouth_prefabs, true);
            _mouth.GetComponentInChildren<SkinnedMeshRenderer>().sharedMaterial = _list_male_skin_colours[_male_skin_colour_index];
        }
    }

    public void setPlayerEyeColor()
    {
        //_eye_add_R = _eye_add_R_slider.value;
        //_eye_add_G = _eye_add_G_slider.value;
        //_eye_add_B = _eye_add_B_slider.value;
        if (_head != null)
        {
            if (_head.GetComponentInChildren<SkinnedMeshRenderer>().materials[1].HasProperty("iris"))
                _head.GetComponentInChildren<SkinnedMeshRenderer>().materials[1].SetColor("iris", new Color(_eye_add_R, _eye_add_G, _eye_add_B));
        }
    }

    public void setPlayerHairColor()
    {
        _hair_add_R = _hair_add_R_slider.value;
        _hair_add_G = _hair_add_G_slider.value;
        _hair_add_B = _hair_add_B_slider.value;
        if (_hair != null)
            if (_hair.GetComponentInChildren<SkinnedMeshRenderer>().material.HasProperty("Color_B447E572"))
                _hair.GetComponentInChildren<SkinnedMeshRenderer>().material.SetColor("Color_B447E572", new Color(_hair_add_R, _hair_add_G, _hair_add_B));
    }

    /*public void setChinSize()
    {
        //Chin Size - Scale chin_MOD_Joint_bind
        for (int i = 0; i < _bonemods.Length; i++)
        {
            if (_bonemods[i].bone_name == "chin_MOD_Joint_bind")
                _bonemods[i].scale = new Vector3(_chin_size_slider.value, _chin_size_slider.value, _chin_size_slider.value);
        }
    }*/

    /*public void setJawSize()
    {
        //Jaw Size - Scale jawCorners_MOD_Joint_bind
        for (int i = 0; i < _bonemods.Length; i++)
        {
            if (_bonemods[i].bone_name == "jawCorners_MOD_Joint_bind")
                _bonemods[i].scale = new Vector3(_jaw_size_slider.value, _jaw_size_slider.value, _jaw_size_slider.value);
        }
    }*/

    //Bridge Height - Move Z jt_noseBridge_MOD_bind
    //Bridge Length - Move Y jt_noseBridge_MOD_bind
    //Bridge Width - Scale X jt_noseBridge_MOD_bind
    //Roundness - Scale Z jt_nose_MOD_bind
    //Tip Height - Move Z jt_nose_MOD_bind
    //Tip Length - Scale Y jt_nose_MOD_bind
    //Twist - Rotate X jt_nose_MOD_bind
    //Tip Width - Scale X jt_nose_MOD_bind

    /*public void setBridgeHeight()
    {
        //Bridge Height - Move Y jt_noseBridge_MOD_bind
        for (int i = 0; i < _bonemods.Length; i++)
        {
            if (_bonemods[i].bone_name == "jt_noseBridge_MOD_bind")
                _bonemods[i].position = new Vector3(_bonemods[i].position.x, _bridge_height_slider.value, _bonemods[i].position.z);
        }
    }*/
    /*public void setBridgeLength()
    {
        //Bridge Length - Move X jt_noseBridge_MOD_bind
        for (int i = 0; i < _bonemods.Length; i++)
        {
            if (_bonemods[i].bone_name == "jt_noseBridge_MOD_bind")
                _bonemods[i].position = new Vector3(_bridge_length_slider.value, _bonemods[i].position.y, _bonemods[i].position.z);
        }
    }*/
    /*public void setBridgeWidth()
    {
        //Bridge Width - Scale X jt_noseBridge_MOD_bind
        for (int i = 0; i < _bonemods.Length; i++)
        {
            if (_bonemods[i].bone_name == "jt_noseBridge_MOD_bind")
                _bonemods[i].scale = new Vector3(_bridge_width_slider.value, _bonemods[i].scale.y, _bonemods[i].scale.z);
        }
    }
    public void setRoundess()
    {
        //Roundness - Scale Y jt_nose_MOD_bind
        for (int i = 0; i < _bonemods.Length; i++)
        {
            if (_bonemods[i].bone_name == "jt_nose_MOD_bind")
                _bonemods[i].scale = new Vector3(_bonemods[i].scale.x, _roundness_slider.value, _bonemods[i].scale.z);
        }
    }
    public void setTipHeight()
    {
        //Tip Height - Move Z jt_nose_MOD_bind
        for (int i = 0; i < _bonemods.Length; i++)
        {
            if (_bonemods[i].bone_name == "jt_nose_MOD_bind")
                _bonemods[i].position = new Vector3(_bonemods[i].position.x, _tip_height_slider.value, _bonemods[i].position.z);
        }
    }
    public void setTipLength()
    {
        //Tip Length - Scale Y jt_nose_MOD_bind
        for (int i = 0; i < _bonemods.Length; i++)
        {
            if (_bonemods[i].bone_name == "jt_nose_MOD_bind")
                _bonemods[i].position = new Vector3(_tip_length_slider.value, _bonemods[i].position.y, _bonemods[i].position.z);
        }
    }
    public void setTwist()
    {
        //Twist - Rotate X jt_nose_MOD_bind
        for (int i = 0; i < _bonemods.Length; i++)
        {
            if (_bonemods[i].bone_name == "jt_nose_MOD_bind")
                _bonemods[i].rotation = Quaternion.Euler(new Vector3(_twist_slider.value, _bonemods[i].rotation.eulerAngles.y, _bonemods[i].rotation.eulerAngles.z));//new Quaternion(_twist_slider.value, _twist_slider.value, _twist_slider.value);
        }
    }
    public void setTipWidth()
    {
        //Tip Width - Scale X jt_nose_MOD_bind
        for (int i = 0; i < _bonemods.Length; i++)
        {
            if (_bonemods[i].bone_name == "jt_nose_MOD_bind")
                _bonemods[i].scale = new Vector3(_tip_width_slider.value, _bonemods[i].scale.y, _bonemods[i].scale.z);
        }
    }

    //Eye Closeness - Move X jt_L_eye_MOD_bind jt_R_eye_MOD_bind
    //Eye Size - Scale jt_L_eye_MOD_bind jt_R_eye_MOD_bind
    //Eye Height - Move Z jt_L_eye_MOD_bind jt_R_eye_MOD_bind

    //Brow Size - Scale Z leftInBrow1_Joint_bind leftMidBrow1_Joint_bind leftOutBrow1_Joint_bind

    public void setEyeCloseness()
    {
        //Eye Closeness - Move Z jt_L_eye_MOD_bind jt_R_eye_MOD_bind
        for (int i = 0; i < _bonemods.Length; i++)
        {
            if (_bonemods[i].bone_name == "jt_L_eye_MOD_bind")
                _bonemods[i].position = new Vector3(_bonemods[i].position.x, _bonemods[i].position.y, _eye_closeness_slider.value);

            else if (_bonemods[i].bone_name == "jt_R_eye_MOD_bind")
                _bonemods[i].position = new Vector3(_bonemods[i].position.x, _bonemods[i].position.y, -_eye_closeness_slider.value);
        }
    }
    public void setEyeSize()
    {
        //Eye Size - Scale jt_L_eye_MOD_bind jt_R_eye_MOD_bind
        for (int i = 0; i < _bonemods.Length; i++)
        {
            if (_bonemods[i].bone_name == "jt_L_eye_MOD_bind")
                _bonemods[i].scale = new Vector3(_eye_size_slider.value, _eye_size_slider.value, _eye_size_slider.value);

            else if (_bonemods[i].bone_name == "jt_R_eye_MOD_bind")
                _bonemods[i].scale = new Vector3(_eye_size_slider.value, _eye_size_slider.value, _eye_size_slider.value);
        }
    }
    public void setEyeHeight()
    {
        //Eye Height - Move Z jt_L_eye_MOD_bind jt_R_eye_MOD_bind
        for (int i = 0; i < _bonemods.Length; i++)
        {
            if (_bonemods[i].bone_name == "jt_L_eye_MOD_bind")
                _bonemods[i].position = new Vector3(_bonemods[i].position.x, _eye_height_slider.value, _bonemods[i].position.z);

            else if (_bonemods[i].bone_name == "jt_R_eye_MOD_bind")
                _bonemods[i].position = new Vector3(_bonemods[i].position.x, _eye_height_slider.value, _bonemods[i].position.z);
        }
    }
    public void setBrowSize()
    {
        //Brow Size - Scale Z leftInBrow1_Joint_bind leftMidBrow1_Joint_bind leftOutBrow1_Joint_bind rightInBrow1_Joint_bind rightMidBrow1_Joint_bind rightOutBrow1_Joint_bind
        for (int i = 0; i < _bonemods.Length; i++)
        {
            if (_bonemods[i].bone_name == "leftInBrow1_Joint_bind")
                _bonemods[i].scale = new Vector3(_bonemods[i].scale.x, _brow_size_slider.value, _bonemods[i].scale.z);
            else if (_bonemods[i].bone_name == "leftMidBrow1_Joint_bind")
                _bonemods[i].scale = new Vector3(_bonemods[i].scale.x, _brow_size_slider.value, _bonemods[i].scale.z);
            else if (_bonemods[i].bone_name == "leftOutBrow1_Joint_bind")
                _bonemods[i].scale = new Vector3(_bonemods[i].scale.x, _brow_size_slider.value, _bonemods[i].scale.z);
            else if (_bonemods[i].bone_name == "rightInBrow1_Joint_bind")
                _bonemods[i].scale = new Vector3(_bonemods[i].scale.x, _brow_size_slider.value, _bonemods[i].scale.z);
            else if (_bonemods[i].bone_name == "rightMidBrow1_Joint_bind")
                _bonemods[i].scale = new Vector3(_bonemods[i].scale.x, _brow_size_slider.value, _bonemods[i].scale.z);
            else if (_bonemods[i].bone_name == "rightOutBrow1_Joint_bind")
                _bonemods[i].scale = new Vector3(_bonemods[i].scale.x, _brow_size_slider.value, _bonemods[i].scale.z);
        }
    }*/


    public void Mute(UnityEngine.Events.UnityEventBase ev)
    {
        int count = ev.GetPersistentEventCount();
        for (int i = 0; i < count; i++)
        {
            ev.SetPersistentListenerState(i, UnityEngine.Events.UnityEventCallState.Off);
        }
    }

    public void Unmute(UnityEngine.Events.UnityEventBase ev)
    {
        int count = ev.GetPersistentEventCount();
        for (int i = 0; i < count; i++)
        {
            ev.SetPersistentListenerState(i, UnityEngine.Events.UnityEventCallState.RuntimeOnly);
        }
    }


    public void quit()
    {
        Application.Quit();
    }
}