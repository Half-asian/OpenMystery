﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Newtonsoft.Json;
using System.IO;

public class CharacterManager : MonoBehaviour
{
    //public GameObject character = GetComponent<GameObject>();
    public List<GameObject> patches;
    public string model_name;
    public ConfigHPActorInfo._HPActorInfo actor_info;
    public CharacterState character_state = CharacterState.Idle;
    public string anim_state = "loop";
    public string animId_idle = "";
    public string queued_anim = "";
    public int queued_anim_delay = 0;
    public string next_outro = "";
    public string anim_sequence_idle = "";
    public Dictionary<string, AnimationManager.BoneMod> bone_mods;

    public AnimationClip animation1_intro;
    public AnimationClip animation1_loop;
    public AnimationClip animation1_exit;
    public string animation1_name;

    public AnimationClip animation2_intro;
    public AnimationClip animation2_loop;
    public AnimationClip animation2_exit;
    public string animation2_name;

    public IEnumerator coroutine_walk;
    public Quaternion goal_rotation;

    public string delayed_anim;

    public string current_waypoint;
    public Vector3 destination_position;
    public Quaternion destination_rotation;

    public List<string> path;

    public Dictionary<string, Transform> parent_bones;

    const float RUN_SPEED = 1.3f;

    public AvatarComponents avatar_components;

    public enum CharacterState
    {
        Idle,
        Walk,
        Run,
        SittingIdle,
        Success,
        RenownBoard
    }


    public void resetState()
    {
        Debug.Log(gameObject.name + " stop looking ");
        looking = null;
        animId_idle = actor_info.animId_idle;
        character_state = CharacterState.Idle;
        loadAnimationSet();
        anim_state = "outro";
        updateAnimationState();
    }

    public void destroyPatches()
    {
        foreach(GameObject g in patches)
        {
            Destroy(g);
        }
    }

    public void setCurrentWaypoint(string _waypoint)
    {

        if (! GameStart.game_state.scenario_holder.scene.waypoint_dict.ContainsKey(_waypoint)){
            return;
        }
        current_waypoint = _waypoint;
        ConfigScene._Scene.WayPoint waypoint = GameStart.game_state.scenario_holder.scene.waypoint_dict[current_waypoint];
        destination_position = new Vector3(waypoint.position[0] * -0.01f, waypoint.position[1] * 0.01f, waypoint.position[2] * 0.01f);
        if (waypoint.rotation != null)
        {
            destination_rotation = Quaternion.Euler(new Vector3(waypoint.rotation[0], waypoint.rotation[1] * -1, waypoint.rotation[2]));
        }
        else
        {
            destination_rotation = Quaternion.Euler(Vector3.zero);
        }
    }

    public string getCurrentWaypoint()
    {
        return current_waypoint;
    }

    public AnimationClip loadAnimation(string anim_name)
    {
        return AnimationManager.loadAnimationClip(anim_name, "c3b", actor_info, bone_mods);
    }
    public void loadAnimationSet(string _animation = "")
    {
        AnimationClip default_anim = Resources.Load("default") as AnimationClip;
        default_anim.legacy = true;

        animation2_intro = animation1_intro;
        animation2_loop = animation1_loop;
        animation2_exit = animation1_exit;
        animation2_name = animation1_name;

        if (animation2_intro == null)
        {
            animation2_intro = Resources.Load("default") as AnimationClip;
        }
        if (animation2_loop == null)
        {
            animation2_loop = Resources.Load("default") as AnimationClip;
        }
        if (animation2_exit == null)
        {
            animation2_exit = Resources.Load("default") as AnimationClip;
        }

        animation1_intro = default_anim;
        animation1_loop = default_anim;
        animation1_exit = default_anim;

        string anim_name = "";
        if (character_state == CharacterState.Idle)
        {
            anim_name = animId_idle;
        }
        else if (character_state == CharacterState.Walk)
        {
            if (_animation != "")
            {
                anim_name = _animation;
            }
            else
            {
                anim_name = actor_info.animId_walk;
            }
        }
        else if (character_state == CharacterState.Run)
        {
            anim_name = actor_info.animId_run;
        }
        else if (character_state == CharacterState.SittingIdle)
        {
            anim_name = actor_info.animId_sitting_idle;
        }
        else if (character_state == CharacterState.Success)
        {
            anim_name = actor_info.animId_success;
        }
        else if (character_state == CharacterState.RenownBoard)
        {
            anim_name = actor_info.animId_renownboard;
        }

        animation1_name = anim_name;

        if (!Configs.config_animation.Animation3D.ContainsKey(anim_name))
        {
            Debug.LogError("Couldn't find animation " + anim_name);
            return;
        }
        ConfigAnimation._Animation3D animation = Configs.config_animation.Animation3D[anim_name];

        if (animation != null)
        {
            animation1_loop = AnimationManager.loadAnimationClip(anim_name, "c3b", actor_info, bone_mods);
            if (animation.introAnim != null)
            {
                Debug.Log(animation.introAnim);
                animation1_intro = AnimationManager.loadAnimationClip(animation.introAnim, "c3b", actor_info, bone_mods);
            }
            /*else
            {
                if (animation_config.Animation3D.ContainsKey(anim_name + "_idleTo01"))
                {
                    animation1_intro = AnimationManager.loadAnimationClip(anim_name + "_idleTo01", "c3b", ref animation_config, actor_info, bone_mods);
                }
                else if (animation_config.Animation3D.ContainsKey(anim_name + "_idleTo"))
                {
                    animation1_intro = AnimationManager.loadAnimationClip(anim_name + "_idleTo", "c3b", ref animation_config, actor_info, bone_mods);
                }
                else if (animation_config.Animation3D.ContainsKey(anim_name + "_intro"))
                {
                    animation1_intro = AnimationManager.loadAnimationClip(anim_name + "_intro", "c3b", ref animation_config, actor_info, bone_mods);
                }
            }*/


            if (animation.outroAnim != null)
            {
                animation1_exit = AnimationManager.loadAnimationClip(animation.outroAnim, "c3b", actor_info, bone_mods);
            }
            /*else
            {
                if (animation_config.Animation3D.ContainsKey(anim_name + "_toIdle01"))
                {
                    animation1_exit = AnimationManager.loadAnimationClip(anim_name + "_toIdle01", "c3b", ref animation_config, actor_info, bone_mods);
                }
                else if (animation_config.Animation3D.ContainsKey(anim_name + "_toIdle"))
                {
                    animation1_exit = AnimationManager.loadAnimationClip(anim_name + "_toIdle", "c3b", ref animation_config, actor_info, bone_mods);
                }
                else if (animation_config.Animation3D.ContainsKey(anim_name + "_outro"))
                {
                    animation1_exit = AnimationManager.loadAnimationClip(anim_name + "_outro", "c3b", ref animation_config, actor_info, bone_mods);
                }
            }*/
        }

        if (animation1_intro == null)
        {
            animation1_intro = default_anim;
        }
        if (animation1_loop == null)
        {
            animation1_loop = default_anim;
        }
        if (animation1_exit == null)
        {
            animation1_exit = default_anim;
        }

        if (gameObject.GetComponent<Animation>() != null)
        {
            Animation character_animation = gameObject.GetComponent<Animation>();
            character_animation.AddClip(animation1_intro, "intro");
            character_animation.AddClip(animation1_loop, "loop");
            character_animation.AddClip(animation2_exit, "outro");
            foreach (GameObject patch in patches)
            {
                if (patch.GetComponent<Animation>() != null)
                {
                    Animation patch_animation = patch.GetComponent<Animation>();
                    patch_animation.AddClip(animation1_intro, "intro");
                    patch_animation.AddClip(animation1_loop, "loop");
                    patch_animation.AddClip(animation2_exit, "outro");
                }
            }
        }
    }

    private IEnumerator RotateOverTime()
    {
        yield return null;
        while (transform.rotation.eulerAngles != destination_rotation.eulerAngles)
        {
            transform.rotation = Quaternion.RotateTowards(transform.rotation, goal_rotation, Time.deltaTime * 300);
            yield return null;
        }
    }

    private IEnumerator WaitForAnimation(float clip_time, float start_time, string current)
    {
        while (Time.realtimeSinceStartup < clip_time + start_time)
            yield return null;

        if (anim_state == "intro" && current == "intro")
        {
            anim_state = "loop";
            updateAnimationState();
        }
        else if (anim_state == "outro" && current == "outro")
        {
            anim_state = "intro";
            updateAnimationState();
        }
    }

    private IEnumerator WaitForMove(float speed)//Vector3 destination_position, Quaternion destination_rotation)
    {
        while (path.Count != 0 || gameObject.transform.position != destination_position)//Vector3.Distance(gameObject.transform.position, destination_position) > 0.1f)
        {
            if (gameObject.transform.position != destination_position)
            {
                Vector3 targetDirection = transform.position - destination_position;
                transform.rotation = Quaternion.LookRotation((targetDirection).normalized);
                transform.rotation = Quaternion.Euler(new Vector3(0.0f, transform.rotation.eulerAngles.y + 180, 0.0f));
                gameObject.transform.position = Vector3.MoveTowards(gameObject.transform.position, destination_position, (0.4f + speed) * Time.deltaTime);
                yield return null;
            }
            else
            {
                current_waypoint = path[0];
                path.RemoveAt(0);
                ConfigScene._Scene.WayPoint waypoint = GameStart.game_state.scenario_holder.scene.waypoint_dict[current_waypoint];
                destination_position = new Vector3(waypoint.position[0] * -0.01f, waypoint.position[1] * 0.01f, waypoint.position[2] * 0.01f);
                if (waypoint.rotation != null)
                {
                    destination_rotation = Quaternion.Euler(new Vector3(waypoint.rotation[0], waypoint.rotation[1] * -1, waypoint.rotation[2]));
                }
                else
                {
                    destination_rotation = Quaternion.Euler(Vector3.zero);
                }
                Vector3 targetDirection = transform.position - destination_position;

                if (gameObject.transform.position != destination_position) //!(Vector3.Distance(gameObject.transform.position, destination_position) < 0.1f))
                {
                    transform.rotation = Quaternion.LookRotation((targetDirection).normalized);
                    transform.rotation = Quaternion.Euler(new Vector3(0.0f, transform.rotation.eulerAngles.y + 180, 0.0f));
                }
                yield return null;
            }
        }
        if (GetComponent<CharAnimSequenceHandler>() != null)
        {
            if (GetComponent<CharAnimSequenceHandler>().walk == true)
            {
                if (anim_sequence_idle != "")
                {
                    GetComponent<CharAnimSequenceHandler>().initAnimSequence(anim_sequence_idle, false);
                }
                else
                {
                    Destroy(GetComponent<CharAnimSequenceHandler>());
                }
            }
        }

        GameObject.Find("GameManager").GetComponent<EventManager>().notifyMoveComplete(gameObject.name);

        character_state = CharacterState.Idle;
        goal_rotation = destination_rotation;
        
        //gameObject.transform.rotation = destination_rotation;
        StartCoroutine(RotateOverTime());

        anim_state = "outro";


        replaceCharacterIdle(actor_info.animId_idle);
        loadAnimationSet();
        updateAnimationState();

    
    }


    public void moveCharacter(List<string> _path, string animation = "")
    {
        clearLookat();
        clearTurnHeadAt();

        character_state = CharacterState.Walk;
        if (coroutine_walk != null)
        {
            StopCoroutine(coroutine_walk);
            if (path != null)
            {
                if (path.Count != 0)
                {
                    current_waypoint = path[0];
                }
            }
        }
        path = _path;
        string path_string = "";
        foreach (string s in path)
        {
            path_string += s + " ";
        }

        setCurrentWaypoint(path[0]);
        path.RemoveAt(0);
        if (animation == actor_info.animId_run || animation == "c_Stu_Jog01")
        {
            coroutine_walk = WaitForMove(RUN_SPEED);
        }
        else
        {
            coroutine_walk = WaitForMove(0.0f);
        }
        setCharacterWalk(animation);
        StartCoroutine(coroutine_walk);
    }

    public void moveCharacterNoAnimation(List<string> _path, float speed)
    {
        clearTurnHeadAt();
        clearLookat();

        character_state = CharacterState.Walk;
        if (coroutine_walk != null)
        {
            StopCoroutine(coroutine_walk);
            if (path != null)
            {
                if (path.Count != 0)
                {
                    current_waypoint = path[0];
                }
            }
        }
        path = _path;
        string path_string = "";
        foreach (string s in path)
        {
            path_string += s + " ";
        }

        setCurrentWaypoint(path[0]);
        path.RemoveAt(0);
       
        coroutine_walk = WaitForMove(speed);
        StartCoroutine(coroutine_walk);
    }

    public void stopCharacterWalk()
    {
        //Debug.Log("stopCharacterWalk" + gameObject.name);
        if (coroutine_walk != null)
        {
            StopCoroutine(coroutine_walk);
            if (path != null)
            {
                if (path.Count != 0)
                {
                    current_waypoint = path[0];
                }
            }
        }
        path = null;
        character_state = CharacterState.Idle;
        loadAnimationSet();
        anim_state = "loop";
        updateAnimationState();
    }

    public void teleportCharacter(Vector3 destination_position, Vector3 destination_rotation)
    {
        if (coroutine_walk != null)
        {
            StopCoroutine(coroutine_walk);
        }
        path = null;
        gameObject.transform.position = destination_position;
        //gameObject.transform.rotation = Quaternion.identity * Quaternion.Euler(destination_rotation);

        gameObject.transform.rotation = Quaternion.identity;
        gameObject.transform.Rotate(new Vector3(0, 0, -destination_rotation[2]));
        gameObject.transform.Rotate(new Vector3(0, -destination_rotation[1], 0));
        gameObject.transform.Rotate(new Vector3(destination_rotation[0], 0, 0));


        character_state = CharacterState.Idle;
        loadAnimationSet();
        anim_state = "outro";
        updateAnimationState();
    }

    public void teleportCharacter(Vector3 destination_position)
    {
        if (coroutine_walk != null)
        {
            StopCoroutine(coroutine_walk);
        }
        path = null;
        gameObject.transform.position = destination_position;
        character_state = CharacterState.Idle;
        loadAnimationSet();
        anim_state = "outro";
        updateAnimationState();
    }

    public void replaceCharacterIdle(string anim_name) //For some reason the game likes to set the character to the default idle anim a lot, which fucks up the intro and outro animations. So this delay filters animations that are instantly replaced.
    {
        if (animation1_name == actor_info.animId_idle || animation1_name == actor_info.animId_sitting_idle) //Default animation to another animation, play the intro
        {
            anim_state = "intro";
            Debug.Log("enter intro");
        }
        else if (anim_name == actor_info.animId_idle || anim_name == actor_info.animId_sitting_idle) //The next animation is the default animation, therefore we should play the outro
        {
            anim_state = "outro";
            Debug.Log("enter outro");
        }
        else
        {
            anim_state = "loop";
            Debug.Log("enter loop");
        }

        animId_idle = anim_name;
        
        if (character_state == CharacterState.Idle)
        {
            if (anim_state != "sequence")
            {
                if (GetComponent<CharAnimSequenceHandler>() != null)
                {
                    GetComponent<CharAnimSequenceHandler>().enabled = false;
                    Destroy(GetComponent<CharAnimSequenceHandler>());
                }
                loadAnimationSet();
                updateAnimationState();
            }
        }

    }

    public void replaceCharacterIdleNoDelay(string anim_name)
    {
        replaceCharacterIdle(anim_name);
    }

    public void setCharacterIdle()
    {
    }

    public void setCharacterWalk(string _animation)
    {
        //Debug.Log("setCharacterWalk" + gameObject.name);
        //if (character_state != CharacterState.Walk)
        //{
        //GameObject.Find("GameManager").GetComponent<EventManager>().stopLookAts(gameObject);

        if (GetComponent<CharAnimSequenceHandler>() != null)
        {
            if (GetComponent<CharAnimSequenceHandler>().walk != true)
            {
                GetComponent<CharAnimSequenceHandler>().enabled = false;
                Destroy(GetComponent<CharAnimSequenceHandler>());
            }
            else
            {
                character_state = CharacterState.Walk;
                return;
            }
        }
        character_state = CharacterState.Walk;
        loadAnimationSet(_animation);
        anim_state = "loop";
        updateAnimationState();
        gameObject.GetComponent<Animation>().Play("loop");
        //}

    }

    public void updateAnimationState()
    {
        if (GetComponent<CharAnimSequenceHandler>() != null) {
            if (GetComponent<CharAnimSequenceHandler>().enabled == true && GetComponent<CharAnimSequenceHandler>().walk == false)
            {
                //Destroy(GetComponent<CharAnimSequenceHandler>());
                return;
            }
        }

        //Debug.Log("updateAnimationState" + gameObject.name);
        if (gameObject == null)
        {
            return;
        }
        Animation character_animation = gameObject.GetComponent<Animation>();

        if (character_animation != null)
        {
            if (anim_state == "loop")
            {
                character_animation.wrapMode = WrapMode.Loop;
            }
            else
            {
                character_animation.wrapMode = WrapMode.ClampForever;
            }
            character_animation.Play(anim_state);
            foreach (GameObject patch in patches)
            {
                Animation patch_animation = patch.GetComponent<Animation>();

                if (patch_animation != null)
                {
                    if (anim_state == "loop")
                    {
                        patch_animation.wrapMode = WrapMode.Loop;
                    }
                    else
                    {
                        patch_animation.wrapMode = WrapMode.ClampForever;
                    }
                    patch_animation.Play(anim_state);

                }
            }
        }



        if (anim_state == "intro")
        {
            StartCoroutine(WaitForAnimation(animation1_intro.length, Time.realtimeSinceStartup, "intro"));
        }
        else if (anim_state == "outro")
        {
            StartCoroutine(WaitForAnimation(animation2_exit.length, Time.realtimeSinceStartup, "outro"));
        }
    }

    /*Transform char_a;
    Transform char_b;
    public Vector3 old_look;
    public float progress = 0.0f;
    public GameObject character_lookat;*/
    public EventManager.Looking looking;
    public EventManager.Looking turning;
    Transform char_a;

    public void setLookat(EventManager.Looking _looking)
    {
        looking = _looking;
        looking.destination_progress = 1.0f;
        try
        {
            looking.looking_position = looking.character.transform.Find("Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind").position - transform.position;//looking.character.transform.position - transform.position;
        }
        catch (System.Exception e)
        {
            //Debug.Log("failed to set look at " + e);
            looking = null;
        }
    }

    public void setTurnHeadAt(EventManager.Looking _turnHeadAt)
    {
        turning = _turnHeadAt;
        turning.destination_progress = 1.0f;
        try
        {
            turning.looking_position = turning.character.transform.Find("Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind").position - transform.position;//looking.character.transform.position - transform.position;
        }
        catch (System.Exception e)
        {

        }
        looking = null;
    }

    public void clearLookat()
    {
        if (looking != null)
            looking.destination_progress = 0.0f;
    }

    public void clearTurnHeadAt()
    {
        if (turning != null)
            turning.destination_progress = 0.0f;
    }


    public void LateUpdate()
    {
        if (looking != null)
        {
            if (looking.character == null)
            {
                looking = null;
                return;
            }
            looking.looking_position = looking.character.transform.Find("Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind").position - transform.position;

            if (looking.progress < 1.0f && looking.progress < looking.destination_progress)
            {
                if (looking.progress <= 0.5f)
                {
                    looking.progress += 4f * Time.deltaTime * (looking.progress + 0.3f);
                }
                else
                {
                    looking.progress += 4f * Time.deltaTime * (1.0f - (looking.progress + 0.3f - 0.5f));
                }
            }

            if (looking.progress > 1.0f)
                looking.progress = 1.0f;

            else if (looking.progress > 0.0f && looking.progress > looking.destination_progress)
            {
                if (looking.progress >= 0.5f)
                {
                    looking.progress -= 4f * Time.deltaTime * (looking.progress + 0.3f);
                }
                else
                {
                    looking.progress -= 4f * Time.deltaTime * (1.0f - (looking.progress + 0.3f - 0.5f));
                }
            }

            if (looking.progress < 0.0f)
                looking.progress = 0.0f;

            char_a = gameObject.transform.Find("Armature/jt_all_bind/jt_hips_bind");

            if (char_a != null)
            {
                Quaternion target_hips_direction = Quaternion.LookRotation(gameObject.transform.position + looking.looking_position - char_a.position).normalized;

                target_hips_direction = Quaternion.Euler(target_hips_direction.eulerAngles + new Vector3(0, 0, -90));

                target_hips_direction = Quaternion.LerpUnclamped(char_a.rotation, target_hips_direction, looking.progress / 6f);

                target_hips_direction = Quaternion.Euler(new Vector3(char_a.eulerAngles.x, target_hips_direction.eulerAngles.y, char_a.eulerAngles.z));

                char_a.eulerAngles = target_hips_direction.eulerAngles;

                for (int i = 0; i < gameObject.transform.childCount; i++)
                {
                    if (gameObject.transform.GetChild(i).GetComponent<Animation>() != null)
                    {
                        char_a = gameObject.transform.GetChild(i).Find("Armature/jt_all_bind/jt_hips_bind");
                        if (char_a != null)
                        {
                            char_a.eulerAngles = target_hips_direction.eulerAngles;
                        }
                    }
                }
            }

             //ROTATE SPINE 2

             char_a = gameObject.transform.Find("Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind");
            //char_b = looking.character.transform.Find("Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind");
            if (char_a != null)
            {
                Quaternion target_spine2_direction = Quaternion.LookRotation(gameObject.transform.position + looking.looking_position - char_a.position).normalized;

                target_spine2_direction = Quaternion.Euler(target_spine2_direction.eulerAngles + new Vector3(0, 0, -90));

                target_spine2_direction = Quaternion.LerpUnclamped(char_a.rotation, target_spine2_direction, looking.progress / 4.5f);

                target_spine2_direction = Quaternion.Euler(new Vector3(char_a.eulerAngles.x, target_spine2_direction.eulerAngles.y, char_a.eulerAngles.z));

                char_a.eulerAngles = target_spine2_direction.eulerAngles;

                for (int i = 0; i < gameObject.transform.childCount; i++)
                {
                    if (gameObject.transform.GetChild(i).GetComponent<Animation>() != null)
                    {
                        char_a = gameObject.transform.GetChild(i).Find("Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind");
                        if (char_a != null)
                        {
                            char_a.eulerAngles = target_spine2_direction.eulerAngles;
                        }
                    }
                }

            }

             //ROTATE SPINE 3

             char_a = gameObject.transform.Find("Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind");
            //char_b = looking.character.transform.Find("Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind");
            if (char_a != null)
            {

                Quaternion target_spine3_direction = Quaternion.LookRotation(gameObject.transform.position + looking.looking_position - char_a.position).normalized;

                target_spine3_direction = Quaternion.Euler(target_spine3_direction.eulerAngles + new Vector3(0, 0, -90));

                target_spine3_direction = Quaternion.LerpUnclamped(char_a.rotation, target_spine3_direction, looking.progress / 4f);

                //target_spine3_direction = Quaternion.Euler(new Vector3(char_a.eulerAngles.x, target_spine3_direction.eulerAngles.y, char_a.eulerAngles.z));

                char_a.eulerAngles = target_spine3_direction.eulerAngles;

                for (int i = 0; i < gameObject.transform.childCount; i++)
                {
                    if (gameObject.transform.GetChild(i).GetComponent<Animation>() != null)
                    {
                        char_a = gameObject.transform.GetChild(i).Find("Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind");
                        if (char_a != null)
                        {
                            char_a.eulerAngles = target_spine3_direction.eulerAngles;
                        }
                    }
                }
            }

            //ROTATE NECK

            if (char_a != null)
            {
                char_a = gameObject.transform.Find("Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind");
                //char_b = looking.character.transform.Find("Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind");

                Quaternion target_neck_direction = Quaternion.LookRotation(gameObject.transform.position + looking.looking_position - char_a.position).normalized;

                target_neck_direction = Quaternion.Euler(target_neck_direction.eulerAngles + new Vector3(20, 0, -90));

                target_neck_direction = Quaternion.LerpUnclamped(char_a.rotation, target_neck_direction, looking.progress / 1.3f);

                target_neck_direction = Quaternion.Euler(new Vector3(char_a.eulerAngles.x, target_neck_direction.eulerAngles.y, char_a.eulerAngles.z));

                char_a.eulerAngles = target_neck_direction.eulerAngles;

                for (int i = 0; i < gameObject.transform.childCount; i++)
                {
                    if (gameObject.transform.GetChild(i).GetComponent<Animation>() != null)
                    {
                        char_a = gameObject.transform.GetChild(i).Find("Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind");
                        if (char_a != null)
                        {
                            char_a.eulerAngles = target_neck_direction.eulerAngles;
                        }
                    }
                }
            }

            if (looking.progress <= 0.0f && looking.progress == 0.0f)
            {
                looking = null;
            }
        }

        if (turning != null)
        {
            if (turning.character == null)
            {
                turning = null;
                return;
            }
            Transform head_bind_pos = turning.character.transform.Find("Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind/jt_head_bind");

            if (head_bind_pos != null) turning.looking_position = head_bind_pos.position - transform.position;

            if (turning.progress < 1.0f && turning.progress < turning.destination_progress)
            {
                if (turning.progress <= 0.5f)
                {
                    turning.progress += 4f * Time.deltaTime * (turning.progress + 0.3f);
                }
                else
                {
                    turning.progress += 4f * Time.deltaTime * (1.0f - (turning.progress + 0.3f - 0.5f));
                }
            }

            if (turning.progress > 1.0f)
                turning.progress = 1.0f;

            else if (turning.progress > 0.0f && turning.progress > turning.destination_progress)
            {
                if (turning.progress >= 0.5f)
                {
                    turning.progress -= 4f * Time.deltaTime * (turning.progress + 0.3f);
                }
                else
                {
                    turning.progress -= 4f * Time.deltaTime * (1.0f - (turning.progress + 0.3f - 0.5f));
                }
            }

            if (turning.progress < 0.0f)
                turning.progress = 0.0f;


            //ROTATE NECK

            char_a = gameObject.transform.Find("Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind");
            //char_b = looking..transform.Find("Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind");
            if (char_a != null)
            {

                Quaternion target_neck_direction = Quaternion.LookRotation(gameObject.transform.position + turning.looking_position - char_a.position).normalized;

                target_neck_direction = Quaternion.Euler(target_neck_direction.eulerAngles + new Vector3(20, 0, -90));

                target_neck_direction = Quaternion.LerpUnclamped(char_a.rotation, target_neck_direction, turning.progress * 0.7f);

                char_a.eulerAngles = target_neck_direction.eulerAngles;
                char_a.localPosition = char_a.localPosition + new Vector3(0, 0, Mathf.Abs(target_neck_direction.eulerAngles.y * 0.008f));

                for (int i = 0; i < gameObject.transform.childCount; i++)
                {
                    if (gameObject.transform.GetChild(i).GetComponent<Animation>() != null)
                    {
                        char_a = gameObject.transform.GetChild(i).Find("Armature/jt_all_bind/jt_hips_bind/spine1_loResSpine2_bind/spine1_loResSpine3_bind/head1_neck_bind");
                        if (char_a != null)
                        {
                            char_a.eulerAngles = target_neck_direction.eulerAngles;
                            char_a.localPosition = char_a.localPosition + new Vector3(0, 0, target_neck_direction.eulerAngles.y * 0.008f);
                        }
                    }
                }
            }

            if (turning.progress <= 0.0f && turning.progress == 0.0f)
            {
                turning = null;
            }
        }
    }
}