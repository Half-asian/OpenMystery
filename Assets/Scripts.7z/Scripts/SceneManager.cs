﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using Newtonsoft.Json;
public class SceneManager : MonoBehaviour
{

    public static void addMasterSceneItems(ConfigScene._Scene current_scene)
    {
        if (current_scene.masterSceneId != null)
        {
            if (Configs.config_scene.Scene.ContainsKey(current_scene.masterSceneId))
            {
                if (Configs.config_scene.Scene[current_scene.masterSceneId].masterSceneId != null)
                {
                    addMasterSceneItems(Configs.config_scene.Scene[current_scene.masterSceneId]);
                }

                if (Configs.config_scene.Scene[current_scene.masterSceneId].camera_dict != null)
                {
                    if (current_scene.camera_dict == null)
                    {
                        current_scene.camera_dict = new Dictionary<string, ConfigScene._Scene.Camera>();
                    }
                    foreach (string master_camera_name in Configs.config_scene.Scene[current_scene.masterSceneId].camera_dict.Keys)
                    {
                        if (!current_scene.camera_dict.ContainsKey(master_camera_name))
                        {
                            current_scene.camera_dict[master_camera_name] = Configs.config_scene.Scene[current_scene.masterSceneId].camera_dict[master_camera_name];
                        }
                    }
                }

                if (Configs.config_scene.Scene[current_scene.masterSceneId].waypoint_dict != null)
                {
                    if (current_scene.waypoint_dict == null)
                    {
                        current_scene.waypoint_dict = new Dictionary<string, ConfigScene._Scene.WayPoint>();
                    }
                    foreach (string master_waypoint_name in Configs.config_scene.Scene[current_scene.masterSceneId].waypoint_dict.Keys)
                    {
                        if (!current_scene.waypoint_dict.ContainsKey(master_waypoint_name))
                        {
                            current_scene.waypoint_dict[master_waypoint_name] = Configs.config_scene.Scene[current_scene.masterSceneId].waypoint_dict[master_waypoint_name];
                        }
                    }
                }
                if (Configs.config_scene.Scene[current_scene.masterSceneId].proplocator_dict != null)
                {
                    if (current_scene.proplocator_dict == null)
                    {
                        current_scene.proplocator_dict = new Dictionary<string, ConfigScene._Scene.PropLocator>();
                    }

                    foreach (string master_proplocator_name in Configs.config_scene.Scene[current_scene.masterSceneId].proplocator_dict.Keys)
                    {
                        if (!current_scene.proplocator_dict.ContainsKey(master_proplocator_name))
                        {
                            current_scene.proplocator_dict[master_proplocator_name] = Configs.config_scene.Scene[current_scene.masterSceneId].proplocator_dict[master_proplocator_name];
                        }
                    }
                }
                if (Configs.config_scene.Scene[current_scene.masterSceneId].hotspot_dict != null)
                {
                    if (current_scene.hotspot_dict == null)
                    {
                        current_scene.hotspot_dict = new Dictionary<string, ConfigScene._Scene.HotSpot>();
                    }

                    foreach (string master_hotspot_name in Configs.config_scene.Scene[current_scene.masterSceneId].hotspot_dict.Keys)
                    {
                        if (!current_scene.hotspot_dict.ContainsKey(master_hotspot_name))
                        {
                            current_scene.hotspot_dict[master_hotspot_name] = Configs.config_scene.Scene[current_scene.masterSceneId].hotspot_dict[master_hotspot_name];
                        }
                    }
                }
            }
        }
    }
}