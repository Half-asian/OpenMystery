﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Assertions;
public class InteractionEncounter : Interaction
{
    public override void setup(ref ConfigInteraction.Interaction _interaction)
    {
        interaction = _interaction;
        Debug.Log(interaction.id);
        Assert.IsNotNull(interaction.encounterId, "InteractionEncounter(): interaction.encounterId can't be null");
        Assert.IsNotNull(interaction.spot, "InteractionEncounter(): interaction.spot can't be null");
        interaction_gameobject = gameObject;
        interaction_gameobject.name = interaction.id;
        interaction_gameobject.SetActive(false);
        GameStart.interaction_manager.StartCoroutine(waitEnterEvents());
    }

    public override void onFinishedEnterEvents()
    {
        interaction_gameobject.SetActive(true);
        interaction_gameobject.AddComponent<InteractionButton>();
        interaction_gameobject.GetComponent<InteractionButton>().interaction = this;
        setHotspot();
    }

    public override void activate()
    {
        if (parent_group_interaction != null)
            parent_group_interaction.destroyOptionalInteractions();


        if (Configs.config_encounter.Encounter[interaction.encounterId].type != "Date")
        {
            taskComplete();
        }
        else
        {
            GameStart.encounter_manager.activateEncounter(interaction.encounterId);
        }
        //Interaction is called from a callback.
        //finished();
    }
}
