﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Assertions;
public class InteractionTitleCard : Interaction
{
    public override void setup(ref ConfigInteraction.Interaction _interaction)
    {
        interaction = _interaction;
        interaction_gameobject = gameObject;
        interaction_gameobject.name = interaction.id;
        interaction_gameobject.SetActive(false);
        GameStart.interaction_manager.StartCoroutine(waitEnterEvents());
    }

    public override void onFinishedEnterEvents()
    {
        activate();
    }


    public override void activate()
    {
        taskComplete();
    }
}
