﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Assertions;
public class InteractionGroup : Interaction
{
    Dictionary<string, Interaction> member_interactions;

    public override void setup(ref ConfigInteraction.Interaction _interaction)
    {
        interaction = _interaction;
        interaction_gameobject = gameObject;
        interaction_gameobject.name = _interaction.id;
        Assert.IsNotNull(interaction.groupMembers, "InteractionGroup(): interaction.groupMembers can't be null");
        GameStart.interaction_manager.StartCoroutine(waitEnterEvents());
    }

    public override void onFinishedEnterEvents()
    {
        group_progress = 0;
        member_interactions = new Dictionary<string, Interaction>();


        spawnMemberInteractions();

        if (member_interactions.Count == 0)
        {
            GameObject.Destroy(interaction_gameobject);
        }
    }

    public void addMemberInteraction(Interaction interaction)
    {
        member_interactions[interaction.interaction.id] = interaction;
        interaction.parent_group_interaction = this;
    }

    public void spawnMemberInteractions()
    {
        foreach (string member_interaction in interaction.groupMembers)
        {
            if (!member_interactions.ContainsKey(member_interaction))
            {
                //Debug.Log("Activating member interaction " + member_interaction + " Interaction 169 of group " + interaction.id);


                GameObject result = GameStart.interaction_manager.activateInteraction(member_interaction);
                Interaction new_interaction = null;
                if (result != null)
                    new_interaction = result.GetComponent<Interaction>();
                if (new_interaction != null)
                {
                    new_interaction.parent_group_interaction = this;
                    new_interaction.interaction_gameobject.transform.parent = interaction_gameobject.transform;
                    member_interactions[member_interaction] = new_interaction;
                }
            }
        }
    }

    public void destroyOptionalInteractions()
    {
        List<string> interactions_to_remove = new List<string>();
        foreach (string i in member_interactions.Keys)
        {
            if (member_interactions[i].interaction.type == "Dialog" || member_interactions[i].interaction.type == "Exit")
                interactions_to_remove.Add(i);
        }
        foreach (string i in interactions_to_remove)
        {
            GameObject.Destroy(member_interactions[i].interaction_gameobject);
            member_interactions.Remove(i);
        }
    }

    public void memberInteractionFinished(Interaction member_interaction)
    {
        Debug.Log("member interaction finished " + member_interaction.interaction.id);
        group_progress += member_interaction.interaction.groupProgress;

        List<string> keys_to_remove = new List<string>();
        foreach (string key in member_interactions.Keys)
        {
            if (member_interactions[key] == member_interaction)
                keys_to_remove.Add(key);
        }
        foreach (string key in keys_to_remove)
            member_interactions.Remove(key);

        if (member_interaction.interaction.groupProgress != 0)
        {
            if (group_progress >= interaction.progressRequired)
            {
                Debug.Log("Group complete.");
                taskComplete(); //No more member interactions.
                
            }
        }
       // else //when was this useful?
            //spawnMemberInteractions(); //PREDICATES SHOULD BE CULLING THIS OFF. NOT A DANGER IF PREDICATES ARE FUNCTIONING - OBJECTION!!! PREDICATES ARENT ALWAYS DEFINED!
    }

    public void endGroup()
    {
        foreach (string i in member_interactions.Keys)
        {
            member_interactions[i].parentDestroyed();
        }
        destroy();
    }

    public override void activate() { return; }

}

