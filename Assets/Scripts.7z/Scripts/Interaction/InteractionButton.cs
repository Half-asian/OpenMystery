using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InteractionButton : MonoBehaviour
{
    bool mouse_hover;
    public Interaction interaction;
    Transform camera_transform;
    bool is_active = true;

    void OnMouseEnter()
    {
        mouse_hover = true;
    }

    private void OnMouseExit()
    {
        mouse_hover = false;
    }

    void FaceButtonToCamera(Transform textLookTargetTransform)
    {
        Vector3 targetDirection = textLookTargetTransform.position - transform.position;
        transform.rotation = Quaternion.LookRotation((targetDirection).normalized);
        transform.rotation = Quaternion.Euler(new Vector3(90.0f, transform.rotation.eulerAngles.y, 0.0f));
    }

    void Start()
    {
        camera_transform = GameObject.Find("Main Camera").GetComponent<Transform>();
        mouse_hover = false;
    }

    private void Update()
    {
        if (is_active)
        {
            FaceButtonToCamera(camera_transform);
            if ((Input.GetMouseButtonDown(0) && mouse_hover))
            {
                interaction.activate();
                is_active = false;
                this.GetComponent<MeshRenderer>().enabled = false;
            }
            if (Input.GetKeyDown("space"))
            {
                if (interaction.interaction.type == "AutotuneGroup" || interaction.interaction.type == null)
                {
                    is_active = false;
                    interaction.activate();
                }
            }
            if (interaction.interaction != null) //Hub NPC interactions aren't really interactions
            {
                if (interaction.interaction.autoSelect == true)
                {
                    interaction.activate();
                    is_active = false;
                    this.GetComponent<MeshRenderer>().enabled = false;
                }
            }
        }
    }
}
