using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Assertions;
public class InteractionMatch : Interaction
{
    public override void setup(ref ConfigInteraction.Interaction _interaction)
    {
        interaction = _interaction;
        Assert.IsNotNull(interaction.matchId, "InteractionMatch(): interaction.matchId can't be null");
        Assert.IsNotNull(interaction.spot, "InteractionMatch(): interaction.spot can't be null");
        interaction_gameobject = gameObject;
        interaction_gameobject.name = interaction.id;
        interaction_gameobject.SetActive(false);
        GameStart.interaction_manager.StartCoroutine(waitEnterEvents());
    }

    public override void onFinishedEnterEvents()
    {
        interaction_gameobject.SetActive(true);
        interaction_gameobject.AddComponent<InteractionButton>();
        interaction_gameobject.GetComponent<InteractionButton>().interaction = this;
        setHotspot();
    }

    public override void activate()
    {
        parent_group_interaction.destroyOptionalInteractions();

        GameObject.Destroy(interaction_gameobject);

        GameStart.quidditch_manager.startMatch(interaction.matchId, this); //Finished is called from a callback at the end of a match
    }
}
