﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Assertions;
public class InteractionDialog : Interaction
{
    public override void setup(ref ConfigInteraction.Interaction _interaction)
    {
        interaction = _interaction;
        Assert.IsNotNull(interaction.dialogId, "InteractionDialog(): interaction.dialogId can't be null");
        interaction_gameobject = gameObject;
        interaction_gameobject.name = interaction.id;
        interaction_gameobject.SetActive(false);
        GameStart.interaction_manager.StartCoroutine(waitEnterEvents());
    }

    public override void onFinishedEnterEvents()
    {
        interaction_gameobject.SetActive(true);
        interaction_gameobject.AddComponent<InteractionButton>();
        interaction_gameobject.GetComponent<InteractionButton>().interaction = this;
        if (interaction.spot != null) setHotspot();
    }


    public override void activate()
    {
        GameStart.dialogue_manager.onDialogueFinishedEvent += dialogueFinishedListener;
        GameStart.dialogue_manager.activateNewDialogue(interaction.dialogId);
    }

    public void dialogueFinishedListener(string dialogue)
    {
        //if (dialogue == interaction.dialogId)

        //We probably don't need to care about what dialogue actually finishes. Just that dialogue did end. Dialogues can lead to new dialogues, which wouldn't match.
        GameStart.dialogue_manager.onDialogueFinishedEvent -= dialogueFinishedListener;
        taskComplete();
    }
}
