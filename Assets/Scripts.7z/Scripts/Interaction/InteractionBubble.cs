﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Assertions;
public class InteractionBubble : Interaction
{
    public override void setup(ref ConfigInteraction.Interaction _interaction)
    {
        interaction = _interaction;
        Assert.IsNotNull(interaction.hudDialogSpeaker, "InteractionBubble(): interaction.hudDialogSpeaker can't be null");
        Assert.IsNotNull(interaction.endHudDialog, "InteractionBubble(): interaction.endHudDialog can't be null");
        interaction_gameobject = gameObject;
        interaction_gameobject.name = interaction.id;
        GameStart.interaction_manager.StartCoroutine(waitEnterEvents());
    }

    public override void onFinishedEnterEvents()
    {
        GameStart.dialogue_manager.in_bubble = true;

        interaction_gameobject.AddComponent<InteractionButton>();
        interaction_gameobject.GetComponent<InteractionButton>().interaction = this;

        if (interaction.hudDialogSpeaker != null)
            GameStart.dialogue_manager.showBubbleDialogue(interaction.hudDialogSpeaker, interaction.endHudDialog);
    }

    public override void activate()
    {
        taskComplete();
    }
}
