using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;
using UnityEngine.Assertions;
public class InteractionManager : MonoBehaviour {
    //This class and the other interaction classesneeds to be rock solid
    //as they are a critical part of the engine. 
    //Don't change any code, unless you know what you're doing.

    //Coroutines from the Interaction class run on this object. 

    public List<ObjectiveInteractionComplete> objective_callbacks = new List<ObjectiveInteractionComplete>();
    
    public void activateHubNPCInteraction(ref string dialogue_id, ref Vector3 location)
    {
        GameObject interaction_gameobject = GameObject.Instantiate(Resources.Load<GameObject>("hud_important"), Vector3.zero, Quaternion.identity);
        InteractionHubNPCDialog hub_npc_interaction = interaction_gameobject.AddComponent<InteractionHubNPCDialog>();
        hub_npc_interaction.hubNpcDialogSetup(ref dialogue_id, ref location);
    }

    public GameObject activateInteraction(string interaction_name)
    {
        Debug.Log("Activating Interaction: " + interaction_name);

        if (!Configs.config_interaction.Interactions.ContainsKey(interaction_name))
        {
            throw new System.Exception("Activate Interaction - Invalid Interaction " + interaction_name);
        }

        ConfigInteraction.Interaction new_interaction = Configs.config_interaction.Interactions[interaction_name];

        if (Configs.config_interaction.Interactions[interaction_name].filterPredicate != null)
        {
            if (!Predicate.parsePredicate(Configs.config_interaction.Interactions[interaction_name].filterPredicate))
            {
                Debug.Log("Failed the predicate: " + Configs.config_interaction.Interactions[interaction_name].filterPredicate);
                return null;
            }
        }

        GameObject interaction_gameobject = null;

        Assert.IsNotNull(new_interaction);

        switch (new_interaction.type)
        {
            case "Group":
                bool could_be_project = false;
                foreach (string group_member in new_interaction.groupMembers)
                {
                    if (Configs.config_interaction.Interactions[group_member].type == null)
                    { //Aka a bubble
                        could_be_project = true;
                    }
                    else if (could_be_project == true) throw new System.Exception("Weird mix of null interaction and non null interaction " + new_interaction.id);
                }
                if (could_be_project == false)
                {
                    //Group interactions can be spawned from the new scenario but also from a leads to. Double check that we're not spawning a dupe
                    if (GameObject.Find(new_interaction.id) == null)
                    {
                        interaction_gameobject = new GameObject();
                        interaction_gameobject.AddComponent<InteractionGroup>().setup(ref new_interaction);
                    }
                    break;
                }
                else
                    goto case "AutotuneGroup";
                

            case "AutotuneGroup":
                interaction_gameobject = new GameObject();
                interaction_gameobject.AddComponent<InteractionAutotuneGroup>().setup(ref new_interaction);
                break;

            case "Dialog":
                interaction_gameobject = GameObject.Instantiate(Resources.Load<GameObject>("hud_dialog"), Vector3.zero, Quaternion.identity);
                interaction_gameobject.AddComponent<InteractionDialog>().setup(ref new_interaction);
                break;

            case "GoalDialog":
                interaction_gameobject = GameObject.Instantiate(Resources.Load<GameObject>("hud_important"), Vector3.zero, Quaternion.identity);
                interaction_gameobject.AddComponent<InteractionGoalDialog>().setup(ref new_interaction);
                break;

            case "Project":
                interaction_gameobject = GameObject.Instantiate(Resources.Load<GameObject>("hud_important"), Vector3.zero, Quaternion.identity);
                interaction_gameobject.AddComponent<InteractionProject>().setup(ref new_interaction);
                break;

            case "Match":
                interaction_gameobject = GameObject.Instantiate(Resources.Load<GameObject>("hud_important"), Vector3.zero, Quaternion.identity);
                interaction_gameobject.AddComponent<InteractionMatch>().setup(ref new_interaction);
                break;

            case "Exit":
             /* interaction_gameobject = GameObject.Instantiate(Resources.Load<GameObject>("hud_exit"), Vector3.zero, Quaternion.identity);
                result_interaction = null;*///new Exit(ref new_interaction);
                break;

            case null:
                interaction_gameobject = new GameObject();
                interaction_gameobject.AddComponent<InteractionBubble>().setup(ref new_interaction);
                break;

            case "Encounter":
                interaction_gameobject = GameObject.Instantiate(Resources.Load<GameObject>("hud_important"), Vector3.zero, Quaternion.identity);
                interaction_gameobject.AddComponent<InteractionEncounter>().setup(ref new_interaction);
                break;

            case "TitleCard":
                interaction_gameobject = new GameObject();
                interaction_gameobject.AddComponent<InteractionTitleCard>().setup(ref new_interaction);
                break;

            case "ActivityComplete":
                interaction_gameobject = new GameObject();
                interaction_gameobject.AddComponent<InteractionActivityComplete>().setup(ref new_interaction);
                break;

            case "Focus":
                interaction_gameobject = new GameObject();
                interaction_gameobject.AddComponent<InteractionFocus>().setup(ref new_interaction);
                break;

            case "InteractionQTE":
                interaction_gameobject = new GameObject();
                interaction_gameobject.AddComponent<InteractionQTE>().setup(ref new_interaction);
                break;

            default:
                GameObject.Find("MainMenuCanvas").GetComponent<MainMenu>().fakeCrash("Unknown interaction type", new_interaction.type + " in " + new_interaction.id);
                break;
        }

        return interaction_gameobject;
    }

    public void finishInteraction(Interaction interaction)
    {
        foreach(ObjectiveInteractionComplete objective in objective_callbacks)
        {
            objective.interactionFinishedCheck(interaction.interaction.id);
        }
    }
}