﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Assertions;
public class InteractionAutotuneGroup : Interaction
{
    int member_counter;

    public override void setup(ref ConfigInteraction.Interaction _interaction)
    {
        interaction = _interaction;
        Assert.IsNotNull(interaction.groupMembers, "InteractionAutotuneGroup(): interaction.groupMembers can't be null");
        interaction_gameobject = gameObject;
        interaction_gameobject.name = interaction.id;

        List<Bubble> bubbles = new List<Bubble>();
        foreach (string group_member in interaction.groupMembers)
        {
            Bubble new_bubble = new Bubble();
            new_bubble.speaker = Configs.config_interaction.Interactions[group_member].hudDialogSpeaker;
            new_bubble.text = Configs.config_interaction.Interactions[group_member].endHudDialog;
            Assert.IsNotNull(new_bubble.speaker, "InteractionAutotuneGroup(): bubble.speaker can't be null");
            Assert.IsNotNull(new_bubble.text, "InteractionAutotuneGroup(): bubble.text can't be null");
            bubbles.Add(new_bubble);
        }

        GameStart.interaction_manager.StartCoroutine(waitEnterEvents());

    }

    public void Shuffle(List<Bubble> list)
    {
        for (int i = 0; i < list.Count; i++)
        {
            Bubble temp = list[i];
            int randomIndex = UnityEngine.Random.Range(i, list.Count);
            list[i] = list[randomIndex];
            list[randomIndex] = temp;
        }
    }

    public override void onFinishedEnterEvents()
    {
        member_counter = 0;
        GameStart.dialogue_manager.in_bubble = true;

        memberInteractionFinished(null);
    }

    public void memberInteractionFinished(Interaction member_interaction)
    {
        if (member_counter < interaction.groupMembers.Length)
        {
            Interaction new_bubble = null;
            while (new_bubble == null && member_counter < interaction.groupMembers.Length)
            {
                new_bubble = GameStart.interaction_manager.activateInteraction(interaction.groupMembers[member_counter]).GetComponent<Interaction>();
                new_bubble.parent_autotune_group_interaction = this;
                member_counter++;
            }
            if (new_bubble != null)
            {
                new_bubble.parent_autotune_group_interaction = this;
                new_bubble.interaction_gameobject.transform.parent = interaction_gameobject.transform;
            }
            else
            {
                GameStart.dialogue_manager.finishBubbleDialogue();
                taskComplete(); //We are done
                if (interaction.leadsTo[0] == "exit" && interaction.leadsToPredicate == null)
                {
                    GameStart.finishProject();
                }
            }
        }
        else
        {
            GameStart.dialogue_manager.finishBubbleDialogue();
            taskComplete(); //We are done
            if (interaction.leadsTo[0] == "exit" && interaction.leadsToPredicate == null)
            {
                GameStart.finishProject();
            }
        }
    }
    public override void activate() { return; }
}
