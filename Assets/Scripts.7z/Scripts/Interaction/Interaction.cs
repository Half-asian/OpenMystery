using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Assertions;
using System;

/*
Interaction Class Lifespan

Wait for enter events to finish
Spawn Group members - Only if group
Wait for task to complete
Spawn leads to
Wait for leads to complete
Wait for exit events to finish
Return groupProgress to parent
*/

public abstract class Interaction : MonoBehaviour
{
    [SerializeField]
    public ConfigInteraction.Interaction interaction { get; protected set; }
    public InteractionGroup parent_group_interaction { get; set; }
    public InteractionAutotuneGroup parent_autotune_group_interaction { get; set; }
    public GameObject interaction_gameobject { get; protected set; }

    [SerializeField]
    protected int group_progress = 0;

    public abstract void setup(ref ConfigInteraction.Interaction interaction);
    protected IEnumerator waitEnterEvents()
    {
        if (interaction != null)
        {
            if (interaction.enterEvents != null)
            {
                GameStart.event_manager.event_stack.AddRange(interaction.enterEvents);
                GameStart.event_manager.runImmediateEvents();
                while (!(GameStart.event_manager.block_duration == 0.0f && GameStart.event_manager.total_block == false))
                {
                    yield return null;
                }
            }
            onFinishedEnterEvents();
        }
    }
    public abstract void onFinishedEnterEvents();
    public abstract void activate();
    public void taskComplete()
    {
        GameStart.interaction_manager.StartCoroutine(waitExitEvents());
    }
    protected IEnumerator waitExitEvents()
    {
        Assert.IsNotNull(interaction, "finished interaction was null");

        Debug.Log("Finished interaction " + interaction.id);

        if (interaction.exitEvents != null)
        {
            GameStart.event_manager.event_stack.AddRange(interaction.exitEvents);
            GameStart.event_manager.runImmediateEvents();
            while (!(GameStart.event_manager.block_duration == 0.0f && GameStart.event_manager.total_block == false))
            {
                yield return null;
            }
        }

        if (interaction.successEvents != null) //I guess we can fail some stuff. Not for now though.
        {
            GameStart.event_manager.event_stack.AddRange(interaction.successEvents);
            GameStart.event_manager.runImmediateEvents();
            while (!(GameStart.event_manager.block_duration == 0.0f && GameStart.event_manager.total_block == false))
            {
                yield return null;
            }
        }

        if (interaction.qteSuccessEvents != null) //I guess we can fail some stuff. Not for now though.
        {
            GameStart.event_manager.event_stack.AddRange(interaction.qteSuccessEvents);
            GameStart.event_manager.runImmediateEvents();
            while (!(GameStart.event_manager.block_duration == 0.0f && GameStart.event_manager.total_block == false))
            {
                yield return null;
            }
        }

        onFinishedExitEvents();
    }
    public void onFinishedExitEvents()
    {
        if (interaction.leadsTo != null)
        {
            spawnLeadsTo();
        }
        else
        {
            destroy();
        }
    }
    public void spawnLeadsTo()
    {
        if (interaction.leadsToPredicate != null)
        {
            int best_match_leads_to = interaction.leadsToPredicate.Length - 1;
            if (interaction.leadsToPredicate != null)
            {
                for (int i = interaction.leadsToPredicate.Length - 1; i >= 0; i--)
                {
                    if (Predicate.parsePredicate(interaction.leadsToPredicate[i]))
                    {
                        best_match_leads_to = i;
                    }
                }
            }
            Debug.Log("Activating a leads to " + interaction.leadsTo[best_match_leads_to]);
            Interaction leads_to_interaction = GameStart.interaction_manager.activateInteraction(interaction.leadsTo[best_match_leads_to]).GetComponent<Interaction>();
            if (parent_group_interaction != null)
            {
                parent_group_interaction.addMemberInteraction(leads_to_interaction);
            }
            destroy();
        }
        else
        {
            if (interaction.id == "NewNuxMQ1C1P1_Project_4")
                interaction.leadsTo[0] = "NewNuxMQ1C1P1_Project_4_Dialog"; //NewNuxMQ1C1P1_Project_4_Dialog is called from nowhere. This is a hack to activate it.

            if (interaction.leadsTo[0] != "exit")
            {
                Debug.Log("Activating leads to " + interaction.leadsTo[0]);
                GameObject leads_to_gameobject = GameStart.interaction_manager.activateInteraction(interaction.leadsTo[0]);
                if (leads_to_gameobject == null)
                {
                    Debug.LogError(interaction.leadsTo[0] + " spawned a null gameobject ");
                }
                else {
                    Interaction leads_to_interaction = leads_to_gameobject.GetComponent<Interaction>();
                    if (parent_group_interaction != null)
                    {
                        parent_group_interaction.addMemberInteraction(leads_to_interaction);
                    }
                }
                destroy();
            }
            else
            {
                if (parent_group_interaction != null)
                {
                    parent_group_interaction.endGroup();
                }
                else
                {
                    destroy();
                }
            }
        }
    }

    public void destroy()
    {
        if (interaction.id == "PI_CureForBoils_Finish_52")
        {
            GameStart.finishProject();
        }


        GameStart.game_state.interactions_complete.Add("interactionComplete(\"" + interaction.id + "\")");

        GameStart.interaction_manager.finishInteraction(this);

        GameObject.Destroy(interaction_gameobject);

        if (parent_group_interaction != null)
            parent_group_interaction.memberInteractionFinished(this);
        if (parent_autotune_group_interaction != null)
            parent_autotune_group_interaction.memberInteractionFinished(this);
    }

    public void parentDestroyed()
    {
        GameStart.game_state.interactions_complete.Add("interactionComplete(\"" + interaction.id + "\")");

        GameStart.interaction_manager.finishInteraction(this);

        GameObject.Destroy(interaction_gameobject);

    }
    protected void setHotspot()
    {
        if (GameStart.game_state.scenario_holder.scene.hotspot_dict != null)
        {
            if (GameStart.game_state.scenario_holder.scene.hotspot_dict.ContainsKey(interaction.spot))
            {
                ConfigScene._Scene.HotSpot hotspot = GameStart.game_state.scenario_holder.scene.hotspot_dict[interaction.spot];
                interaction_gameobject.transform.position = new Vector3(hotspot.position[0] * -0.01f, hotspot.position[1] * 0.01f + 0.2f, hotspot.position[2] * 0.01f);
            }
            else
            {
                Log.writeFull("Interaction.setHotspot interaction " + interaction.id + ": scene " + GameStart.game_state.scenario_holder.scene.envId + " does not define hotspot " + interaction.spot, "error");
            }
        }
        else
        {
            Log.writeFull("Interaction.setHotspot interaction " + interaction.id + ": scene " + GameStart.game_state.scenario_holder.scene.envId + " has no hotspots defined", "error");
        }
    }
}


public class Bubble
{
    public string speaker;
    public string text;
}
