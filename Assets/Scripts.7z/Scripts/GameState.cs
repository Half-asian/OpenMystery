using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameState
{
    public enum GameType
    {
        GameTypeYear1,
        GameTypeYear2,
        GameTypeYear3,
        GameTypeYear4,
        GameTypeYear5,
        GameTypeYear6,
        GameTypeYear7,
        GameTypeTLSQ,
        GameTypeSQ,
        GameTypeQuidditch,
        GameTypeUnspecified,
        GameTypeDebug,
    }

    public enum State
    {
        StateMenu,
        StateLoading,
        StateFinishedLoading,
        StateGame,
        StateQuidditch,
    }
    public State state = State.StateMenu;


    public GoalChain goal_chain;


    public ScenarioHolder scenario_holder;

    public GameObject current_scene_game_object;
    public ConfigProject._Project current_project;
    public Dictionary<string, CharacterManager> characters = new Dictionary<string, CharacterManager>();
    public Dictionary<string, Prop> spawned_props = new Dictionary<string, Prop>();
    public List<GameObject> characters_gameobjects = new List<GameObject>(); //we can't use the character dictionary as a complete reference of all spawned characters. This is because there is no unique spawn identifier.
    public List<string> interactions_complete = new List<string>();

    //Assets
    public Dictionary<string, Texture2D> loaded_textures = new Dictionary<string, Texture2D>();
    public Dictionary<string, ModelManager.c3t> loaded_models = new Dictionary<string, ModelManager.c3t>();

    public string companionId = "chiara";

    public class ScenarioHolder
    {

        ConfigScene._Scene current_scene;
        public ConfigScenario._Scenario current_scenario;
        public bool scene_has_changed = true;

        public ConfigScene._Scene scene
        {
            get { return current_scene; }
        }
        public ConfigScenario._Scenario scenario
        {
            get { return current_scenario; }
        }

        public ScenarioHolder(string scenario_name)
        {
            if (!Configs.config_scenario.Scenario.ContainsKey(scenario_name))
                throw new System.Exception("Create Scenario - invalid scenario name.");
            current_scenario = Configs.config_scenario.Scenario[scenario_name];
            if (current_scenario.sceneOverrides != null)
            {
                if (current_scenario.sceneOverrides.ContainsKey(DialogueManager.local_avatar_house))
                    setCurrentScene(current_scenario.sceneOverrides[DialogueManager.local_avatar_house]);
            }
            else
                setCurrentScene(current_scenario.scene);
            Debug.Log("Activating new scenario: " + current_scenario.scenarioId + " with scene " + current_scene.layoutId);
        }

        public void setCurrentScene(string scene_name)
        {


            if (!Configs.config_scene.Scene.ContainsKey(scene_name))
                throw new System.Exception("Set Scene - invalid scene name.");
            if (current_scene != null)
                scene_has_changed = current_scene.layoutId != Configs.config_scene.Scene[scene_name].layoutId;
            current_scene = Configs.config_scene.Scene[scene_name];
            SceneManager.addMasterSceneItems(current_scene);
            if (current_scene == null)
            {
                throw new System.Exception("Set Scene - Did not set the scene.");
            }
        }
    }

    public void refreshBgSound()
    {
        if (scenario_holder.current_scenario.bgSoundPlaylistId != null)
        {
            if (Configs.playlist_dict.ContainsKey(scenario_holder.current_scenario.bgSoundPlaylistId))
            {
                if (Configs.playlist_dict[scenario_holder.current_scenario.bgSoundPlaylistId].files != null)
                {
                    GameStart.dialogue_manager.playAudioFile(Configs.playlist_dict[scenario_holder.current_scenario.bgSoundPlaylistId].files[0], "bgaudio");
                }
            }
        }
    }

    public void refreshMusic()
    {
        if (scenario_holder.scenario.musicPlaylistId != null)
        {
            if (Configs.playlist_dict.ContainsKey(scenario_holder.scenario.musicPlaylistId))
            {
                if (Configs.playlist_dict[scenario_holder.scenario.musicPlaylistId].files != null)
                {
                    GameStart.dialogue_manager.playAudioFile(Configs.playlist_dict[scenario_holder.scenario.musicPlaylistId].files[0], "bgaudio");
                }
            }
        }
    }

    public void destroy()
    {
        if (current_scene_game_object != null)
        {
            GameObject.Destroy(current_scene_game_object);
        }
        foreach (GameObject c in characters_gameobjects)
        {
            GameObject.Destroy(c.gameObject);
        }
        foreach (GameObject g in GameObject.FindGameObjectsWithTag("hud_dialog"))
        {
            GameObject.Destroy(g);
        }
        foreach (GameObject g in GameObject.FindGameObjectsWithTag("hud_important"))
        {
            GameObject.Destroy(g);
        }
    }

    public void spawnScenarioActors()
    {
        float time = Time.realtimeSinceStartup;

        state = GameState.State.StateLoading;
        Dictionary<string, string> textures_to_add = new Dictionary<string, string>();

        Config3DModel._Config3DModel env_model = Configs.config_environment_model.ModelConfig[scenario_holder.scene.envId];
        foreach (string texture in env_model.jsonData[0].neededTextureKeys)
        {
            if (!textures_to_add.ContainsKey(texture) && !loaded_textures.ContainsKey(texture))
            {
                textures_to_add[texture] = env_model.name;
            }
        }

        if (scenario_holder.scenario.charSpawns != null)
        {
            foreach (ConfigScenario._Scenario.CharSpawn char_spawn in scenario_holder.scenario.charSpawns)
            {
                ConfigHPActorInfo._HPActorInfo character;

                if (!Configs.config_hp_actor_info.HPActorInfo.ContainsKey(char_spawn.charId))
                {
                    Debug.LogWarning("Could not find actor info for " + char_spawn.charId);
                    character = Configs.config_hp_actor_info.HPActorInfo["c_Skye_skin"];
                }
                else
                {
                    character = Configs.config_hp_actor_info.HPActorInfo[char_spawn.charId];


                    foreach (string texture in Configs.config_character_model.ModelConfig[character.modelId].jsonData[0].neededTextureKeys)
                    {
                        if (!textures_to_add.ContainsKey(texture) && !loaded_textures.ContainsKey(texture))
                        {
                            textures_to_add[texture] = Configs.config_character_model.ModelConfig[character.modelId].name;
                        }
                    }
                    if (character.modelPatches != null)
                    {
                        foreach (string patch in character.modelPatches)
                        {
                            if (patch[0] == 'c')
                            {
                                foreach (string texture in Configs.config_character_model.ModelConfig[patch].jsonData[0].neededTextureKeys)
                                {
                                    if (!textures_to_add.ContainsKey(texture) && !loaded_textures.ContainsKey(texture))
                                    {
                                        textures_to_add[texture] = Configs.config_character_model.ModelConfig[patch].name;
                                    }
                                }
                            }
                            else if (patch[0] == 'o')
                            {
                                foreach (string texture in Configs.config_outfit_model.ModelConfig[patch].jsonData[0].neededTextureKeys)
                                {
                                    if (!textures_to_add.ContainsKey(texture) && !loaded_textures.ContainsKey(texture))
                                    {
                                        textures_to_add[texture] = Configs.config_outfit_model.ModelConfig[patch].name;
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (scenario_holder.scene.proplocator_dict != null)
            {
                foreach (ConfigScene._Scene.PropLocator prop_locator in scenario_holder.scene.proplocator_dict.Values)
                {
                    foreach (string texture in Configs.config_prop_model.ModelConfig[prop_locator.reference].jsonData[0].neededTextureKeys)
                    {
                        if (!textures_to_add.ContainsKey(texture) && !loaded_textures.ContainsKey(texture))
                        {
                            textures_to_add[texture] = Configs.config_prop_model.ModelConfig[prop_locator.reference].name;
                        }
                    }

                }
            }

            int texture_total = loaded_textures.Count + textures_to_add.Count;

            foreach (string texture in textures_to_add.Keys)
            {
                //StartCoroutine(TextureManager.ImportTextureFromFile(texture, textures_to_add[texture]));
                loaded_textures[texture] = TextureManager.loadTextureDDS(texture);

            }
            Debug.Log("Request Textures " + (Time.realtimeSinceStartup - time).ToString());



            //ModelManager.c3t env_c3t = ModelManager.loadc3t(ModelManager.getPatchedName(game_state.scenario_holder.scene.envId), "c3t").Result;

            //while (game_state.loaded_textures.Count != texture_total)
            //{
            //    yield return null;
            //}

            Debug.Log("Loaded Textures " + (Time.realtimeSinceStartup - time).ToString());


            if (current_scene_game_object != null)
            {
                GameObject.Destroy(current_scene_game_object);
            }

            if (scenario_holder.scene != null)
            {
                ModelManager.loadModel(ref current_scene_game_object, scenario_holder.scene.envId, "c3b");
            }

            if (scenario_holder.scenario.charSpawns != null)
            {
                foreach (ConfigScenario._Scenario.CharSpawn char_spawn in scenario_holder.scenario.charSpawns)
                {
                    ActorSpawn.spawnCharacterInScene(char_spawn.charId, char_spawn.waypointId, char_spawn.instanceId);
                }
            }

            if (scenario_holder.scene.proplocator_dict != null)
            {
                foreach (ConfigScene._Scene.PropLocator prop_locator in scenario_holder.scene.proplocator_dict.Values)
                {
                    Prop.spawnPropFromLocator(prop_locator);
                }
            }

            if (scenario_holder.scenario.randomSpawns != null)
            {
                foreach (string[] spawn_strings in scenario_holder.scenario.randomSpawns)
                {
                    if (spawn_strings.Length > 1)
                    {
                        Debug.LogError("GameStart:ActivateScenario - more than 1 npcwaypoint listed in random spawn");
                    }
                    ConfigNpcWaypointSpawn._NpcWaypointSpawn spawn = Configs.config_npc_waypoint_spawn.NpcWaypointSpawn[spawn_strings[0]];

                    int random_character = Random.Range(0, spawn.validCharacters.Length);
                    int random_sequence = Random.Range(0, spawn.validSequences.Length);

                    ActorSpawn.spawnCharacterInScene(spawn.validCharacters[random_character], spawn.waypoint, spawn.spawnId);

                    if (Configs.config_char_anim_sequence.CharAnimSequence.ContainsKey(spawn.validSequences[random_sequence]))
                    {
                        characters[spawn.spawnId].gameObject.AddComponent<CharAnimSequenceHandler>();
                        characters[spawn.spawnId].gameObject.GetComponent<CharAnimSequenceHandler>().initAnimSequence(spawn.validSequences[random_sequence], false);
                    }
                    else
                    {
                        characters[spawn.spawnId].replaceCharacterIdle(spawn.validSequences[random_sequence]);
                    }
                }
            }

            if (GameStart.game_state.goal_chain.getCurrentObjective().objectiveHubNpcs != null)
            {
                foreach (string objective_hub_npc_string in GameStart.game_state.goal_chain.getCurrentObjective().objectiveHubNpcs)
                {
                    ConfigHubNPC._HubNPC objective_hub_npc = Configs.config_hub_npc.HubNPC[objective_hub_npc_string];
                    ActorSpawn.spawnCharacterInScene(objective_hub_npc.actorId, objective_hub_npc.hubWaypoint, objective_hub_npc.hubNpcId);

                }
            }

            textures_to_add.Clear();

            state = GameState.State.StateFinishedLoading;
        }

    }

    public string getCurrentScenario()
    {
        if (scenario_holder != null)
        {
            if (scenario_holder.current_scenario != null)
                return scenario_holder.current_scenario.scenarioId;
        }
        return null;
    }
}
