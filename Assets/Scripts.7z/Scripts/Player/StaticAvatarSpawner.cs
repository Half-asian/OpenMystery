﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

class StaticAvatarSpawner
{
    public static CharacterManager spawnStaticAvatar(ref GameObject parent_gameobject)
    {
        parent_gameobject = null;
        //Get the Avatar components
        AvatarComponents avatar_components = new AvatarComponents(GlobalEngineVariables.player_folder + "\\avatar.json");

        //Get the character. Spawn the animator.
        ConfigHPActorInfo._HPActorInfo character = Configs.config_hp_actor_info.HPActorInfo[PlayerManager.current.character_id];
        Dictionary<string, Transform> parent_bones =  ModelManager.loadModel(ref parent_gameobject, character.modelId, "c3b");
        parent_gameobject.name = "Avatar";


        CharacterManager c = parent_gameobject.AddComponent<CharacterManager>();
        parent_gameobject.AddComponent<Animation>();
        c.actor_info = character;
        c.animId_idle = character.animId_idle;
        c.patches = new List<GameObject>();
        c.parent_bones = parent_bones;

        avatar_components.setCharacterManager(c);
        avatar_components.base_bones = parent_bones;

        if (PlayerManager.current.gender == "male")
        {
            avatar_components.spawnComponents("c_Avatar_Male_headNoseless_skin");
        }
        else
        {
            avatar_components.spawnComponents("c_Avatar_Female_headNoseless_skin");
        }

        avatar_components.base_component.transform.parent = parent_gameobject.transform;

        foreach (IAvatarComponent component in avatar_components.categories.Values)
        {
            GameObject g = component.getGameObject();
            if (g != null) c.patches.Add(g);
        }

        c.bone_mods = avatar_components.bonemods;
        c.replaceCharacterIdleNoDelay(c.actor_info.animId_idle);
        c.setCharacterIdle();
        c.model_name = character.modelId;





        return c;
    }
}

