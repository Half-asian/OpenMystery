using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Newtonsoft.Json;
using System.IO;
using System.Text;

public class AvatarComponents
{
    public Dictionary<string, AnimationManager.BoneMod> bonemods;

    public string actor_id;
    public string gender;

    public Dictionary<string, IAvatarComponent> categories;

    public CharacterManager character;

    public GameObject base_component = null;
    public Dictionary<string, Transform> base_bones;

    public Dictionary<string, PlayerFile.CustomizationCategory> customization_categories;

    public AvatarComponents(string filename)
    {
        categories = new Dictionary<string, IAvatarComponent>();
        bonemods = new Dictionary<string, AnimationManager.BoneMod>();
        actor_id = PlayerManager.current.character_id;

        resetFromPlayerFile();
    }
    
    public void resetFromPlayerFile()
    {
        customization_categories = new Dictionary<string, PlayerFile.CustomizationCategory>();
        foreach (string key in PlayerManager.current.customization_categories.Keys)
        {
            customization_categories[key] = new PlayerFile.CustomizationCategory();
            customization_categories[key].component_id = string.Copy(PlayerManager.current.customization_categories[key].component_id);
            if (PlayerManager.current.customization_categories[key].float_parameters != null)
            {
                customization_categories[key].float_parameters = new Dictionary<string, float>();
                foreach (string fkey in PlayerManager.current.customization_categories[key].float_parameters.Keys)
                {
                    customization_categories[key].float_parameters[fkey] = PlayerManager.current.customization_categories[key].float_parameters[fkey];
                }
            }
            if (PlayerManager.current.customization_categories[key].int_parameters != null)
            {
                customization_categories[key].int_parameters = new Dictionary<string, int>();
                foreach (string fkey in PlayerManager.current.customization_categories[key].int_parameters.Keys)
                {
                    customization_categories[key].int_parameters[fkey] = PlayerManager.current.customization_categories[key].int_parameters[fkey];
                }
            }
        }
    }

    public void commitChanges()
    {
        PlayerManager.current.customization_categories = customization_categories;
    }

    public void undoChanges()
    {
        resetFromPlayerFile();
        throw new System.NotImplementedException();
    }

    public void setCharacterManager(CharacterManager _character)
    {
        character = _character;
    }

    public void spawnComponents(string base_component_name)
    {
        if (base_component_name.Contains("Female") || base_component_name.Contains("female")) {
            gender = "female";
        }
        else
        {
            gender = "male";
        }
        
        if (base_bones == null)
            base_bones = ModelManager.loadModel(ref base_component, base_component_name, "c3b");
        else
            ModelManager.loadModel(ref base_component, base_component_name, "c3b", base_bones);


        categories["hands"] = new IndividualComponents.ComponentHands(this);

        foreach (string category in PlayerManager.current.customization_categories.Keys)
        {
            switch (category)
            {
                case "brows":
                    categories["brows"] = new IndividualComponents.ComponentBrows(this);
                    break;
                case "eyes":
                    categories["eyes"] = new IndividualComponents.ComponentEyes(this);
                    break;
                case "faces":
                    categories["faces"] = new IndividualComponents.ComponentFaces(this);
                    break;
                case "nose":
                    categories["nose"] = new IndividualComponents.ComponentNose(this);
                    break;
                case "lips":
                    categories["lips"] = new IndividualComponents.ComponentLips(this);
                    break;
                case "hair":
                    categories["hair"] = new IndividualComponents.ComponentHair(this);
                    break;
                case "glasses":
                    categories["glasses"] = new IndividualComponents.ComponentGlasses(this);
                    break;
                case "one-piece":
                    categories["one-piece"] = new IndividualComponents.ComponentOnePiece(this);
                    break;
                case "tops":
                    categories["tops"] = new IndividualComponents.ComponentTop(this);
                    break;
                case "bottom":
                    categories["bottom"] = new IndividualComponents.ComponentBottom(this);
                    break;
                case "right-wrist":
                    categories["right-wrist"] = new IndividualComponents.ComponentRightWrist(this);
                    break;
            }
        }
    }

    

    public void changeAvatarBrowThickness(float browThickness) { categories["brows"].setFloat(browThickness, "browThickness"); }
    public void changeAvatarEyeCloseness(float eyeCloseness) { categories["eyes"].setFloat(eyeCloseness, "eyeCloseness"); }
    public void changeAvatarEyeSize(float eyeSize) { categories["eyes"].setFloat(eyeSize, "eyeSize"); }
    public void changeAvatarEyeY(float eyeY) { categories["eyes"].setFloat(eyeY, "eyeY"); }
    public void changeAvatarChinSize(float chinSize) { categories["faces"].setFloat(chinSize, "chinSize"); }
    public void changeAvatarJawSize(float chinSize) { categories["faces"].setFloat(chinSize, "jawSize"); }
    public void changeAvatarNoseBridgeHeight(float noseBridgeHeight) { categories["nose"].setFloat(noseBridgeHeight, "noseBridgeHeight"); }
    public void changeAvatarNoseBridgeLength(float noseBridgeLength) { categories["nose"].setFloat(noseBridgeLength, "noseBridgeLength"); }
    public void changeAvatarNoseBridgeWidth(float noseBridgeWidth) { categories["nose"].setFloat(noseBridgeWidth, "noseBridgeWidth"); }
    public void changeAvatarNoseFatness(float noseFatness) { categories["nose"].setFloat(noseFatness, "noseFatness"); }
    public void changeAvatarNoseHeight(float noseHeight) { categories["nose"].setFloat(noseHeight, "noseHeight"); }
    public void changeAvatarNoseWidth(float noseWidth) { categories["nose"].setFloat(noseWidth, "noseWidth"); }
    public void changeAvatarNoseLength(float noseLength) { categories["nose"].setFloat(noseLength, "noseLength"); }
    public void changeAvatarNoseTwist(float noseTwist) { categories["nose"].setFloat(noseTwist, "noseTwist"); }

    public void replaceAvatarArms(string component_id)
    {
        categories["arms"] = new IndividualComponents.ComponentArms(this, component_id);
    }
}

public interface IAvatarComponent
{
    void setFloat(float f, string s);
    void setInt(int i, string s);
    GameObject getGameObject();
}
