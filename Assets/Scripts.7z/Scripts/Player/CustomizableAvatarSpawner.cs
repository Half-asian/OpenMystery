using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CustomizableAvatarSpawner : MonoBehaviour
{
    public static CharacterManager spawnCustomizableAvatar(ref GameObject character_gameobject, string character_id, string character_name)
    {
        ConfigHPActorInfo._HPActorInfo character = null;
        Dictionary<string, Transform> parent_bones = null;

        character = Configs.config_hp_actor_info.HPActorInfo[character_id];

        parent_bones = ModelManager.loadModel(ref character_gameobject, character.modelId, "c3b");


        Debug.Log("spawning avatar");
        character_gameobject.name = character_name;

        CharacterManager c = character_gameobject.AddComponent<CharacterManager>();
        c.actor_info = character;
        c.animId_idle = character.animId_idle;
        c.patches = new List<GameObject>();
        c.model_name = character.modelId;
        c.parent_bones = parent_bones;
        c.bone_mods = new Dictionary<string, AnimationManager.BoneMod>();

        if (character_gameobject != null)
        {
            character_gameobject.name = character_name;

            c.gameObject.AddComponent<Animation>();
        }

        c.replaceCharacterIdleNoDelay(c.actor_info.animId_idle);
        c.setCharacterIdle();
        return c;
    }
}
