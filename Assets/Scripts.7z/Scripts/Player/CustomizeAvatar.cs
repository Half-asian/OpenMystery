using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

public class CustomizeAvatar : MonoBehaviour
{
    private CharacterManager customizable_avatar;
    private Dictionary<string, Transform> customizable_avatar_modifiable_bones;
    private Dictionary<string, Transform> customizable_avatar_modified_bones;
    [SerializeField]
    GameObject _camera;
    AvatarComponents avatar_components;
    Animation character_animation;
    SkinnedMeshRenderer unmodified_smr;
    float prev_x;
    float prev_y;
    float prev_z;

    void Awake()
    {
        avatar_components = new AvatarComponents(GlobalEngineVariables.player_folder + "\\avatar.json");

        _camera.transform.position = new Vector3(0, 0.773000002f, 0.338999987f);
        _camera.transform.rotation = Quaternion.Euler(new Vector3(0, 180, 0));


        GameObject avatar_gameobject = null;
        customizable_avatar =  CustomizableAvatarSpawner.spawnCustomizableAvatar(ref avatar_gameobject, avatar_components.actor_id, "CustomizableAvatar");

        unmodified_smr = customizable_avatar.transform.Find("null").GetComponent<SkinnedMeshRenderer>();
        customizable_avatar.gameObject.transform.position = Vector3.zero;
        customizable_avatar.gameObject.transform.rotation = Quaternion.identity;
        customizable_avatar_modifiable_bones = new Dictionary<string, Transform>();
        customizable_avatar_modified_bones = new Dictionary<string, Transform>();

        avatar_components.setCharacterManager(customizable_avatar);
        avatar_components.spawnComponents("c_Avatar_Male_headNoseless_skin");
        avatar_components.base_component.transform.parent = avatar_gameobject.transform;
        character_animation = avatar_components.character.GetComponent<Animation>();


        foreach (string bonemod in BonemodMap.bonemod_map.Keys)
        {
            customizable_avatar_modifiable_bones[bonemod] = customizable_avatar.gameObject.transform.Find(BonemodMap.bonemod_map[bonemod]);
            customizable_avatar_modified_bones[bonemod] = avatar_components.base_bones[bonemod];
        }

        //GameObject static_avatar_gameobject = null;
        //StaticAvatarSpawner.spawnStaticAvatar(ref static_avatar_gameobject);

    }

    private void Update()
    {
        foreach(string bone in customizable_avatar.parent_bones.Keys)
        {
            avatar_components.base_bones[bone].transform.position = customizable_avatar.parent_bones[bone].position;
            avatar_components.base_bones[bone].transform.rotation = customizable_avatar.parent_bones[bone].rotation;
            avatar_components.base_bones[bone].transform.localScale = customizable_avatar.parent_bones[bone].localScale;
        }

        if (avatar_components != null)
        {
            foreach (string bone_mod in avatar_components.bonemods.Keys)
            {
                customizable_avatar_modified_bones[bone_mod].transform.position = customizable_avatar_modifiable_bones[bone_mod].position + avatar_components.bonemods[bone_mod].translation;
                customizable_avatar_modified_bones[bone_mod].transform.rotation = customizable_avatar_modifiable_bones[bone_mod].rotation * avatar_components.bonemods[bone_mod].rotation;
                Vector3 new_scale = customizable_avatar_modifiable_bones[bone_mod].localScale;
                new_scale.x *= avatar_components.bonemods[bone_mod].scale.x;
                new_scale.y *= avatar_components.bonemods[bone_mod].scale.y;
                new_scale.z *= avatar_components.bonemods[bone_mod].scale.z;
                customizable_avatar_modified_bones[bone_mod].transform.localScale = new_scale;
            }
        }

    }

    public void saveAvatarButtonPressed()
    {
        avatar_components.commitChanges();
        string json_file = PlayerManager.current.serializeToJson();
        File.WriteAllText(GlobalEngineVariables.player_folder + "\\avatar.json", json_file);
    }

    public void resetChangesButtonPressed()
    {
        avatar_components.undoChanges();
    }

    public void changeAvatarBrowThickness(float browThickness) { avatar_components.changeAvatarBrowThickness(browThickness); }
    public void changeAvatarEyeCloseness(float eyeCloseness) { avatar_components.changeAvatarEyeCloseness(eyeCloseness); }
    public void changeAvatarEyeSize(float eyeSize) { avatar_components.changeAvatarEyeSize(eyeSize); }
    public void changeAvatarEyeY(float eyeY) { avatar_components.changeAvatarEyeY(eyeY); }
    public void changeAvatarChinSize(float chinSize) { avatar_components.changeAvatarChinSize(chinSize); }
    public void changeAvatarJawSize(float jawSize) { avatar_components.changeAvatarJawSize(jawSize); }
    public void changeAvatarNoseBridgeHeight(float noseBridgeHeight) { avatar_components.changeAvatarNoseBridgeHeight(noseBridgeHeight); }
    public void changeAvatarNoseBridgeLength(float noseBridgeLength) { avatar_components.changeAvatarNoseBridgeLength(noseBridgeLength); }
    public void changeAvatarNoseBridgeWidth(float noseBridgeWidth) { avatar_components.changeAvatarNoseBridgeWidth(noseBridgeWidth); }
    public void changeAvatarNoseFatness(float noseFatness) { avatar_components.changeAvatarNoseFatness(noseFatness); }
    public void changeAvatarNoseWidth(float noseWidth) { avatar_components.changeAvatarNoseWidth(noseWidth); }
    public void changeAvatarNoseLength(float noseLength) { avatar_components.changeAvatarNoseLength(noseLength); }
    public void changeAvatarNoseHeight(float noseHeight) { avatar_components.changeAvatarNoseHeight(noseHeight); }
    public void changeAvatarNoseTwist(float noseTwist) { avatar_components.changeAvatarNoseTwist(noseTwist); }

}
