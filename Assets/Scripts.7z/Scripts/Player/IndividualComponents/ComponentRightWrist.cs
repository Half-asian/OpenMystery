﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace IndividualComponents
{
    class ComponentRightWrist : IAvatarComponent
    {
        private GameObject component_gameobject;

        AvatarComponents avatar_components;

        public ComponentRightWrist(AvatarComponents _avatar_components)
        {
            avatar_components = _avatar_components;
            replaceComponent();
        }

        public void setFloat(float f, string s)
        {
            throw new System.NotImplementedException();
        }

        public void setInt(int i, string s)
        {
            throw new System.NotImplementedException();
        }

        public GameObject replaceComponent()
        {
            PlayerFile.CustomizationCategory category = avatar_components.customization_categories["rightWrist"];
            string outfit_id = Configs.config_avatar_components.AvatarComponents[category.component_id].outfitId;
            string model_id = Configs.config_avatar_outfit_data.AvatarOutfitData[outfit_id].modelid;
            GameObject.Destroy(component_gameobject);
            GameObject new_gameobject = null;
            ModelManager.loadModel(ref new_gameobject, model_id, "c3b", avatar_components.base_bones);
            component_gameobject = new_gameobject;
            component_gameobject.transform.parent = avatar_components.base_component.transform;
            return component_gameobject;
        }
        public GameObject getGameObject()
        {
            return component_gameobject;
        }
    }
}
