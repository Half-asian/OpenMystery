﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace IndividualComponents
{
    class ComponentHair : IAvatarComponent
    {
        private GameObject component_gameobject;

        AvatarComponents avatar_components;

        public ComponentHair(AvatarComponents _avatar_components)
        {
            avatar_components = _avatar_components;
            replaceComponent();
            setModifiers();
        }

        public void setFloat(float f, string s) {
            throw new System.NotImplementedException();
        }

        public void setInt(int i, string s)
        {
            throw new System.NotImplementedException();
        }
        public GameObject replaceComponent()
        {
            PlayerFile.CustomizationCategory category = avatar_components.customization_categories["hair"];
            string model_id = Configs.config_avatar_components.AvatarComponents[category.component_id].patchModelId;
            GameObject.Destroy(component_gameobject);
            GameObject new_gameobject = null;
            ModelManager.loadModel(ref new_gameobject, model_id, "c3b", avatar_components.base_bones);
            component_gameobject = new_gameobject;
            component_gameobject.transform.parent = avatar_components.base_component.transform;
            return component_gameobject;
        }

        public void setModifiers()
        {
            PlayerFile.CustomizationCategory category = avatar_components.customization_categories["hair"];

            if (category.int_parameters.ContainsKey("hairColor"))
            {
                int hair_color_id = category.int_parameters["hairColor"];

                int[] hair_color_codes = Configs.config_avatar_attribute_colors.AvatarAttributeColors["hairColor"].colorConfigs[hair_color_id].codes;

                Color c = new Color(hair_color_codes[0] / 255.0f, hair_color_codes[1] / 255.0f, hair_color_codes[2] / 255.0f, 1.0f);
                SkinnedMeshRenderer smr = component_gameobject.GetComponentInChildren<SkinnedMeshRenderer>();
                smr.material.SetColor("u_hairColor", c);
            }
        }

        public GameObject getGameObject()
        {
            return component_gameobject;
        }
    }
}
