﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace IndividualComponents
{
    class ComponentArms : IAvatarComponent
    {
        private GameObject component_gameobject;

        AvatarComponents avatar_components;

        string component_id;

        public ComponentArms(AvatarComponents _avatar_components, string _component_id)
        {
            component_id = _component_id;
            avatar_components = _avatar_components;
            replaceComponent();
            setModifiers();
        }
        public void setFloat(float f, string s)
        {
            throw new System.NotImplementedException();
        }
        public void setInt(int i, string s)
        {
            throw new System.NotImplementedException();
        }

        public GameObject replaceComponent()
        {
            Debug.Log(component_id);
            if (component_id == "LongSleeve")
                component_id = "ForeArm";

            ConfigAvatarPatchConfig._AvatarPatchConfig patch = Configs.config_avatar_patch_config.AvatarPatchConfig[component_id];
            string model_id;
            if (avatar_components.gender == "male")
                 model_id = patch.maleModelId;
            else
                model_id = patch.femaleModelId;

            GameObject.Destroy(component_gameobject);
            GameObject new_gameobject = null;
            ModelManager.loadModel(ref new_gameobject, model_id, "c3b", avatar_components.base_bones);
            component_gameobject = new_gameobject;
            component_gameobject.transform.parent = avatar_components.base_component.transform;
            return component_gameobject;
        }

        public void setModifiers()
        {
            if (avatar_components.customization_categories["faces"].int_parameters.ContainsKey("skinColor"))
            {
                int skin_color_id = avatar_components.customization_categories["faces"].int_parameters["skinColor"];
                int[] skin_color_codes = Configs.config_avatar_attribute_colors.AvatarAttributeColors["skinColor"].colorConfigs[skin_color_id].codes;
                Color c = new Color(skin_color_codes[0] / 255.0f, skin_color_codes[1] / 255.0f, skin_color_codes[2] / 255.0f, 1.0f);
                SkinnedMeshRenderer smr = component_gameobject.GetComponentInChildren<SkinnedMeshRenderer>();
                smr.material.SetColor("u_skinColor", c);
            }
        }

        public GameObject getGameObject()
        {
            return component_gameobject;
        }
    }
}
