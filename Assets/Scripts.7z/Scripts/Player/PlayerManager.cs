﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using Newtonsoft.Json;
using System.IO;


[System.Serializable]
public class PlayerManager
{

    public static PlayerFile current;
    public static void initialise()
    {
        current = PlayerFile.createFromJson(GlobalEngineVariables.player_folder + "\\avatar.json");
        Debug.Log(current.gender != null);
        Debug.Log(current.character_id != null);
        Debug.Log(current.customization_categories != null);
    }

}