using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Assertions;

public class GoalChain
{
    public ConfigGoalChain._GoalChain goal_chain { get; protected set; }
    List<List<string>> goals = new List<List<string>>();
    Goal current_goal = null;

    public GoalChain(ConfigGoalChain._GoalChain _goal_chain) //Real goalchain from the configs
    {
        Assert.IsNotNull(_goal_chain, "GoalChain(): goal_chain cannot be null.");
        goal_chain = _goal_chain;
        Assert.IsNotNull(goal_chain.goalIds, "GoalChain(): goal_chain.goalIds cannot be null.");
        foreach(List<string> goal in goal_chain.goalIds)
        {
            goals.Add(goal);
        }
        getNewGoal();
    }

    public GoalChain(ConfigGoalChain._GoalChain _goal_chain, int _goal_index) //Goalchain starting from a specific goal
    {
        Assert.IsNotNull(_goal_chain, "GoalChain(): goal_chain cannot be null.");
        goal_chain = _goal_chain;
        Assert.IsNotNull(goal_chain.goalIds, "GoalChain(): goal_chain.goalIds cannot be null.");

        if (goal_chain.classGoalIds != null)
        {
            for (int i = _goal_index; i < goal_chain.goalIds.Count + goal_chain.classGoalIds.Count; i++)
            {
                if (i < goal_chain.goalIds.Count)
                    goals.Add(goal_chain.goalIds[i]);
                else
                {
                    List<string> new_goal_string = new List<string>();
                    new_goal_string.Add(goal_chain.classGoalIds[i - goal_chain.goalIds.Count]);
                    goals.Add(new_goal_string);
                }
            }
        }
        else
        {
            for (int i = _goal_index; i < goal_chain.goalIds.Count; i++)
            {
                if (i < goal_chain.goalIds.Count)
                    goals.Add(goal_chain.goalIds[i]);
            }
        }
        getNewGoal();
    }
    public Goal getCurrentGoal()
    {
        if (goals.Count > 0) return current_goal; //ADD PREDICATE CHECK
        return null;
    }


    public string getScenario()
    {
        return current_goal.getScenario();
    }
    public ConfigObjective.Objective getCurrentObjective()
    {
        return current_goal.getObjective();
    }

    public List<Objective> getObjectives()
    {
        return current_goal.getObjectives();
    }

    public void goalComplete(Goal goal)
    {
        goals.RemoveAt(0);
        Goal old_goal = goal;
        GameStart.dungeon_master.goalComplete(old_goal);
        if (goals.Count == 0)
            GameStart.dungeon_master.goalChainComplete(this);
        else
        {
            getNewGoal();
            GameStart.dungeon_master.goalPopup();
        }
    }

    public void getNewGoal()
    {
        ConfigGoal.Goal goal = null;
        int counter = 0;
        bool pass_predicate;
        do
        {
            goal = Configs.config_goal.Goals[goals[0][counter]];
            if (goal.predicate == null) pass_predicate = true;
            else
            {
                pass_predicate = Predicate.parsePredicate(goal.predicate);
            }
            counter++;
        }
        while (pass_predicate == false && counter < goals[0].Count);
        if (!pass_predicate)
        {
            //throw new System.Exception("No goal found that passes predicates");
            Debug.LogWarning("No goal found that passes predicates");
            goal = Configs.config_goal.Goals[goals[0][0]];

        }
        current_goal = new Goal(goal, this);
    }
}
public class Goal
{
    GoalChain parent_goalchain;
    public ConfigGoal.Goal goal { get; protected set; }
    List<Objective> objectives = new List<Objective>();
    public Goal(ConfigGoal.Goal _goal, GoalChain _parent_goalchain)
    {
        Assert.IsNotNull(_goal, "Goal(): goal cannot be null.");
        goal = _goal;
        parent_goalchain = _parent_goalchain;
        Assert.IsNotNull(goal.required_steps, "Goal(): goal.required_steps cannot be null.");
        foreach(string required_step in goal.required_steps)
        {
            if (Configs.config_objective.Objectives.ContainsKey(required_step))
            {
                Objective new_obj = getNewObjectiveFromConfigObjective(Configs.config_objective.Objectives[required_step]);
                if (new_obj.should_remove == false)
                    objectives.Add(new_obj);
            }
        }

    }

    public void removeObjective(Objective objective)
    {
        Debug.Log("removing objective " + objective.objective.objective_id);
        objectives.Remove(objective);
        if (objectives.Count == 0)
        {
            Debug.Log("Goal completed " + goal.goal_id);
            parent_goalchain.goalComplete(this);
        }
    }

    public Objective getNewObjectiveFromConfigObjective(ConfigObjective.Objective objective)
    {
        Assert.IsNotNull(objective, "getNewObjectiveFromConfigObjective(): objective cannot be null");
        Assert.IsNotNull(objective.message, "getNewObjectiveFromConfigObjective(): objective.message cannot be null");
        switch (objective.message)
        {
            case "interactionComplete":
                return new ObjectiveInteractionComplete(objective, this);
            case "dialogueComplete":
                return new ObjectiveDialogueComplete(objective, this);
            case "matchComplete":
                return new ObjectiveMatchComplete(objective, this);
            case "repeatableMatchComplete":
                return new ObjectiveRepeatableMatchComplete(objective, this);
            default:
                throw new System.Exception("Objective type not implemented " + objective.message);
        }
    }

    public string getScenario()
    {
        return objectives[0].getScenario();
    }
    public ConfigObjective.Objective getObjective()
    {
        return objectives[0].objective;
    }
    
    public List<Objective> getObjectives()
    {
        return objectives;
    }
}
public abstract class Objective
{
    public ConfigObjective.Objective objective { get; protected set; }
    public Goal parent_goal { get; protected set; }
    protected int keys_completed = 0;
    protected List<string> keys;
    public bool should_remove = false;

    protected void ObjectiveCompleted()
    {
        Debug.Log("Objective completed: " + objective.objective_id);
        parent_goal.removeObjective(this);
        GameStart.objective_cleanup.Add(this);
    }

    public abstract string getScenario();
    public abstract void cleanup();
}
public class ObjectiveInteractionComplete : Objective
{
    public ObjectiveInteractionComplete(ConfigObjective.Objective _objective, Goal _parent_goal)
    {
        Assert.IsNotNull(_objective, "ObjectiveInteractionComplete(): objective cannot be null.");
        objective = _objective;
        parent_goal = _parent_goal;
        Assert.IsTrue(objective.message == "interactionComplete");
        Assert.IsNotNull(objective.keys, "ObjectiveInteractionComplete(): objective.keys cannot be null.");
        Assert.IsNotNull(objective.objectiveScenario, "ObjectiveInteractionComplete(): objective.objectiveScenario cannot be null");
        keys = new List<string>(objective.keys);
        GameStart.interaction_manager.objective_callbacks.Add(this);
    }

    public void interactionFinishedCheck(string interaction_id)
    {
        if (keys.Contains(interaction_id))
        {
            keys.Remove(interaction_id);
            keys_completed++;
        }
        if (keys_completed >= objective.required_count)
            ObjectiveCompleted();
    }

    public override string getScenario()
    {
        return objective.objectiveScenario;
    }

    public override void cleanup()
    {
        GameStart.interaction_manager.objective_callbacks.Remove(this);
    }
}
public class ObjectiveDialogueComplete : Objective, DialogueCallback
{
    public ObjectiveDialogueComplete(ConfigObjective.Objective _objective, Goal _parent_goal)
    {
        Assert.IsNotNull(_objective, "ObjectiveDialogueComplete(): objective cannot be null.");
        objective = _objective;
        parent_goal = _parent_goal;
        Assert.IsTrue(objective.message == "dialogueComplete");
        Assert.IsNotNull(objective.keys, "ObjectiveDialogueComplete(): objective.keys cannot be null.");
        keys = new List<string>(objective.keys);
        GameStart.dialogue_manager.onDialogueFinishedEvent += dialogueCallback;
    }

    public void dialogueCallback(string dialogue_id)
    {
        if (keys.Contains(dialogue_id))
        {
            keys.Remove(dialogue_id);
            keys_completed++;
        }
        if (keys_completed >= objective.required_count)
        {
            GameStart.dialogue_manager.onDialogueFinishedEvent -= dialogueCallback;
            ObjectiveCompleted();
        }
    }

    public override string getScenario()
    {
        return objective.objectiveScenario;
    }

    public override void cleanup()
    {
        //GameStart.dialogue_manager.onDialogueFinishedEvent += dialogueCallback;
    }
}
public class ObjectiveMatchComplete : Objective
{
    public ObjectiveMatchComplete(ConfigObjective.Objective _objective, Goal _parent_goal)
    {
        Assert.IsNotNull(_objective, "ObjectiveMatchComplete(): objective cannot be null.");
        objective = _objective;
        parent_goal = _parent_goal;
        Assert.IsTrue(objective.message == "matchComplete");
        Assert.IsNotNull(objective.keys, "ObjectiveMatchComplete(): objective.keys cannot be null.");
        Assert.IsNotNull(objective.objectiveScenario, "ObjectiveMatchComplete(): objective.objectiveScenario cannot be null");
        keys = new List<string>(objective.keys);
        GameStart.quidditch_manager.objective_callbacks.Add(this);
    }

    public void quidditchMatchFinishedCheck(string match_id)
    {
        Debug.Log("quidditchMatchFinishedCheck");
        if (keys.Contains(match_id))
        {
            keys.Remove(match_id);
            keys_completed++;
        }
        if (keys_completed >= objective.required_count)
            ObjectiveCompleted();
    }

    public override string getScenario()
    {
        return objective.objectiveScenario;
    }

    public override void cleanup()
    {
        GameStart.quidditch_manager.objective_callbacks.Remove(this);
    }
}
public class ObjectiveRepeatableMatchComplete : Objective
{
    public ObjectiveRepeatableMatchComplete(ConfigObjective.Objective _objective, Goal _parent_goal)
    {
        Assert.IsNotNull(_objective, "ObjectiveMatchComplete(): objective cannot be null.");
        objective = _objective;
        parent_goal = _parent_goal;
        Assert.IsTrue(objective.message == "repeatableMatchComplete");
        should_remove = true;
    }

    public override string getScenario()
    {
        throw new System.Exception("tried to get scenario from ObjectiveRepeatableMatchComplete");
    }

    public override void cleanup() { return; }
}