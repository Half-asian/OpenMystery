﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.IO;
using Newtonsoft.Json;

//This script handles the overarching quest system. It decides what scenarios to start and tracks the players goals and objectives.
public class DungeonMaster {

    public void startGoalChain(string goal_chain)
    {
        if (GameStart.game_state == null)
            GameStart.game_state = new GameState();
        if (!Configs.config_goal_chain.GoalChain.ContainsKey(goal_chain)){
            Log.writeFull("startGoalChain: Invalid GoalChain " + goal_chain);
            throw new System.Exception("startGoalChain: Invalid GoalChain " + goal_chain);
        }

        GameStart.game_state.goal_chain = new GoalChain(Configs.config_goal_chain.GoalChain[goal_chain]);
    }
    public void startGoal(string goal_chain_id, int goal_index)
    {
        if (GameStart.game_state == null)
            GameStart.game_state = new GameState();
        
        if (!Configs.config_goal_chain.GoalChain.ContainsKey(goal_chain_id))
        {
            Log.writeFull("startGoalChain: Invalid GoalChain " + goal_chain_id);
            throw new System.Exception("startGoalChain: Invalid GoalChain " + goal_chain_id);
        }


        GameStart.game_state.goal_chain = new GoalChain(Configs.config_goal_chain.GoalChain[goal_chain_id], goal_index);
    }
    public void goalChainComplete(GoalChain goalchain)
    {
        Debug.Log("Finished Goal Chain");

        if (!File.ReadAllText("save\\goalchains_complete.txt").Contains("goalChainComplete(\"" + goalchain.goal_chain.id + "\")"))
        {
            StreamWriter writer = new StreamWriter("save\\goalchains_complete.txt", true);
            writer.WriteLine("goalChainComplete(\"" + goalchain.goal_chain.id + "\")");
            writer.Close();
        }

        destroyInteractions();
        GameStart.ui_manager.next_area_button.SetActive(false);
        GameStart.ui_manager.exit_to_menu_button.SetActive(true);
    }
    public void goalComplete(Goal goal)
    {
        if (!File.ReadAllText("save\\goals_complete.txt").Contains("isGoalComplete(\"" + goal.goal.goal_id + "\")"))
        {
            StreamWriter writer = new StreamWriter("save\\goals_complete.txt", true);
            writer.WriteLine("isGoalComplete(\"" + goal.goal.goal_id + "\")");
            writer.Close();
        }

        destroyInteractions();

        
    }

    public void goalPopup()
    {
        if (GameStart.ui_manager.exit_to_menu_button.activeSelf == false)
        {
            if (GameStart.game_state.goal_chain.getCurrentGoal() != null)
            {
                GameStart.ui_manager.showPopup(GameStart.game_state.goal_chain.getCurrentGoal().goal.goal_id);

                //GameStart.ui_manager.next_area_title.text = Configs.config_local_data.LocalData[GameStart.game_state.goal_chain.getCurrentGoal().goal.goal_name].en_US;
                //GameStart.ui_manager.next_area_desc.text = Configs.config_local_data.LocalData[GameStart.game_state.goal_chain.getCurrentGoal().goal.ready_text].en_US;
            }
            /*else {
                GameStart.ui_manager.next_area_title.text = "finished";
                GameStart.ui_manager.next_area_desc.text = "finished";
            }*/

            GameStart.ui_manager.next_area_button.SetActive(true);

        }
    }

    public void activateScenarioFromCurrentObjective()
    {
        ConfigObjective.Objective current_objective = GameStart.game_state.goal_chain.getCurrentObjective();
        if (current_objective.objectiveScenario != null)
        {
            GameStart.activateScenario(current_objective.objectiveScenario);
        }
        else if (current_objective.objectiveHubNpcs != null)
        {
            if (current_objective.objectiveHubNpcs.Length != 1)
            {
                Debug.Log("DungeonMaster:getScenarioFromCurrentObjective - More than 1 objectiveHubNPC!");
            }
            ConfigHubNPC._HubNPC first_npc = Configs.config_hub_npc.HubNPC[current_objective.objectiveHubNpcs[0]];
            GameStart.activateScenario(first_npc.hubId);
        }
        else
        {
            Debug.LogError("DungeonMaster:getScenarioFromCurrentObjective - Unknown what to do with this objective!");

            if (current_objective.objective_id == "Y1_C1_P6Obj1")
            {
                GameStart.activateScenario("NUX_TrainScene");
            }
        }
    }
    public void nextArea()
    {
        GameStart.ui_manager.next_area_button.SetActive(false);
        
        activateScenarioFromCurrentObjective();
    }
    public void exitToMenu()
    {
        GameStart.ui_manager.exit_to_menu_button.SetActive(false);
        GameObject.Find("GameManager").GetComponent<GameStart>().cleanUp();
        GameStart.ui_manager.pause_menu.SetActive(false);
        GameStart.ui_manager.main_menu.SetActive(true);
    }
    public void destroyInteractions()
    {
        foreach (GameObject g in GameObject.FindGameObjectsWithTag("hud_dialog"))
        {
            GameObject.Destroy(g);
        }

        foreach (GameObject g in GameObject.FindGameObjectsWithTag("hud_important"))
        {
            GameObject.Destroy(g);
        }
    }
}