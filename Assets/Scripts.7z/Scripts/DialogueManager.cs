﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.IO;
using Newtonsoft.Json;
using UnityEngine.Networking;
using System.Text.RegularExpressions;
using System;

public interface DialogueCallback
{
    public abstract void dialogueCallback(string dialogue);
}

public class DialogueManager : MonoBehaviour
{
    GameStart game_start;
    EventManager event_manager;
    DungeonMaster dungeon_master;

    //public List<DialogueCallback> callbacks = new List<DialogueCallback>();
    public event Action<string> onDialogueFinishedEvent;

    public GameObject BGMusicPlayer;
    public GameObject AMBAudioPlayer;

    public GameObject ui_dialogue;
    public Text ui_dialogue_name;
    public Text ui_dialogue_text;
    public GameObject ui_dialogue_choice_1;
    public string dialogue_choice_1_next_dialogue;
    public GameObject ui_dialogue_choice_2;
    public string dialogue_choice_2_next_dialogue;
    public GameObject ui_dialogue_choice_3;
    public string dialogue_choice_3_next_dialogue;
    public List<string> choices;
    ConfigHPDialogueLine.HPDialogueLine current_dialogue;
    public string next_dialogue;
    public bool waiting_for_dialogue = false;
    public static string local_avatar_first_name;
    public static string local_avatar_last_name;
    public static string local_avatar_full_name;
    public static string local_avatar_house;
    public static string local_avatar_gender;
    public static string local_avatar_quidditch_position = "chaser";
    public static string local_avatar_clothing_type;
    public static string local_avatar_secondary_lothing_option;
    public static string local_avatar_opponent_house;
    public static string local_avatar_onscreen_name;
    public static int local_avatar_year = 5;
    public bool in_dialogue;
    public bool in_bubble;

    public List<string> madeChoice;

    public List<string> entry_stack = new List<string>();

    public List<string> exit_stack = new List<string>();

    public string text_holder;
    public string name_holder;
    public string next_text_holder;
    public string next_name_holder;

    const float letter_seperator = 0.02f;
    public float start_dialogue_time;

    public DialogueStatus dialogue_status = DialogueStatus.Finished;

    public string[] camera_params;
    public enum DialogueStatus
    {
        WaitingEnterEvents,
        WaitingPlayerConfirm,
        WaitingPlayerOptionSelect,
        WaitingExitEvents,
        Finished
    }

    public void Start()
    {
        game_start = GetComponent<GameStart>();
        event_manager = GetComponent<EventManager>();
        dungeon_master = new DungeonMaster();
    }

    public void resetCamera()
    {
        CameraManager.resetCamera();
        /*if (main_camera_holder.GetComponent<Animation>() != null)
        {
            Destroy(main_camera_holder.GetComponent<Animation>());
        }*/
    }
    

    public void showBubbleDialogue(string speaker, string dialogue)
    {
        if (speaker == "Avatar")
        {
            speaker = "You";
        }
        else
        {
            speaker = mapName(speaker);
        }

        ui_dialogue.SetActive(true);
        name_holder = speaker;

        text_holder = getLocalDataLine(dialogue);

        ui_dialogue_name.text = "";
        ui_dialogue_text.text = "";
        start_dialogue_time = Time.realtimeSinceStartup;
    }

    public void finishBubbleDialogue()
    {
        in_bubble = false;
        ui_dialogue.SetActive(false);
    }

    IEnumerator PlayAudioFile(string filename, string type)
    {
        if (filename == "none" && type == "amb")
        {
            AMBAudioPlayer.GetComponent<AudioSource>().Stop();
            yield break;
        }

        if (type == "bgaudio"){
            if (BGMusicPlayer.GetComponent<AudioSource>().clip != null)
            {
                if (BGMusicPlayer.GetComponent<AudioSource>().clip.name == filename)
                {
                    yield break;
                }

            }
        }

        UnityWebRequest www;
        if (filename.Contains(".wav"))
        {
            www = UnityWebRequestMultimedia.GetAudioClip("file://" + filename, AudioType.WAV);
        }
        else
        {
            www = UnityWebRequestMultimedia.GetAudioClip("file://" + filename, AudioType.MPEG);
        }
        yield return www.SendWebRequest();
        if (www.result == UnityWebRequest.Result.ConnectionError)
        {
            Log.writeFull(www.error, "error");
            throw new System.Exception(www.error);
        }
        else
        {
            AudioClip myClip = DownloadHandlerAudioClip.GetContent(www);

            if (type == "bark")
            {
                CameraManager.main_camera.GetComponent<AudioSource>().PlayOneShot(myClip);
            }
            else if (type == "bgaudio")
            {
                myClip.name = filename;
                BGMusicPlayer.GetComponent<AudioSource>().clip = myClip;

                BGMusicPlayer.GetComponent<AudioSource>().Play();
            }
            else if (type == "amb")
            {
                AMBAudioPlayer.GetComponent<AudioSource>().clip = myClip;
                AMBAudioPlayer.GetComponent<AudioSource>().Play();
            }
        }
    }

    public void playAudioFile(string filename, string type)
    {
        Debug.Log("playing audio file " + filename);
        if (File.Exists(GlobalEngineVariables.assets_folder + "\\sounds\\" + filename) || filename == "none")
        {
            StartCoroutine(PlayAudioFile(GlobalEngineVariables.assets_folder + "\\sounds\\" + filename, type));
        }
        else
        {
            if (!File.ReadAllText("missing_assets.txt").Contains("Couldn't find " + GlobalEngineVariables.assets_folder + "\\sounds\\" + filename))
            {
                StreamWriter writer = new StreamWriter("missing_assets.txt", true);
                writer.WriteLine("Couldn't find " + GlobalEngineVariables.assets_folder + "\\sounds\\" + filename);
                writer.Close();
            }
        }
    }

    public bool activateNewDialogue(string dialogue)
    {
        Debug.Log("activateNewDialogue " + dialogue);

        string dialogue_line = null;

        if (Configs.dialogue_dict.ContainsKey(dialogue))
        {
            foreach (ConfigHPDialogueLine.HPDialogueLine i in Configs.dialogue_dict[dialogue])
            {
                if (i.initialTurn == true)
                {
                    dialogue_line = i.id;
                    break; //There can be multiple. Take the first one.
                }
            }
            if (dialogue_line == null)
            {
                dialogue_line = Configs.dialogue_dict[dialogue][0].id; //No initial turn? Thats fine. Take the first match.
            }
        }
        else
        {
            Debug.LogError("DialogueManager:activateNewDialogue - Config empty for dialogue " + dialogue + " in HPDialogueLines");
            return false;
        }

        if (dialogue_line == null)
        {
            throw new System.Exception("DialogueManager:activateNewDialogue - Config empty for dialogue " + dialogue + " in HPDialogueLines");
            // return false;
            //dialogue_line = dialogue + "1";

        }


        return activateDialogue(dialogue_line);
    }
    public bool activateDialogue(string dialogue_name)
    {
        in_bubble = false;

        if (dialogue_name == null)
        {
            Debug.LogError("activateDialogue name was null");
            return true;
        }
        
        Log.writeFull("activated dialogue " + dialogue_name);




        dialogue_status = DialogueStatus.WaitingEnterEvents;

        in_dialogue = true;
        ConfigHPDialogueLine.HPDialogueLine dialogue = null;
        if (!Configs.config_hp_dialogue_line.HPDialogueLines.ContainsKey(dialogue_name))
        {

            foreach (string dialogue_key in Configs.config_hp_dialogue_line.HPDialogueLines.Keys)
            {
                if (Configs.config_hp_dialogue_line.HPDialogueLines[dialogue_key].dialogue == dialogue_name)
                {
                    dialogue = Configs.config_hp_dialogue_line.HPDialogueLines[dialogue_key];
                    break;
                }
            }
        }
        else
        {
            dialogue = Configs.config_hp_dialogue_line.HPDialogueLines[dialogue_name];
        }

        if (dialogue == null)
        {
            Debug.Log(dialogue_name + " was not in the dialogue dictionary");
            return false;
        }

        if (Configs.dialogue_line_override_dict.ContainsKey(dialogue.id))
        {
            foreach(ConfigHPDialogueOverride._HPDialogueOverride override_line in Configs.dialogue_line_override_dict[dialogue.id])
            {
                if (override_line.companionId == GameStart.game_state.companionId)
                {
                    Log.writeFull("Overriding dialogue " + dialogue.id + " with " + override_line.id);
                    override_line.overrideLine(dialogue);
                }
            }
        }




        current_dialogue = dialogue;

        if (dialogue.emoteResetEvents != null)
        {
            foreach (string emote_reset_event in dialogue.emoteResetEvents) {
                event_manager.event_stack.Add(emote_reset_event);
            }
        }

        if (dialogue.emoteEvents != null)
        {
            foreach (string emote_event in dialogue.emoteEvents)
            {
                event_manager.event_stack.Add(emote_event);
            }
        }

        if (dialogue.barkPlaylistIds != null)
        {
            if (dialogue.barkPredicates != null)
            {
                bool played = false;
                for (int i = 0; i < dialogue.barkPlaylistIds.Length; i++)
                {
                    if (i < dialogue.barkPredicates.Length)
                    {

                        if (Predicate.parsePredicate(dialogue.barkPredicates[i]))
                        {
                            if (Configs.playlist_dict.ContainsKey(dialogue.barkPlaylistIds[i]))
                            {
                                Debug.Log(dialogue.barkPlaylistIds[i]);
                                played = true;
                                playAudioFile(Configs.playlist_dict[dialogue.barkPlaylistIds[i]].files[0], "bark");
                            }
                        }
                    }
                    else
                    {
                        if (played == false)
                        {
                            if (Configs.playlist_dict.ContainsKey(dialogue.barkPlaylistIds[i]))
                            {
                                played = true;
                                Debug.Log(dialogue.barkPlaylistIds[i]);
                                playAudioFile(Configs.playlist_dict[dialogue.barkPlaylistIds[i]].files[0], "bark");
                            }
                        }
                    }
                }
            }
            else
            {
                if (Configs.playlist_dict.ContainsKey(dialogue.barkPlaylistIds[0]))
                {
                    playAudioFile(Configs.playlist_dict[dialogue.barkPlaylistIds[0]].files[0], "bark");
                }
            }
        }

        if (dialogue.lookAt != null)
        {
            for (int i = 0; i < dialogue.lookAt.Length; i++)
            {
                string[] action_params = dialogue.lookAt[i].Split(':');

                if (dialogue.headOnly != null && dialogue.headOnly.Length > i)
                {
                    if (dialogue.headOnly[i] == "true") {
                        GetComponent<EventManager>().turnHeadAt(action_params);
                    }
                    else if (dialogue.headOnly[i] == "false")
                    {
                        GetComponent<EventManager>().lookAt(action_params);
                    }
                    else
                    {
                        Debug.LogError("Unknown headOnly parameter in dialogue: " + dialogue.headOnly[i]);
                    }
                }
                else {
                    GetComponent<EventManager>().lookAt(action_params);
                }
            }
        }

        if (dialogue.speakerId == "Avatar")
        {
            next_name_holder = "You";
        }
        else if (dialogue.speakerId != null)
        {
            next_name_holder = mapName(dialogue.speakerId);
        }
        if (dialogue.token != null)
        {
            if (!Configs.config_local_data.LocalData.ContainsKey(dialogue.token))
            {
                Debug.Log("Couldn't find dialogue " + dialogue.token);
                next_text_holder = "error";
            }
            else
            {
                string text;
                if (Configs.config_local_data.LocalData.ContainsKey(dialogue.token + "+female") && local_avatar_gender == "female")
                {
                    text = getLocalDataLine(dialogue.token + "+female");
                }
                else
                {
                    text = getLocalDataLine(dialogue.token);
                }
                next_text_holder = text;
            }
        }
        else
        {
            next_text_holder = null;
        }

        if (dialogue.dialogueChoiceIds == null)
        {
            if (dialogue.nextTurnIds != null)
            {
                //Check predicates
                if (dialogue.nextTurnPredicates != null)
                {
                    for (int p = 0; p < dialogue.nextTurnPredicates.Length; p++)
                    {
                        if (Predicate.parsePredicate(dialogue.nextTurnPredicates[p]))
                        {
                            next_dialogue = dialogue.nextTurnIds[p];
                            break;
                        }
                        else
                        {
                            next_dialogue = dialogue.nextTurnIds[p + 1];
                        }
                    }
                }
                else
                {
                    next_dialogue = dialogue.nextTurnIds[0];
                }

            }
            else
            {
                next_dialogue = null;
            }

            waiting_for_dialogue = true;
        }
        else
        {
            choices = new List<string>();
            ui_dialogue_choice_1.SetActive(true);
            //if (!local_data_config.LocalData.ContainsKey(dialogue.dialogueChoiceIds[0]))
            if (!Configs.config_dialogue_choices.DialogueChoice.ContainsKey(dialogue.dialogueChoiceIds[0]))
            {
                Debug.Log("Could not find choice " + dialogue.dialogueChoiceIds[0]);
            }

            if (Configs.dialogue_choice_override_dict.ContainsKey(dialogue.dialogueChoiceIds[0]))
            {
                foreach (ConfigDialogueChoiceOverride._DialogueChoiceOverride override_choice in Configs.dialogue_choice_override_dict[dialogue.dialogueChoiceIds[0]])
                {
                    if (override_choice.companionId == GameStart.game_state.companionId)
                    {
                        Log.writeFull("Overriding choice " + dialogue.dialogueChoiceIds[0] + " with " + override_choice.id);
                        override_choice.overrideChoice(Configs.config_dialogue_choices.DialogueChoice[dialogue.dialogueChoiceIds[0]]);
                    }
                }
            }

            if (Configs.dialogue_choice_override_dict.ContainsKey(dialogue.dialogueChoiceIds[1]))
            {
                foreach (ConfigDialogueChoiceOverride._DialogueChoiceOverride override_choice in Configs.dialogue_choice_override_dict[dialogue.dialogueChoiceIds[1]])
                {
                    if (override_choice.companionId == GameStart.game_state.companionId)
                    {
                        Log.writeFull("Overriding choice " + dialogue.dialogueChoiceIds[1] + " with " + override_choice.id);
                        override_choice.overrideChoice(Configs.config_dialogue_choices.DialogueChoice[dialogue.dialogueChoiceIds[1]]);
                    }
                }
            }

            if (dialogue.dialogueChoiceIds.Length > 2)
            {
                if (Configs.dialogue_choice_override_dict.ContainsKey(dialogue.dialogueChoiceIds[2]))
                {
                    foreach (ConfigDialogueChoiceOverride._DialogueChoiceOverride override_choice in Configs.dialogue_choice_override_dict[dialogue.dialogueChoiceIds[2]])
                    {
                        if (override_choice.companionId == GameStart.game_state.companionId)
                        {
                            Log.writeFull("Overriding choice " + dialogue.dialogueChoiceIds[2] + " with " + override_choice.id);
                            override_choice.overrideChoice(Configs.config_dialogue_choices.DialogueChoice[dialogue.dialogueChoiceIds[2]]);
                        }
                    }
                }
            }

            ui_dialogue_choice_1.GetComponentInChildren<Text>().text = getLocalDataLine(  Configs.config_dialogue_choices.DialogueChoice[dialogue.dialogueChoiceIds[0]].choiceToken);
            if (dialogue.nextTurnIds != null)
                dialogue_choice_1_next_dialogue = dialogue.nextTurnIds[0];
            else if (Configs.config_dialogue_choices.DialogueChoice[dialogue.dialogueChoiceIds[0]].noQteTurnId != null)
                dialogue_choice_1_next_dialogue = Configs.config_dialogue_choices.DialogueChoice[dialogue.dialogueChoiceIds[0]].noQteTurnId; //dates
            else if (Configs.config_dialogue_choices.DialogueChoice[dialogue.dialogueChoiceIds[0]].preQteTurnId != null)
                dialogue_choice_1_next_dialogue = Configs.config_dialogue_choices.DialogueChoice[dialogue.dialogueChoiceIds[0]].successTurnId; //dates
            else
                throw new System.Exception("A");
            choices.Add(dialogue.dialogueChoiceIds[0]);

            ui_dialogue_choice_2.SetActive(true);
            ui_dialogue_choice_2.GetComponentInChildren<Text>().text = getLocalDataLine(Configs.config_dialogue_choices.DialogueChoice[dialogue.dialogueChoiceIds[1]].choiceToken);
            if (dialogue.nextTurnIds != null)
                dialogue_choice_2_next_dialogue = dialogue.nextTurnIds[1];
            else if (Configs.config_dialogue_choices.DialogueChoice[dialogue.dialogueChoiceIds[1]].noQteTurnId != null)
                dialogue_choice_2_next_dialogue = Configs.config_dialogue_choices.DialogueChoice[dialogue.dialogueChoiceIds[1]].noQteTurnId; //dates
            else if (Configs.config_dialogue_choices.DialogueChoice[dialogue.dialogueChoiceIds[1]].preQteTurnId != null)
                dialogue_choice_2_next_dialogue = Configs.config_dialogue_choices.DialogueChoice[dialogue.dialogueChoiceIds[1]].successTurnId; //dates
            else
                throw new System.Exception("A");
            choices.Add(dialogue.dialogueChoiceIds[1]);

            if (dialogue.dialogueChoiceIds.Length > 2)
            {
                ui_dialogue_choice_3.SetActive(true);
                ui_dialogue_choice_3.GetComponentInChildren<Text>().text = getLocalDataLine(Configs.config_dialogue_choices.DialogueChoice[dialogue.dialogueChoiceIds[2]].choiceToken);
                if (dialogue.nextTurnIds != null)
                    dialogue_choice_3_next_dialogue = dialogue.nextTurnIds[2];
                else if (Configs.config_dialogue_choices.DialogueChoice[dialogue.dialogueChoiceIds[2]].noQteTurnId != null)
                    dialogue_choice_3_next_dialogue = Configs.config_dialogue_choices.DialogueChoice[dialogue.dialogueChoiceIds[2]].noQteTurnId; //dates
                else if (Configs.config_dialogue_choices.DialogueChoice[dialogue.dialogueChoiceIds[2]].preQteTurnId != null)
                    dialogue_choice_3_next_dialogue = Configs.config_dialogue_choices.DialogueChoice[dialogue.dialogueChoiceIds[2]].successTurnId; //dates
                else
                    throw new System.Exception("A");
                choices.Add(dialogue.dialogueChoiceIds[2]);
            }
            waiting_for_dialogue = false;
        }

        if (dialogue.enterEvents != null)
        {
            foreach (string enter_event in dialogue.enterEvents)
            {
                entry_stack.Add(enter_event);
            }
        }

        if (entry_stack.Count != 0)
        {
            event_manager.event_stack.AddRange(entry_stack);
            entry_stack.Clear();
            event_manager.runImmediateEvents();
        }


        if (dialogue.cameraShot != null)
        {
            camera_params = new string[] { dialogue.cameraShot, "0" };
            //string[] event_params = new string[] {dialogue.cameraShot, "0"};
            //GetComponent<EventManager>().focusCamera(event_params);
        }
        else
        {
            camera_params = null;
        }

        if (event_manager.event_stack.Count == 0 && event_manager.block_duration == 0.0f && event_manager.total_block == false)
        {
            dialogue_status = DialogueStatus.WaitingPlayerConfirm;
            if (camera_params != null)
            {
                CameraManager.focusCam(ref camera_params);
                camera_params = null;
            }
            start_dialogue_time = Time.realtimeSinceStartup;
            text_holder = next_text_holder;
            name_holder = next_name_holder;
        }

        if (dialogue.exitEvents != null)
        {
            foreach (string exit_event in dialogue.exitEvents)
            {
                exit_stack.Add(exit_event);
            }
        }
        ui_dialogue_name.text = "";
        ui_dialogue_text.text = "";

        if (dialogue.nextTurnIds == null && dialogue.dialogueChoiceIds == null)
        {
            return true; //Finished dialogue
        }
        else
        {
            return false;
        }
    }

    public string mapName(string speaker)
    {
        string temp_name = ""; //Check for last name, check for last name mapping. Then check for first name, check for first name mapping

        if (Configs.config_hp_actor_info.HPActorInfo.ContainsKey(speaker)){
            if (Configs.config_hp_actor_info.HPActorInfo[speaker].nameLast != null)
            {
                temp_name = Configs.config_hp_actor_info.HPActorInfo[speaker].nameLast;

                if (Configs.config_local_data.LocalData.ContainsKey(temp_name))
                {
                    temp_name = Configs.config_local_data.LocalData[temp_name].en_US;
                    if (Configs.config_local_data.LocalData.ContainsKey(temp_name))
                    {
                        temp_name = Configs.config_local_data.LocalData[temp_name].en_US;
                    }
                }

            }
            else if (Configs.config_hp_actor_info.HPActorInfo[speaker].nameFirst != null)
            {
                temp_name = Configs.config_hp_actor_info.HPActorInfo[speaker].nameFirst;

                if (Configs.config_local_data.LocalData.ContainsKey(temp_name))
                {
                    temp_name = Configs.config_local_data.LocalData[temp_name].en_US;
                    if (Configs.config_local_data.LocalData.ContainsKey(temp_name))
                    {
                        temp_name = Configs.config_local_data.LocalData[temp_name].en_US;
                    }
                }

            }
            else
            {
                temp_name = speaker;
            }
        }
        else
        {
            temp_name = speaker;
            if (Configs.config_local_data.LocalData.ContainsKey(temp_name))
            {
                temp_name = Configs.config_local_data.LocalData[temp_name].en_US;
                if (Configs.config_local_data.LocalData.ContainsKey(temp_name))
                {
                    temp_name = Configs.config_local_data.LocalData[temp_name].en_US;
                }
            }
            else
            {
                temp_name = speaker;
            }
        }

        temp_name = temp_name.Replace("::Date::", Configs.config_companion.Companion[GameStart.game_state.companionId].speakerId);


        return temp_name;
    }

    public void hideDialogue()
    {
        ui_dialogue.SetActive(false);
    }

    public void Update()
    {


        /*if (Time.realtimeSinceStartup > next_letter_time && ui_dialogue.activeSelf == true)
        {
            if (name_holder_index >= 3)
            {
                ui_dialogue_name.text = name_holder;
                if (text_holder_index <= text_holder.Length)
                {
                    ui_dialogue_text.text = text_holder.Substring(0, text_holder_index);
                    text_holder_index++;

                }
                next_letter_time = Time.realtimeSinceStartup + letter_seperator;
            }
            name_holder_index++;
        }*/

        switch (dialogue_status)
        {
            case DialogueStatus.WaitingEnterEvents:


                if (event_manager.event_stack.Count == 0 && event_manager.block_duration == 0.0f && event_manager.total_block == false)
                {
                    dialogue_status = DialogueStatus.WaitingPlayerConfirm;
                    if (camera_params != null)
                    {
                        CameraManager.focusCam(ref camera_params);
                        camera_params = null;
                    }
                    start_dialogue_time = Time.realtimeSinceStartup;
                    if (next_text_holder != null)
                    {
                        ui_dialogue.SetActive(true);
                    }
                    else
                    {
                        ui_dialogue.SetActive(false);
                    }
                    text_holder = next_text_holder;
                    name_holder = next_name_holder;
                }
                break;
            case DialogueStatus.WaitingPlayerConfirm:
                if (ui_dialogue_choice_1.activeSelf)
                {
                    if (next_text_holder != null)
                    {
                        ui_dialogue.SetActive(true);
                    }
                    else
                    {
                        ui_dialogue.SetActive(false);
                    }
                    dialogue_status = DialogueStatus.WaitingPlayerOptionSelect;
                    break;
                }
                if (Input.GetKeyDown("space"))
                {
                    dialogue_status = DialogueStatus.WaitingExitEvents;
                    //ui_dialogue.SetActive(false);
                    foreach(string s in exit_stack)
                    {
                        event_manager.event_stack.Add(s);
                    }
                    exit_stack.Clear();
                    event_manager.runImmediateEvents();
                    if (event_manager.event_stack.Count == 0 && event_manager.block_duration == 0.0f && event_manager.total_block == false)
                    {
                        if (next_dialogue != null)
                        {
                            activateDialogue(next_dialogue);
                            dialogue_status = DialogueStatus.WaitingEnterEvents;
                        }
                        else
                        {
                            dialogue_status = DialogueStatus.Finished;
                            Debug.Log("Dialogue finished " + current_dialogue.dialogue);
                            onDialogueFinishedEvent.Invoke(current_dialogue.dialogue);

                            //dungeon_master.checkObjective(current_dialogue.dialogue, "Dialog");
                            if (GameStart.game_state.state == GameState.State.StateQuidditch && GameStart.quidditch_manager.state == Quidditch.State.state_waiting_dialogue)
                            {
                                Debug.Log("Quidditch Dialog callback"); //Is this called early?
                                GameStart.quidditch_manager.dialogueCallback();
                            }
                            CameraManager.freeCamera();
                            foreach (string character in GameStart.game_state.characters.Keys)
                            {
                                GameStart.game_state.characters[character].clearLookat();
                                GameStart.game_state.characters[character].clearTurnHeadAt();
                            }
                        }
                    }
                }
                else
                {
                    ui_dialogue.SetActive(true);
                }
                break;
            case DialogueStatus.WaitingExitEvents:
                if (event_manager.event_stack.Count == 0 && event_manager.block_duration == 0.0f && event_manager.total_block == false)
                {
                    if (next_dialogue != null)
                    {
                        activateDialogue(next_dialogue);
                        dialogue_status = DialogueStatus.WaitingEnterEvents;
                    }
                    else
                    {
                        dialogue_status = DialogueStatus.Finished;
                        //if (GameObject.Find("hud_important") == null && GameObject.Find("hud_encounter") == null && GameObject.Find("hud_dialog") == null)
                        //{
                        Debug.Log("Dialogue finished " + current_dialogue.dialogue);

                        //ui_dialogue.SetActive(false);

                        onDialogueFinishedEvent.Invoke(current_dialogue.dialogue);


                        if (GameStart.game_state.state == GameState.State.StateQuidditch && GameStart.quidditch_manager.state == Quidditch.State.state_waiting_dialogue)
                        {
                            Debug.Log("Quidditch Dialog callback");
                            GameStart.quidditch_manager.dialogueCallback();
                        }
                        CameraManager.freeCamera();

                        foreach (string character in GameStart.game_state.characters.Keys)
                        {
                            GameStart.game_state.characters[character].clearLookat();
                            GameStart.game_state.characters[character].clearTurnHeadAt();
                        }

                        //GetComponent<EventManager>().looking_characters.Clear(); //IS THIS ACCURATE?
                    }
                }
                break;
            case DialogueStatus.Finished:
                if (!in_bubble)
                {
                    ui_dialogue.SetActive(false);
                }
                if (current_dialogue != null)
                {
                    onDialogueFinishedEvent?.Invoke(current_dialogue.dialogue);
                }
                break;
        }

        if (ui_dialogue.activeSelf == true && text_holder != null)
        {
            ui_dialogue_name.text = name_holder;
            int text_holder_index = Mathf.Min((int)((Time.realtimeSinceStartup - start_dialogue_time) / letter_seperator), text_holder.Length);
            ui_dialogue_text.text = text_holder.Substring(0, text_holder_index);
        }
        else
        {
            ui_dialogue.SetActive(false);
            ui_dialogue_name.text = "FUCK";
            ui_dialogue_text.text = "FUCK";
        }

    }

    /*public void LateUpdate()
    {
        if (Time.realtimeSinceStartup > next_letter_time && ui_dialogue.activeSelf == true)
        {
            if (name_holder_index >= 3)
            {
                ui_dialogue_name.text = name_holder;
                if (text_holder_index <= text_holder.Length)
                {
                    ui_dialogue_text.text = text_holder.Substring(0, text_holder_index);
                    text_holder_index++;

                }
                next_letter_time = Time.realtimeSinceStartup + letter_seperator;
            }
            name_holder_index++;
        }
    }*/


    public string getLocalDataLine(string line)
    {
        if (Configs.config_local_data.LocalData.ContainsKey(line))
        {
            string text = Configs.config_local_data.LocalData[line].en_US;
            text = text.Replace("::FirstName::", local_avatar_first_name);
            text = text.Replace("::LastName::", local_avatar_last_name);
            text = text.Replace("::FullName::", local_avatar_full_name);
            text = text.Replace("::House::", local_avatar_house[0].ToString().ToUpper() + local_avatar_house.Substring(1, local_avatar_house.Length - 1));
            text = text.Replace("::Date::", Configs.config_companion.Companion[GameStart.game_state.companionId].speakerId);

            switch (DialogueManager.local_avatar_opponent_house)
            {
                case "hufflepuff":
                    text = text.Replace("::opponentHouse::", "Hufflepuff");
                    break;
                case "ravenclaw":
                    text = text.Replace("::opponentHouse::", "Ravenclaw");
                    break;
                case "slytherin":
                    text = text.Replace("::opponentHouse::", "Slytherin");
                    break;
                case "gryffindor":
                    text = text.Replace("::opponentHouse::", "Gryffindor");
                    break;
                default:
                    text.Replace("::opponentHouse::", "Hufflepuff");
                    break;
            }

            text = text.Replace("{bold}", "");//"<b>");
            text = text.Replace("{italic}", "");
            text = text.Replace("{/}", "");//"</b>");




            if (local_avatar_gender == "male")
            {
                text = text.Replace("::HeadKid::", "Head Boy");
            }
            else
            {
                text = text.Replace("::HeadKid::", "Head Girl");
            }
            return text;
        }
        else
        {
            return "ERROR";
        }
    }

    public void Awake()
    {
        dialogue_status = DialogueStatus.Finished;
        madeChoice = new List<string>();
    }
}