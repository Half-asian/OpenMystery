﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using Newtonsoft.Json;

public class CharAnimSequenceHandler : MonoBehaviour
{


    //Attach this script to items with an anim sequence

    public ConfigCharAnimSequence._CharAnimSequence anim_sequence;

    public int node_index = 0;

    public bool waiting = false;

    public IEnumerator wait_for_animation = null;

    Animation _animation;

    string current_animation_name;

    public Dictionary<string, GameObject> props = new Dictionary<string, GameObject>();
    //public List<GameObject> propsb = new List<GameObject>();

    ConfigHPActorInfo._HPActorInfo actor_info;

    private void Awake()
    {
        if (GetComponent<CharacterManager>() != null)
        {
            actor_info = GetComponent<CharacterManager>().actor_info;
        }
    }

    static string getBroomSkinName(string actor_id)
    {
        if (Configs.config_quidditch_broom_info.QuidditchBroomInfo.ContainsKey(actor_id))
        {
            if (Configs.config_quidditch_broom_info.QuidditchBroomInfo[actor_id].predicates != null)
            {
                for (int i = 0; i <  Configs.config_quidditch_broom_info.QuidditchBroomInfo[actor_id].predicates.Length; i++)
                {
                    if (Predicate.parsePredicate(Configs.config_quidditch_broom_info.QuidditchBroomInfo[actor_id].predicates[i]) == true)
                    {
                        return Configs.config_quidditch_broom_info.QuidditchBroomInfo[actor_id].brooms[i];
                    }
                }
            }
            return Configs.config_quidditch_broom_info.QuidditchBroomInfo[actor_id].defaultBroom;
        }
        return Configs.config_quidditch_broom_info.QuidditchBroomInfo["default"].defaultBroom;
    }


    Transform recursiveFindChild(Transform parent, string childName)
    {
        foreach (Transform child in parent)
        {
            if (child.name == childName)
            {
                return child;
            }
            else
            {
                Transform found = recursiveFindChild(child, childName);
                if (found != null)
                {
                    return found;
                }
            }
        }
        return null;
    }

    private IEnumerator p_blackBoardEvidence_skin_transition(float transition_time, float start_time)
    {
        Debug.Log("Couroutine start");
        float u_transition;
        while (Time.realtimeSinceStartup < transition_time + start_time)
        {
            u_transition = Mathf.Lerp(1f, 0.0f, (Time.realtimeSinceStartup - start_time) / transition_time);
            transform.Find("QuidditchBlackBoardMove").GetComponent<SkinnedMeshRenderer>().material.SetFloat("u_transition", u_transition);
            yield return null;
        }
        u_transition = 0.0f;
        transform.Find("QuidditchBlackBoardMove").GetComponent<SkinnedMeshRenderer>().material.SetFloat("u_transition", u_transition);
    }

    private IEnumerator WaitForAnimation(float clip_time, float start_time, string animation_name)
    {
        while (Time.realtimeSinceStartup < clip_time + start_time)
            yield return null;

        // at this point, the animation has completed
        // so at this point, do whatever you wish...
        GameObject.Find("GameManager").GetComponent<EventManager>().notifyCharacterAnimationComplete(gameObject.name, animation_name);

        if (waiting == true)
        {
            waiting = false;
            advanceAnimSequence();
        }
        else
        {
            Debug.Log("Wtf");
        }
    }

    /*public IEnumerator safeAdvanceAnimSequenceTo(string destination)
    {
        while (current_animation_name != destination)
        {
            advanceAnimSequence();
            yield return null;
        }
        GameObject.Find("GameManager").GetComponent<EventManager>().notifySequenceNodeExited(destination);

        while (waiting == true)
        {
            yield return null;
        }
    }*/

    public void safeAdvanceAnimSequenceTo(string destination)
    {
        advanceAnimSequence();
        /*while (current_animation_name != destination)
        {
            advanceAnimSequence();
        }*/
    }

    public void playBookAnim(string target)
    {

        AnimationClip anim_clip = AnimationManager.loadAnimationClip(target, "c3b", null);
        Debug.Log(target);
        if (anim_clip != null)
        {
            if (Configs.config_animation.Animation3D.ContainsKey(target))
            {
                if (Configs.config_animation.Animation3D[target].wrapMode == "clamp")
                {
                    props["p_Book01_skin"].GetComponent<Animation>().wrapMode = WrapMode.ClampForever;

                }
                else
                {
                    props["p_Book01_skin"].GetComponent<Animation>().wrapMode = WrapMode.Loop;
                }
            }
            else
            {
                props["p_Book01_skin"].GetComponent<Animation>().wrapMode = WrapMode.Loop;
            }
            props["p_Book01_skin"].GetComponent<Animation>().AddClip(anim_clip, "default");
            props["p_Book01_skin"].GetComponent<Animation>().Play("default");
        }

    }

    public void processAction(ConfigCharAnimSequence._CharAnimSequence._data.action action)
    {
        switch (action.type)
        {
            case "AttachProp":
                //Debug.Log("AttachProp " + action.id);
                if (action.alias != null)
                {
                    if (props.ContainsKey(action.alias))
                        return;
                }
                if (action.alias == null && props.ContainsKey(action.id))
                {
                    return;
                }

                GameObject prop = null;
                ModelManager.loadModel(ref prop, action.id, "c3b");
                if (prop != null)
                {
                    prop.AddComponent<Animation>();

                    if (action.alias != null)
                    {
                        props[action.alias] = prop;
                    }
                    else
                    {
                        props[action.id] = prop;
                    }

                    Transform bone_to_attach = recursiveFindChild(gameObject.transform, action.target);//   gameObject.transform.Find("Armature/" + action.target);
                    if (bone_to_attach == null)
                    {
                        Debug.LogError("found the bone no! :( " + action.target);
                        bone_to_attach = recursiveFindChild(gameObject.transform, "jt_all_bind");
                    }
                    if (bone_to_attach.name == "jt_propCounterScale")
                    {
                        bone_to_attach = recursiveFindChild(gameObject.transform, "jt_all_bind");
                    }
                    prop.transform.parent = bone_to_attach;
                    prop.transform.localPosition = Vector3.zero;
                    prop.transform.localRotation = Quaternion.identity;
                }
                break;
            case "AttachBroom": //WORK ON THIS LATER. FIGURE OUT HOW THE GAME FINDS CHARACTERS BROOMS
                if (!props.ContainsKey("broom"))
                {
                    GameObject broom_prop = null;

                    string broom_skin_name = getBroomSkinName(GetComponent<CharacterManager>().actor_info.actorId);

                    ModelManager.loadModel(ref broom_prop, broom_skin_name, "c3b");

                    if (broom_prop != null)
                    {
                        broom_prop.name = broom_skin_name;
                        broom_prop.AddComponent<Animation>();
                        props["broom"] = broom_prop;

                        Transform bone_to_attach = recursiveFindChild(gameObject.transform, action.target);//   gameObject.transform.Find("Armature/" + action.target);
                        if (bone_to_attach == null)
                        {
                            Debug.Log("found the bone no! :(");
                        }
                        broom_prop.transform.parent = bone_to_attach;
                        broom_prop.transform.localPosition = Vector3.zero;
                        broom_prop.transform.localRotation = Quaternion.identity;
                    }
                    else
                    {
                        Debug.Log("broom was null :(");
                    }
                }
                break;

            case "PlayBroomAnim":
                if (props.ContainsKey("broom"))
                {
                    AnimationClip anim_clip = AnimationManager.loadAnimationClip(action.target, "c3b", null);
                    if (anim_clip != null)
                    {
                        if (Configs.config_animation.Animation3D.ContainsKey(action.target))
                        {
                            if (Configs.config_animation.Animation3D[action.target].wrapMode == "clamp")
                            {
                                props["broom"].GetComponent<Animation>().wrapMode = WrapMode.ClampForever;

                            }
                            else
                            {
                                props["broom"].GetComponent<Animation>().wrapMode = WrapMode.Loop;
                            }
                        }
                        else
                        {
                            props[action.id].GetComponent<Animation>().wrapMode = WrapMode.Loop;
                        }
                        props["broom"].GetComponent<Animation>().AddClip(anim_clip, "default");
                        props["broom"].GetComponent<Animation>().Play("default");
                    }
                }
                break;

            case "PlayPropAnim":
                if (props.ContainsKey(action.id))
                {
                    AnimationClip anim_clip = AnimationManager.loadAnimationClip(action.target, "c3b", null);
                    if (anim_clip != null)
                    {
                        if (Configs.config_animation.Animation3D.ContainsKey(action.target))
                        {
                            if (Configs.config_animation.Animation3D[action.target].wrapMode == "clamp")
                            {
                                props[action.id].GetComponent<Animation>().wrapMode = WrapMode.ClampForever;

                            }
                            else
                            {
                                props[action.id].GetComponent<Animation>().wrapMode = WrapMode.Loop;
                            }
                        }
                        else
                        {
                            props[action.id].GetComponent<Animation>().wrapMode = WrapMode.Loop;
                        }
                        props[action.id].GetComponent<Animation>().AddClip(anim_clip, "default");
                        props[action.id].GetComponent<Animation>().Play("default");

                        if (action.id == "p_BrothersWand_skin")
                        {
                            props[action.id].GetComponent<Animation>().wrapMode = WrapMode.Loop;
                        }

                    }
                    else
                    {
                        Debug.LogError("Animation was null");
                    }
                }
                else
                {
                    Debug.LogError("COULD NOT PLAY PROP ANIM BECAUSE IT DOENST EXITS " + action.id);
                }
                break;

            default:
                Debug.LogWarning("Unknown animation sequence action type of " + action.type + " in action " + action.id);
                break;
        }
    }

    public bool walk;

    public int initAnimSequence(string _anim_sequence, bool _walk)
    {
        walk = _walk;
        //Find the animation sequence in the config
        waiting = false;
        _animation = GetComponent<Animation>();
        if (wait_for_animation != null)
        {
            StopCoroutine(wait_for_animation);
        }

        if (Configs.config_char_anim_sequence.CharAnimSequence.ContainsKey(_anim_sequence)) {
            anim_sequence = Configs.config_char_anim_sequence.CharAnimSequence[_anim_sequence];
        }
        else
        {
            Debug.Log("Could not find anim sequence " + _anim_sequence);
            //if (GetComponent<CharacterManager>().character_state == CharacterManager.CharacterState.Walk)
            //{
            //}
            //else
            //{
            //    GetComponent<CharacterManager>().replaceCharacterIdle(GetComponent<CharacterManager>().actor_info.animId_idle);
            //}
            walk = false;
            return 1;
        }

        //Find index of starting node

        for (int i = 0; i < anim_sequence.data.nodes.Length; i++)
        {
            if (anim_sequence.data.nodes[i].nodeId == anim_sequence.data.startEdge.destinationId) {
                node_index = i;
            }
        }

        //Perform the entry actions

        if (anim_sequence.data.startEdge.actions != null)
        {
            foreach (ConfigCharAnimSequence._CharAnimSequence._data.action action in anim_sequence.data.startEdge.actions)
            {
                processAction(action);
            }
        }

        if (anim_sequence.data.nodes[node_index].entryActions != null)
        {
            foreach (ConfigCharAnimSequence._CharAnimSequence._data.action action in anim_sequence.data.nodes[node_index].entryActions)
            {
                processAction(action);
            }
        }


        //Load the initial animation and play it 
        AnimationClip anim_clip = null;
        if (walk) 
        {
            current_animation_name = anim_sequence.data.nodes[node_index].walkAnimName;
        }
        else
        {

            current_animation_name = anim_sequence.data.nodes[node_index].animName;
            if (GetComponent<CharacterManager>() != null)
            {
                GetComponent<CharacterManager>().anim_sequence_idle = _anim_sequence;
            }
        }

        if (GetComponent<CharacterManager>() == null)
        {
            anim_clip = AnimationManager.loadAnimationClip(current_animation_name, "c3b", actor_info);
        }
        else
        {
            anim_clip = GetComponent<CharacterManager>().loadAnimation(current_animation_name);
        }

        if (anim_clip != null)
        {

            _animation.AddClip(anim_clip, current_animation_name);
            _animation.Play(current_animation_name);

            for (int i = 0; i < transform.childCount; i++)
            {
                if (transform.GetChild(i).GetComponent<Animation>() != null)
                {
                    transform.GetChild(i).GetComponent<Animation>().AddClip(anim_clip, current_animation_name);
                    transform.GetChild(i).GetComponent<Animation>().Play(current_animation_name);
                }
            }
            if (!anim_sequence.data.nodes[node_index].blocking)
            {
                _animation.wrapMode = WrapMode.ClampForever;
                waiting = true;
                wait_for_animation = WaitForAnimation(anim_clip.length, Time.realtimeSinceStartup, current_animation_name);
                StartCoroutine(wait_for_animation);
                for (int i = 0; i < transform.childCount; i++)
                {
                    if (transform.GetChild(i).GetComponent<Animation>() != null)
                    {
                        transform.GetChild(i).GetComponent<Animation>().wrapMode = WrapMode.ClampForever;
                    }
                }
            }
            else
            {
                _animation.wrapMode = WrapMode.Loop;
                waiting = false;
                for (int i = 0; i < transform.childCount; i++)
                {
                    if (transform.GetChild(i).GetComponent<Animation>() != null)
                    {
                        transform.GetChild(i).GetComponent<Animation>().wrapMode = WrapMode.Loop;
                    }
                }
            }
            if (current_animation_name == "p_blackboardQMovies01_transitions01_blackBoardQMoves01_staticOff")
            {
                StartCoroutine(p_blackBoardEvidence_skin_transition(1.5f, Time.realtimeSinceStartup));
            }
        }
        else
        {
            Debug.LogError("ANIM CLIP NULL");
        }
        return 0;
    }

    public void advanceAnimSequence()
    {

        //Find the new node
        int new_node_index = -1;

        for (int i = 0; i < anim_sequence.data.nodes.Length; i++)
        {
            if (anim_sequence.data.nodes[i].nodeId == anim_sequence.data.nodes[node_index].edges[anim_sequence.data.nodes[node_index].edges.Length - 1].destinationId) //Take the higher one. More accurate would be to check weight.
            {
                new_node_index = i;
            }
        }

        if (new_node_index == -1) //We have reached TheEnd
        {
            foreach (GameObject g in props.Values)
            {
                Destroy(g);
            }
            props.Clear();

            Destroy(gameObject.GetComponent<CharAnimSequenceHandler>());
            return;
        }

        node_index = new_node_index;

        //Activate the actions


        if (anim_sequence.data.nodes[node_index].entryActions != null)
        {
            foreach (ConfigCharAnimSequence._CharAnimSequence._data.action action in anim_sequence.data.nodes[node_index].entryActions)
            {
                processAction(action);
            }
        }


        //Play the main animation

        AnimationClip anim_clip = null;
        if (walk)
        {
            current_animation_name = anim_sequence.data.nodes[node_index].walkAnimName;
        }
        else
        {
            current_animation_name = anim_sequence.data.nodes[node_index].animName;
        }


        if (_animation.GetClip(anim_sequence.data.nodes[node_index].animName) == null)
        {
            if (GetComponent<CharacterManager>() == null)
            {
                anim_clip = AnimationManager.loadAnimationClip(current_animation_name, "c3b", actor_info);
            }
            else
            {
                anim_clip = GetComponent<CharacterManager>().loadAnimation(current_animation_name);
            }
            if (anim_clip != null)
            {
                anim_clip.name = current_animation_name;
            }
        }
        else
        {
            anim_clip = _animation.GetClip(current_animation_name);
        }

        if (anim_clip != null)
        {
            _animation.AddClip(anim_clip, current_animation_name);
            _animation.Play(current_animation_name);

            for (int i = 0; i < transform.childCount; i++)
            {
                if (transform.GetChild(i).GetComponent<Animation>() != null)
                {
                    transform.GetChild(i).GetComponent<Animation>().AddClip(anim_clip, current_animation_name);
                    transform.GetChild(i).GetComponent<Animation>().Play(current_animation_name);
                }
            }

            if (!anim_sequence.data.nodes[node_index].blocking)
            {
                _animation.wrapMode = WrapMode.ClampForever;
                for (int i = 0; i < transform.childCount; i++)
                {
                    if (transform.GetChild(i).GetComponent<Animation>() != null)
                    {
                        transform.GetChild(i).GetComponent<Animation>().wrapMode = WrapMode.ClampForever;
                    }
                }
                waiting = true;
                wait_for_animation = WaitForAnimation(anim_clip.length, Time.realtimeSinceStartup, current_animation_name);
                StartCoroutine(wait_for_animation);
            }
            else
            {
                _animation.wrapMode = WrapMode.Loop;
                for (int i = 0; i < transform.childCount; i++)
                {
                    if (transform.GetChild(i).GetComponent<Animation>() != null)
                    {
                        transform.GetChild(i).GetComponent<Animation>().wrapMode = WrapMode.Loop;
                    }
                }
                waiting = false;
            }
        }
        else
        {
            waiting = false;
        }
    }

    public void destroyProps()
    {
        foreach (GameObject g in props.Values)
        {
            Destroy(g);
        }
        props.Clear();
    }
    public void OnDestroy()
    {
        foreach(GameObject g in props.Values)
        {
            Destroy(g);
        }
        props.Clear();
    }
}