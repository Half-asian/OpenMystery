﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Newtonsoft.Json;

public class ConfigLocalData : Config<ConfigLocalData>
{
    [System.Serializable]
    public class _LocalData
    {
        public string en_US;
    }

    public Dictionary<string, _LocalData> LocalData;

    public override void combine(List<ConfigLocalData> other_list)
    {
        for (int i = 1; i < other_list.Count; i++)
        {
            foreach (string key in other_list[i].LocalData.Keys)
            {
                LocalData[key] = other_list[i].LocalData[key];
            }
        }
    }
}

class ConfigLocalDataLoader
{
    public static async Task loadConfigsAsync()
    {
        List<ConfigLocalData> list_local_data = await ConfigLocalData.getDeserializedConfigsList("LocalData");
        Configs.config_local_data = list_local_data[0];
        Configs.config_local_data.combine(list_local_data);
    }
}
