﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Newtonsoft.Json;
using UnityEngine;

public class ConfigSound : Config<ConfigSound>
{
    [System.Serializable]

    public class Sound
    {
        public string[] files;
        public string frequencyID;
        public string playlistId;
    }

    public List<Sound> BGMusic;
    public List<Sound> Ambient;
    public List<Sound> Playlist;
    public List<Sound> Sounds;
    public List<Sound> SFX;


    public override void combine(List<ConfigSound> other_list)
    {
        for (int i = 1; i < other_list.Count; i++)
        {
            foreach (Sound key in other_list[i].BGMusic)
            {
                if (BGMusic == null)
                    BGMusic = new List<Sound>();
                BGMusic.Add(key);
            }
            foreach (Sound key in other_list[i].Ambient)
            {
                if (Ambient == null)
                    Ambient = new List<Sound>();
                Ambient.Add(key);
            }
            foreach (Sound key in other_list[i].Playlist)
            {
                if (Playlist == null)
                    Playlist = new List<Sound>();
                Playlist.Add(key);
            }
            foreach (Sound key in other_list[i].Sounds)
            {
                if (Sounds == null)
                    Sounds = new List<Sound>();
                Sounds.Add(key);
            }
            foreach (Sound key in other_list[i].SFX)
            {
                if (SFX == null)
                    SFX = new List<Sound>();
                SFX.Add(key);
            }
        }
    }

}


class ConfigSoundsLoader
{



    public static async Task loadConfigsAsync()
    {
        List<ConfigSound> list_sound = await ConfigSound.getDeserializedConfigsList("Playlist");
        Configs.config_sound = list_sound[0];
        Configs.config_sound.combine(list_sound);

        Configs.playlist_dict = new Dictionary<string, ConfigSound.Sound>();

        foreach (ConfigSound.Sound p in Configs.config_sound.Playlist)
        {
            Configs.playlist_dict[p.playlistId] = p;
        }
    }

}
