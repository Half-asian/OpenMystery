using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;
using System.IO;

public class Common : MonoBehaviour
{
    public static bool arrayContains<T>(T[] data, T value)
    {
        foreach (T t in data)
        {
            if (EqualityComparer<T>.Default.Equals(t, value))
            {
                return true;
            }
        }
        return false;
    }

    public static int arrayIndex<T>(T[] data, T value)
    {
        for (int i = 0; i < data.Length; i++)
        {
            if (EqualityComparer<T>.Default.Equals(data[i], value))
            {
                return i;
            }
        }
        return -1;
    }

    public static void setWaypointTransform(ref GameObject prop, ConfigScene._Scene.PropLocator prop_locator)
    {
        if (prop_locator.position != null)
        {
            prop.transform.position = new Vector3(prop_locator.position[0] * -0.01f, prop_locator.position[1] * 0.01f, prop_locator.position[2] * 0.01f);
        }
        if (prop_locator.rotation != null)
        {
            prop.transform.rotation = Quaternion.identity;
            prop.transform.Rotate(new Vector3(0, 0, -prop_locator.rotation[2]));
            prop.transform.Rotate(new Vector3(0, -prop_locator.rotation[1], 0));
            prop.transform.Rotate(new Vector3(prop_locator.rotation[0], 0, 0));
        }
        if (prop_locator.scale != null)
        {
            prop.transform.localScale = new Vector3(prop_locator.scale[0] * 0.01f, prop_locator.scale[1] * 0.01f, prop_locator.scale[2] * 0.01f);
        }
    }

    public static void setWaypointTransform(ref GameObject prop, ConfigScene._Scene.WayPoint prop_locator)
    {
        if (prop_locator.position != null)
        {
            prop.transform.position = new Vector3(prop_locator.position[0] * -0.01f, prop_locator.position[1] * 0.01f, prop_locator.position[2] * 0.01f);
        }
        if (prop_locator.rotation != null)
        {
            prop.transform.rotation = Quaternion.identity;
            prop.transform.Rotate(new Vector3(0, 0, -prop_locator.rotation[2]));
            prop.transform.Rotate(new Vector3(0, -prop_locator.rotation[1], 0));
            prop.transform.Rotate(new Vector3(prop_locator.rotation[0], 0, 0));
        }
        if (prop_locator.scale != null)
        {
            prop.transform.localScale = new Vector3(prop_locator.scale[0], prop_locator.scale[1], prop_locator.scale[2]);
        }
    }

    public static string getConfigPath(string config_name)
    {
        if (!string.IsNullOrWhiteSpace(GlobalEngineVariables.configs_folder))
        {
            string[] file_paths = Directory.GetFiles(GlobalEngineVariables.configs_folder);
            foreach (string file_path in file_paths)
            {
                string file_name = Path.GetFileName(file_path);

                if (file_name.StartsWith(config_name))
                {
                    return file_path;
                }
            }
        }
        /*else
        {
            throw new System.Exception("Tried to load a config but config path not set.");
        }
        throw new System.Exception("Config was missing " + config_name);*/
        Log.writeFull("Could not find config " + config_name);
        return null;
    }
}
