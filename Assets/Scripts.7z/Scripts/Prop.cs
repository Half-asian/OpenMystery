using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Prop
{
    public Prop(string _name, GameObject _game_object, spawner _spawned_by)
    {
        name = _name;
        game_object = _game_object;
        spawned_by = _spawned_by;
    }
    public string name;
    public GameObject game_object;
    public enum spawner
    {
        Scene,
        Event,
    }
    public spawner spawned_by;

    public static void spawnPropFromLocator(ConfigScene._Scene.PropLocator prop_locator)
    {
        GameObject prop = null;
        ModelManager.loadModel(ref prop, prop_locator.reference, "c3b");

        Common.setWaypointTransform(ref prop, prop_locator);

        if (prop != null)
        {
            prop.transform.parent = GameStart.game_state.current_scene_game_object.transform;
            prop.gameObject.name = prop_locator.name;

            if (prop_locator.animation != null)
            {
                Animation prop_anim = prop.AddComponent<Animation>();
                AnimationClip anim = AnimationManager.loadAnimationClip(prop_locator.animation, "c3b", null, null);
                prop_anim.AddClip(anim, "default");
                prop_anim.wrapMode = WrapMode.Loop;
                prop_anim.Play("default");
            }
            prop.name = prop_locator.name;
            Prop new_prop = new Prop(prop_locator.name, prop, Prop.spawner.Scene);
            GameStart.game_state.spawned_props[prop_locator.name] = new_prop;
        }
        else
        {
            Debug.LogWarning("Failed to spawn scene prop " + prop_locator.reference);
        }
    }

    public static void spawnPropFromEvent(string model, ConfigScene._Scene.WayPoint waypoint, string name)
    {
        Prop prop;
        if (GameStart.game_state.spawned_props.ContainsKey(name))
        {
            prop = GameStart.game_state.spawned_props[name];
        }
        else
        {
            prop = new Prop(name, null, spawner.Event);
            ModelManager.loadModel(ref prop.game_object, model, "c3b");
            GameStart.game_state.spawned_props[name] = prop;
        }

        prop.game_object.transform.parent = GameStart.game_state.current_scene_game_object.transform;
        Common.setWaypointTransform(ref prop.game_object, waypoint);
    }
}
