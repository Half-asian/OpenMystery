﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.IO;
using System;
using TMPro;

public class MainMenu : MonoBehaviour
{

    public Image loading_image;
    public GameObject canvas;
    public GameObject menu_object;
    public GameObject crash;

    public GameObject start_button;

    public GameObject sun;
    public GameObject celestial_light;


    public SimpleCameraController cameracontroller;

    public GameObject particles_dust;

    public string _starting_goal_chain = "";
    public int _starting_goal = 0;

    //Loading Screen stuff
    public GameObject loading_screen;
    public Image loading_spinner;

    //dev menu stuff
    public bool dev_mode = false;
    public GameObject dev_mode_button;
    public bool secret_menu_active = false;
    public GameObject secret_menu;
    public Dropdown tlsq_selector;
    public Dropdown mq_selector;


    //TLSQ stuff
    public GameObject tlsq_box;
    public Text tlsq_name;
    public Text tlsq_description;
    public Text tlsq_description2;
    public Image tlsq_image;

    //MQ stuff
    public GameObject mq_box;
    public Text mq_chapter;
    public Text mq_title;
    public Text mq_description;

    //Quidditch stuff
    public Dropdown quidditch_goalchain_selector;
    public Dropdown quidditch_goal_selector;

    public GameObject dialogue_container;
    public GameObject cthunlu;

    public enum State
    {
        stateLoadingScreenLoading,
        stateLoadingScreenAwait,
        stateMenu,
    }

    public State state;

    IEnumerator LateStart()
    {
        List<string> string_list = new List<string>();
        yield return null;
        GameStart.dialogue_manager = GameObject.Find("GameManager").GetComponent<DialogueManager>();
        foreach (ConfigTimeLimitedSideQuest._TimeLimitedSideQuest tlsq in Configs.config_time_limited_side_quest.TimeLimitedSideQuest.Values)
        {
            string_list.Add(tlsq.id);
        }
        tlsq_selector.AddOptions(string_list);

        string_list.Clear();
        foreach (ConfigYears.Year year in Configs.config_years.Years.Values)
        {
            foreach (string chapter in year.chapterIds){
                string_list.Add(chapter);
            }
        }
        mq_selector.AddOptions(string_list);

    }

    public void setTlsqBox()
    {
        mq_box.SetActive(false);
        if (tlsq_selector.captionText.text == "Select a Time Limited Side Quest")
        {
            tlsq_box.SetActive(false);
        }
        else
        {
            mq_selector.value = 0;
            ConfigTimeLimitedSideQuest._TimeLimitedSideQuest tlsq = Configs.config_time_limited_side_quest.TimeLimitedSideQuest[tlsq_selector.captionText.text];
            tlsq_name.text = GameStart.dialogue_manager.getLocalDataLine(tlsq.title);
            tlsq_description.text = GameStart.dialogue_manager.getLocalDataLine(tlsq.introDescription);
            tlsq_description2.text = tlsq_description.text;

            if (tlsq.iconStart != null)
            {
                if (tlsq.iconPredicate != null)
                {
                    bool selected_icon = false;
                    for (int i = 0; i < tlsq.iconPredicate.Length; i++)
                    {
                        if (i < tlsq.iconPredicate.Length)
                        {

                            if (Predicate.parsePredicate(tlsq.iconPredicate[i]))
                            {
                                Sprite s = Resources.Load<Sprite>("Menu/" + tlsq.iconStart[i]["icon"].Substring(0, tlsq.iconStart[i]["icon"].Length - 4));
                                if (s != null)
                                {
                                    tlsq_image.sprite = s;
                                }
                                {
                                    Debug.Log("Menu/" + tlsq.iconStart[i]["icon"].Substring(0, tlsq.iconStart[i]["icon"].Length - 4));
                                }
                                selected_icon = true;
                            }
                        }
                        else
                        {
                            if (selected_icon == false)
                            {
                                Sprite s = Resources.Load<Sprite>("Menu/"+ tlsq.iconStart[i]["icon"].Substring(0, tlsq.iconStart[i]["icon"].Length - 4));
                                if (s != null)
                                {
                                    tlsq_image.sprite = s;
                                }
                                else
                                {
                                    Debug.Log("Menu/" + tlsq.iconStart[i]["icon"]);
                                }
                                selected_icon = true;
                            }
                        }
                    }
                }
                else
                {
                    Sprite s = Resources.Load<Sprite>("Menu/" + tlsq.iconStart[0]["icon"].Substring(0, tlsq.iconStart[0]["icon"].Length - 4));
                    if (s != null)
                    {
                        tlsq_image.sprite = s;
                    }
                    else
                    {
                        Debug.Log("Menu/" + tlsq.iconStart[0]["icon"]);
                    }
                }
                if (tlsq_image.sprite == null)
                {
                    tlsq_image.color = new Color(1, 1, 1, 0);
                }
                else
                {
                    tlsq_image.color = new Color(1, 1, 1, 1);
                }
            }
            else
            {
                tlsq_image.color = new Color(1, 1, 1, 0);
            }

            tlsq_box.SetActive(true);
        }
    }

    public void setMQBox()
    {
        tlsq_box.SetActive(false);
        if (mq_selector.captionText.text == "Select a Main Quest Chapter")
        {
            mq_box.SetActive(false);
        }
        else
        {
            tlsq_selector.value = 0;
            mq_box.SetActive(true);
            foreach (ConfigYears.Year year in Configs.config_years.Years.Values)
            {
                for (int chapter = 0; chapter < year.chapterIds.Count; chapter++)
                {
                    Type t = year.chapterIds[chapter].GetType();

                    if (t == typeof(Newtonsoft.Json.Linq.JValue))
                    {
                        if ((string)year.chapterIds[chapter] == mq_selector.captionText.text)
                        {
                            mq_chapter.text = "CHAPTER " + (chapter + 1);
                        }
                    }
                    else
                    {
                        if ((string)year.chapterIds[chapter][0] == mq_selector.captionText.text)
                        {
                            mq_chapter.text = "CHAPTER " + (chapter + 1);
                        }
                    }
                }
            }
            if (Configs.config_goal_chain.GoalChain.ContainsKey(mq_selector.captionText.text)){
                ConfigGoalChain._GoalChain goal_chain = Configs.config_goal_chain.GoalChain[mq_selector.captionText.text];
                Debug.Log(goal_chain.id);
                mq_title.text = GameStart.dialogue_manager.getLocalDataLine(goal_chain.id);
                mq_description.text = GameStart.dialogue_manager.getLocalDataLine(goal_chain.description);
            }
            else
            {
                mq_title.text = "ERROR";
                mq_description.text = "ERROR";
            }
        }
    }

    public void startMQ()
    {
        devEnterGoalChainID(mq_selector.captionText.text);
    }

    public void startTLSQ()
    {
        ConfigTimeLimitedSideQuest._TimeLimitedSideQuest tlsq = Configs.config_time_limited_side_quest.TimeLimitedSideQuest[tlsq_selector.captionText.text];
        devEnterGoalChainID(tlsq.goalChainIds[0]);
    }

    public void StartMenu()
    {
        dev_mode_button.SetActive(dev_mode);
        StartCoroutine(LateStart());

        if ((float)Screen.width / (float)Screen.height <= 1.61f && (float)Screen.width / (float)Screen.height >= 1.59f) //Hello, Cthunlu!
        {
            Debug.Log("16:10");
            dialogue_container.transform.localPosition = new Vector3(0, -25, 0);
            cthunlu.SetActive(true);
        }

    }

    public void setQuidditchGoalChain()
    {
        string goal_chain = quidditch_goalchain_selector.captionText.text;
        List<string> goals = new List<string>();
        quidditch_goal_selector.ClearOptions();
        for (int i = 0; i < Configs.config_goal_chain.GoalChain[goal_chain].goalIds.Count; i++)
        {
            foreach(string goalid in Configs.config_goal_chain.GoalChain[goal_chain].goalIds[i])
            {
                goals.Add(goalid);
            }
        }

        quidditch_goal_selector.AddOptions(goals);
        start_button.SetActive(true);
    }


    public void devEnterGoalChainID(string id)
    {
        particles_dust.SetActive(false);
        //game_start.GetComponent<GameStart>().playBGMusic("BGM");
        GameStart.dungeon_master.startGoalChain(id);
        loading_image.enabled = true;
        StartCoroutine(countdownLaunch(10));
        cameracontroller.enabled = true;
        GetComponent<PauseMenu>().enabled = true;
    }

    IEnumerator countdownLaunch(int countdown)
    {
        while (countdown > 1)
        {
            countdown--;
            yield return null;
        }
        Debug.Log("Menu load");
        canvas.SetActive(true);
        GameStart.dungeon_master.activateScenarioFromCurrentObjective();
        loading_image.enabled = false;
        menu_object.SetActive(false);
    }

    public void enterGoalChainID()
    {
        particles_dust.SetActive(false);
        GameStart.dungeon_master.startGoalChain(_starting_goal_chain);
        loading_image.enabled = true;
        StartCoroutine(countdownLaunch(10));
        cameracontroller.enabled = true;
        GetComponent<PauseMenu>().enabled = true;
    }

    public void enterGoalID()
    {
        particles_dust.SetActive(false);
        Debug.Log(_starting_goal);
        GameStart.dungeon_master.startGoal(_starting_goal_chain, _starting_goal);

        loading_image.enabled = true;
        StartCoroutine(countdownLaunch(10));
        cameracontroller.enabled = true;
        GetComponent<PauseMenu>().enabled = true;
    }

    public void startGoal(string starting_goal_chain, int starting_goal)
    {
        _starting_goal_chain = starting_goal_chain;
        _starting_goal = starting_goal;
        enterGoalID();
    }



    public string output = "";
    public string stack = "";


    void OnEnable()
    {
        Application.logMessageReceived += HandleLog;
    }

    void HandleLog(string logString, string stackTrace, LogType type)
    {
        output = logString;
        stack = stackTrace;

        if (type == LogType.Exception)
        {
            crash.SetActive(true);
            crash.transform.Find("Error").GetComponent<Text>().text = logString;
            crash.transform.Find("Trace").GetComponent<Text>().text = stackTrace;

            System.IO.FileStream oFileStream = null;

            if (!File.Exists("error_log.txt"))
            {
                oFileStream = new System.IO.FileStream("error_log.txt", System.IO.FileMode.Create);
                oFileStream.Close();
            }

            StreamWriter writer = new StreamWriter("error_log.txt", true);
            writer.WriteLine(logString);
            writer.WriteLine(stackTrace);
            writer.Close();
        }
    }

    public void fakeCrash(string logString, string stackTrace)
    {
        crash.SetActive(true);
        crash.transform.Find("Error").GetComponent<Text>().text = logString;
        crash.transform.Find("Trace").GetComponent<Text>().text = stackTrace;

        System.IO.FileStream oFileStream = null;

        if (!File.Exists("error_log.txt"))
        {
            oFileStream = new System.IO.FileStream("error_log.txt", System.IO.FileMode.Create);
            oFileStream.Close();
        }

        StreamWriter writer = new StreamWriter("error_log.txt", true);
        writer.WriteLine(logString);
        writer.WriteLine(stackTrace);
        writer.Close();
    }

    public void quitGame()
    {
        Debug.Log("should quit game");
        Application.Quit();
        #if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
        #endif
    }

    public string match;
    public void startMatch()
    {
        particles_dust.SetActive(false);
        menu_object.SetActive(false);
        GetComponent<PauseMenu>().enabled = true;
        GameStart.quidditch_manager.startMatch(match, null);
    }

    public void chapterSelect()
    {


        StartCoroutine(fromMenuToChapter());
    }

    IEnumerator fromMenuToChapter()
    {
        float start_time = Time.realtimeSinceStartup;

        GameStart.event_manager.screen_fade.GetComponent<Animator>().SetTrigger("fade_to_black");

        while (Time.realtimeSinceStartup < start_time + 1)
        {
            yield return null;
        }
        menu_object.SetActive(false);

        CameraManager.main_camera_holder.GetComponent<Animator>().SetTrigger("changing room");
        while (Time.realtimeSinceStartup < start_time + 2f)
        {
            yield return null;
        }
        GameStart.event_manager.screen_fade.GetComponent<Animator>().SetTrigger("fade_from_black");
    }



    IEnumerator fromLoadingToMenu()
    {
        state = State.stateMenu;
        float start_time = Time.realtimeSinceStartup;
        GameStart.event_manager.screen_fade.GetComponent<Animator>().SetTrigger("fade_to_black");
        while (Time.realtimeSinceStartup < start_time + 1)
        {
            yield return null;
        }
        loading_screen.SetActive(false);
        while (Time.realtimeSinceStartup < start_time + 2f)
        {
            yield return null;
        }
        GameStart.event_manager.screen_fade.GetComponent<Animator>().SetTrigger("fade_from_black");

    }

    public void Update()
    {
        if (state == State.stateLoadingScreenLoading)
        {
            loading_spinner.transform.Rotate(new Vector3(0, 0, -150 * Time.deltaTime));
        }
        if (state == State.stateLoadingScreenAwait)
        {
            GameStart.ui_manager.press_space_text.color = new Color(Mathf.Abs(Mathf.Sin(Time.realtimeSinceStartup * 2)) + 0.1f, Mathf.Abs(Mathf.Sin(Time.realtimeSinceStartup * 2)) + 0.1f, Mathf.Abs(Mathf.Sin(Time.realtimeSinceStartup * 2)) + 0.1f);
            if (Input.GetKeyDown("space"))
            {
                StartCoroutine(fromLoadingToMenu());
            }
        }
    }
}