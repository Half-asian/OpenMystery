using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class SplashText : MonoBehaviour
{

    List<string> splash_texts = new List<string>()
    {
        "Woo, /hpgg/!",
        "Merula a cute!",
        "Merula Snyde!",
        "Merula!",
        "Wurgh!",
        "Give me Skye romance!",
        "\"...\" - Erika Rath",
        "tfw no witch gf",
        "Did you know:\n Merula and Skye are cousins?",
        "Did you know:\n Chiara is Borf's mother?",
        "Hufflepuff will rise!",
        "Oh shit, I'm sorry.",
        "Drain Gang!",
        "Scum Gang!",
        "Yo, Pierre!",
        "BOOBA!",
        "Hey Ron, can we say fuck in this game?",
        "White Boy Summer!",
        "Come to Brazil!",
        "YWNBAW!",
        "We're all gonna make it!",
        "Monster Energy Infused!",
        "Kiss the Go-Goat!",
        "Made with Unity? Shocker!",
        "Sneed's Feed and Seed.",
        "Khazar milkers.",
        "RIP Robyn Thistlethwaite",
        "Benny Harvey R.I.P",
        "The game was rigged from the start.",
        "Nowadays, anything can be art.\n This splash is art.",
        "My demented fantasy.",
        "My sick fantasy world.",
        "My deep, dark fantasy.",
        "I want Rath to crush my head with her thighs.",
        "A bean!",
        "um uh l0n3 5t@rrrr",
        "Legalize heroin!",
        "I'm a targeted individual.",
        "Jennifer Connelly!",
        "SpottemGottem and Pooh Shiesty linked up!\n Need it or keep it?",
        "Liz Tuttle fucks horses.",
        "The weak should fear the strong.",
        "Hail to the burger king.",
        "Epstein didn't kill himself.",
        "I based my CV on this.",
        "JC, hire me!",
        "Chrrp!",
        "Shoutout to Zero!",
        "A Thulean perspective.",
        "Cowabunga ho.",
    };

    void Start()
    {
        int random_number = Random.Range(0, splash_texts.Count);

        GetComponent<Text>().text = splash_texts[random_number];
    }

    /*public float max_size;
    public float min_size;
    public float speed;
    public bool get_bigger;
    float scale;
    void Update()
    {
        if (get_bigger)
        {
            if (scale < max_size)
            {
                scale += speed * Time.deltaTime;
            }
            else
            {
                get_bigger = false;
            }
        }
        else
        {
            if (scale > min_size)
            {
                scale -= speed * Time.deltaTime;
            }
            else
            {
                get_bigger = true;
            }
        }

        transform.localScale = new Vector3(scale, scale, scale);
    }*/

    public float scale_add;
    public float scale_multiplier;
    public float sin_speed;
    private void Update()
    {
        float scale = Mathf.Abs(Mathf.Sin(Time.realtimeSinceStartup * sin_speed));
        scale += scale_add;
        scale *= scale_multiplier;

        transform.localScale = new Vector3(scale, scale, scale);
    
    }

}
