using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ActorSpawn : MonoBehaviour
{
    static Player player_manager;

    static GameObject game_start;

    public static void spawnCharacterInScene(string character_id, string waypoint_id, string character_name)
    {
        GameObject character_gameobject = null;

        CharacterManager c = spawnCharacter(ref character_gameobject, character_id, character_name);

        GameStart.game_state.characters[c.gameObject.name] = c;

        character_gameobject.transform.parent = GameStart.game_state.current_scene_game_object.transform;


        if (GameStart.game_state.scenario_holder.scene.waypoint_dict.ContainsKey(waypoint_id))
        {
            ConfigScene._Scene.WayPoint w = GameStart.game_state.scenario_holder.scene.waypoint_dict[waypoint_id];

            if (character_gameobject != null)
            {
                Vector3 temp = new Vector3(w.position[0] * -0.01f, w.position[1] * 0.01f, w.position[2] * 0.01f);
                character_gameobject.transform.position = temp;
                c.current_waypoint = w.name;
                if (w.rotation != null)
                {
                    character_gameobject.transform.rotation = Quaternion.identity;
                    character_gameobject.transform.Rotate(new Vector3(0, 0, -w.rotation[2]));
                    character_gameobject.transform.Rotate(new Vector3(0, -w.rotation[1], 0));
                    character_gameobject.transform.Rotate(new Vector3(w.rotation[0], 0, 0));
                }
                else
                {
                    character_gameobject.transform.rotation = Quaternion.Euler(Vector3.zero);
                }
                if (w.scale != null)
                {
                    character_gameobject.transform.localScale = new Vector3(w.scale[0], w.scale[1], w.scale[2]);
                }
            }

        }
        else
        {
            Debug.LogWarning("Char spawn waypoint ID not in scene waypoint dict " + waypoint_id);
        }
        if (character_id == "Avatar")
        {
            if (DialogueManager.local_avatar_clothing_type != null)
            {
                player_manager.changeClothes(DialogueManager.local_avatar_clothing_type, DialogueManager.local_avatar_secondary_lothing_option, DialogueManager.local_avatar_onscreen_name);
            }
        }

        GameStart.game_state.characters_gameobjects.Add(character_gameobject);
    }

    public static Dictionary<string, Transform> spawnAvatar(ref GameObject gameobject, ConfigHPActorInfo._HPActorInfo actor_info)
    {
        Debug.Log("spawnAvatar");
        Dictionary<string, Transform> parent_bones = new Dictionary<string, Transform>();
        if (actor_info.modelId == "c_Avatar_Male_headQuidditch_skin")
        {
            parent_bones = ModelManager.loadModel(ref gameobject, "c_Avatar_Male_headNoseless_skin", "c3b");
        }

        return parent_bones;
    }

    public static CharacterManager spawnCharacter(ref GameObject character_gameobject, string character_id, string character_name)
    {
        ConfigHPActorInfo._HPActorInfo character = null;
        Dictionary<string, Transform> parent_bones = null;
        character_id = ConfigActorMapping.getActorMapping(character_id, DialogueManager.local_avatar_gender);

        if (character_id == "::prefectIdAlias::")
        {
            character_id = Configs.config_house.House[DialogueManager.local_avatar_house].snippets_prefectIdAlias;
        }

        if (!Configs.config_hp_actor_info.HPActorInfo.ContainsKey(character_id))
            character = Configs.config_hp_actor_info.HPActorInfo["c_Skye_skin"];
        else
        {
            character = Configs.config_hp_actor_info.HPActorInfo[character_id];
        }


        if (character_id != "Avatar")
        {
            character = Configs.config_hp_actor_info.HPActorInfo[character_id];
            parent_bones = ModelManager.loadModel(ref character_gameobject, character.modelId, "c3b");
        }
        else
        {
            DialogueManager.local_avatar_onscreen_name = character_name;
            return StaticAvatarSpawner.spawnStaticAvatar(ref character_gameobject);

            /*parent_bones = player_manager.readCharacterFile(ref character_gameobject, "character.txt");
            if (game_start != null)
            {
                character_gameobject.transform.parent = game_start.transform;
            }
            character_gameobject.name = "Avatar";*/
        }

        if (character.quidditchMaterialOptions != null)
        {
            string house;
            if (character.quidditchMaterialOptions.houseId == "Avatar")
            {
                house = DialogueManager.local_avatar_house;
            }
            else if (character.quidditchMaterialOptions.houseId == "QuidditchRival")
            {
                if (DialogueManager.local_avatar_house == "ravenclaw")
                    house = "slytherin";
                else
                    house = "ravenclaw";
            }
            else if (character.quidditchMaterialOptions.houseId == "QuidditchOpponent")
            {
                if (DialogueManager.local_avatar_opponent_house != null)
                {
                    house = DialogueManager.local_avatar_opponent_house;
                }
                else
                {
                    house = "gryffindor";
                }
            }
            else
            {
                house = character.quidditchMaterialOptions.houseId;
            }
            if (character.quidditchMaterialOptions.mapping.Keys != null)
            {
                foreach (string map in character.quidditchMaterialOptions.mapping.Keys)
                {
                    Transform piece = character_gameobject.transform.Find(map);
                    if (piece != null)
                    {
                        if (piece.GetComponent<SkinnedMeshRenderer>() != null)
                        {
                            if (house == "ravenclaw" || (house == "Avatar" && DialogueManager.local_avatar_house == "ravenclaw"))
                            {
                                piece.GetComponent<SkinnedMeshRenderer>().material.SetInt("is_ravenclaw", 1);
                                piece.GetComponent<SkinnedMeshRenderer>().material.SetInt("is_slytherin", 0);
                                piece.GetComponent<SkinnedMeshRenderer>().material.SetInt("is_hufflepuff", 0);
                                piece.GetComponent<SkinnedMeshRenderer>().material.SetInt("is_gryffindor", 0);

                            }
                            else if (house == "slytherin" || (house == "Avatar" && DialogueManager.local_avatar_house == "slytherin"))
                            {
                                piece.GetComponent<SkinnedMeshRenderer>().material.SetInt("is_ravenclaw", 0);
                                piece.GetComponent<SkinnedMeshRenderer>().material.SetInt("is_slytherin", 1);
                                piece.GetComponent<SkinnedMeshRenderer>().material.SetInt("is_hufflepuff", 0);
                                piece.GetComponent<SkinnedMeshRenderer>().material.SetInt("is_gryffindor", 0);
                            }
                            else if (house == "hufflepuff" || (house == "Avatar" && DialogueManager.local_avatar_house == "hufflepuff"))
                            {
                                piece.GetComponent<SkinnedMeshRenderer>().material.SetInt("is_ravenclaw", 0);
                                piece.GetComponent<SkinnedMeshRenderer>().material.SetInt("is_slytherin", 0);
                                piece.GetComponent<SkinnedMeshRenderer>().material.SetInt("is_hufflepuff", 1);
                                piece.GetComponent<SkinnedMeshRenderer>().material.SetInt("is_gryffindor", 0);
                            }
                            else if (house == "gryffindor" || (house == "Avatar" && DialogueManager.local_avatar_house == "gryffindor"))
                            {
                                piece.GetComponent<SkinnedMeshRenderer>().material.SetInt("is_ravenclaw", 0);
                                piece.GetComponent<SkinnedMeshRenderer>().material.SetInt("is_slytherin", 0);
                                piece.GetComponent<SkinnedMeshRenderer>().material.SetInt("is_hufflepuff", 0);
                                piece.GetComponent<SkinnedMeshRenderer>().material.SetInt("is_gryffindor", 1);
                            }

                            else
                            {
                                Debug.LogError("Invalid houseid " + house);
                            }
                        }
                        else
                        {
                            Debug.Log("quidditch piece no skinnedmeshrenderer");
                        }
                    }
                }
            }
        }


        CharacterManager c = character_gameobject.AddComponent<CharacterManager>();
        c.actor_info = character;
        c.animId_idle = character.animId_idle;
        c.patches = new List<GameObject>();
        c.model_name = character.modelId;
        c.parent_bones = parent_bones;
        if (c.parent_bones == null)
        {
            Debug.Log("FUCKFUCK");
        }

        if (character_gameobject != null)
        {
            character_gameobject.name = character_name;

            c.gameObject.AddComponent<Animation>();

            if (character_id != "Avatar")
            {
                if (character.modelPatches != null)
                {
                    foreach (string patch in character.modelPatches)
                    {
                        GameObject p = null;

                        ModelManager.loadModel(ref p, patch, "c3b", parent_bones);

                        if (p != null)
                        {
                            p.transform.parent = character_gameobject.transform;
                            c.patches.Add(p);

                        }
                    }
                }
            }
            else
            {
                for (int i = 0; i < character_gameobject.transform.childCount; i++)
                {
                    if (character_gameobject.transform.GetChild(i).gameObject.transform.childCount >= 1)
                    {
                        character_gameobject.transform.GetChild(i).gameObject.AddComponent<Animation>();
                        c.patches.Add(character_gameobject.transform.GetChild(i).gameObject);
                    }
                }
                c.bone_mods = player_manager._bonemods;
            }
        }

        c.replaceCharacterIdleNoDelay(c.actor_info.animId_idle);
        c.setCharacterIdle();
        return c;
    }

    public static void despawnCharacterInScene(string character_name)
    {
        if (GameStart.game_state.characters.ContainsKey(character_name))
        {
            Destroy(GameStart.game_state.characters[character_name].gameObject);
            GameStart.game_state.characters.Remove(character_name);
        }
    }


    public static void initialise()
    {
        game_start = GameObject.Find("GameManager");
        player_manager = game_start.GetComponent<Player>();
    }
}
